DELETE FROM PSGCOMMON.tblStagerConfigInfo WHERE StagerNo = 337
GO
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10000,'337') 
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10001,'PSG.TMS.Stager.ImageDataRecognition.dll')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10002,'PSG.TMS.Stager.ImageDataRecognition.ImageDataRecognitionStager')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10003,'1')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10004,'3')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10005,'Image data recognition stager')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,10006,'0')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11002,'337')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11276,'True')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11277,'googlevisionai')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11278,'')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11279,'')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11280,'')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11281,'prebuilt-check.us')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11282,'1000')
INSERT INTO PSGCOMMON.tblStagerConfigInfo (StagerNo,Optionkey,OptionValue) VALUES (337,11283,'"VOID", "CANCELLED", "SAMPLE", "TEST", "DUPLICATE", "Warning", "Security", "Back", "PAY", "Order", "Capital", "N.A.", "AMOUNT", "www.", "Check"')
GO