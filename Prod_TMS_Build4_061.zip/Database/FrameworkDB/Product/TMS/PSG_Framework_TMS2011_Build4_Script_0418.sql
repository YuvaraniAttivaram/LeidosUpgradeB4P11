DELETE FROM PSGCOMMON.tblDBObjects Where DBObjectID=101102
GO
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectId,ProgramId,DBObjectType,DBObjectName,DBName,EnvCode,SPType)
VALUES (101102,0,'Stored Procedure','[PSGTMS].[uspUpdateOrientationInFormatFields]','','',0)
GO

DELETE FROM PSGCOMMON.tblDBObjects WHERE ProgramId = 337 AND DBOBJECTID IN (110004, 110006, 110010)
GO
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectID, ProgramId, DBObjectType, DBOBjectName, DBName, EnvCode) VALUES (110004,337,'StoredProcedure','PSGTMS.uspGetBatchAndDetailRecordsForImageDataRecognitionStager','','')
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectID, ProgramId, DBObjectType, DBOBjectName, DBName, EnvCode) VALUES (110006,337,'StoredProcedure','PSGTMS.uspUpdateBatchFileForImageDataRecognitionStager','','')
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectID, ProgramId, DBObjectType, DBOBjectName, DBName, EnvCode) VALUES (110010,337,'StoredProcedure','PSGTMS.uspUpdateDetailFileForImageDataRecognitionStager','','')
GO
DELETE FROM PSGCOMMON.tblDBObjects WHERE ProgramId=0 AND DBObjectId=110877
GO
INSERT INTO PSGCOMMON.tblDBObjects(DBObjectId,ProgramId,DBObjectType,DBObjectName,DBName,EnvCode) VALUES(110877,0,'Stored Procedure','PSGTMS.uspBulkInsertForImageDataRecognitionStager_JSON','','')
GO

DELETE FROM PSGCOMMON.tblDBObjects Where DBObjectID=101101
GO
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectId,ProgramId,DBObjectType,DBObjectName,DBName,EnvCode,SPType)
VALUES (101101,0,'Stored Procedure','[PSGTMS].[uspUpdateCfgOptionValues]','','',0)
GO

DELETE FROM PSGCOMMON.tblDBObjects Where DBObjectID=101106
GO
INSERT INTO PSGCOMMON.tblDBObjects (DBObjectId,ProgramId,DBObjectType,DBObjectName,DBName,EnvCode,SPType)
VALUES (101106,0,'Stored Procedure','[PSGTMS].[uspUpdateOCRConfig]','','',0)
GO