DELETE From PSGCommon.[tblStagerSession] Where StagerID = 64
GO
INSERT INTO PSGCommon.[tblStagerSession] ([StagerId] ,[SessionId],[StagerName] ,[MachineName],[SiteId],[StartTime],[AvailableStagers],[LastAccessTime]
,[LastJobOperation],[NeedKilling],[LoadFactor],[SessionStatus],[ServiceStatus],[StagerTimeOut],[ConfiguredStagers]
,[TriggerPath],[WorkFlowLog],[Clustered],[MaxEvtLog],[EvtLogPath],[AutoStart] ,[ProcessorCount]
,[ConfiguredLoadFactor],[ISInSpokeBase] ,[ServiceInstalled], EnvCode,GenericService)

VALUES (64, '', 'ImageDataRecognitionStager', '', 0,'','337,','', 0, 'False', 4,  'N', '', 20,'337,','[tempdir]\Stager\ImageDataRecognitionStager','1','False',500, '','False',1, '4', '0','False','',0)
GO
