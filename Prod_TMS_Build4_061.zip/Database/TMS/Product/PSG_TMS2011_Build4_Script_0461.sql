
Delete From PSGTMS.tblMessage Where ProgramNumber = 7 and MessageNumber = 6
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (7,6,'Do you want to set this panel orientation to the current format?')
Go

Delete From PSGTMS.tblMessage Where ProgramNumber = 105 and MessageNumber = 3
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (105,3,'Do you want to set this panel orientation to the current format?')
Go

Delete from PSGTMS.tblMessage_Lang where ProgramNumber =7 and MessageNumber = 6 and Languageid = 1
Go
Insert into PSGTMS.tblMessage_Lang Values (1,7,6,'Do you want to set this panel orientation to the current format')
GO

Delete from PSGTMS.tblMessage_Lang where ProgramNumber =105 and MessageNumber = 3 and Languageid = 1
Go
Insert into PSGTMS.tblMessage_Lang Values (1,105,3,'Do you want to set this panel orientation to the current format')
GO

Delete From PSGTMS.tblMessage Where ProgramNumber = 27 and MessageNumber in (1,2)
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (27,1,'Do you want to save the selected courtesy amount snippet area?')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (27,2,'Do you want to set the selected legal amount snippet area?')
Go

Delete From PSGTMS.tblMessage Where ProgramNumber = 76 and MessageNumber in (1,2)
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (76,1,'Do you want to set the selected courtesy amount snippet area ? ')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (76,2,'Do you want to set the selected legal amount snippet area? ')
Go

Delete from PSGTMS.tblMessage_Lang where ProgramNumber =27 and MessageNumber in (1,2) and Languageid = 1
Insert into PSGTMS.tblMessage_Lang Values (1,27,1,'Do you want to save the selected courtesy amount snippet area? Click CurrentLockbox to save for the current lockbox. Click AllLockboxes to save for all lockboxes. Click Cancel to cancel the operation')
Insert into PSGTMS.tblMessage_Lang Values (1,27,2,'Do you want to save the selected legal amount snippet area? Click CurrentLockbox to save for the current lockbox. Click AllLockboxes to save for all lockboxes. Click Cancel to cancel the operation ') 
GO

Delete from PSGTMS.tblMessage_Lang where ProgramNumber = 76 and MessageNumber in (1,2) and Languageid = 1
Insert into PSGTMS.tblMessage_Lang Values (1,76,1,'Do you want to save the selected courtesy amount snippet area? ')
Insert into PSGTMS.tblMessage_Lang Values (1,76,2,'Do you want to save the selected legal amount snippet area? ') 
GO

Delete From PSGTMS.tblMessage Where ProgramNumber = 105 and MessageNumber = 4
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (105,4,'One or more field(s) have low confidence values. Do you accept the values and proceed with posting?')
Go

Delete from PSGTMS.tblMessage_Lang where ProgramNumber =105 and MessageNumber = 4 and Languageid = 1
Insert into PSGTMS.tblMessage_Lang Values (1,105,4,'One or more field(s) have low confidence values. Do you accept the values and proceed with posting?')
GO

Delete From PSGTMS.tblMessage Where ProgramNumber = 105 and MessageNumber in (3,6)
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (105,6,'Do you want to set this panel orientation to the current format?')
Go

Delete from PSGTMS.tblMessage_Lang where ProgramNumber =105 and MessageNumber in (3,6) and Languageid = 1
Go
Insert into PSGTMS.tblMessage_Lang Values (1,105,6,'Do you want to set this panel orientation to the current format?')
GO

Delete From PSGTMS.tblMessage Where programnumber = 9 and MessageNumber in (11,12,13,14,15,16,17,18,19)
Go
INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,11,'Icon not found: %1')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,12,'The following files are not allowed:')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,13,'File %1 exceeds the 1MB size limit and will not be attached.')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,14,'Failed to attach file: %1')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,15,'Please enter a Title.')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,16,'Please enter a Description.')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,17,'Please select a Group.')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,18,'Please select a Priority.')

INSERT INTO PSGTMS.tblMessage ([ProgramNumber],[MessageNumber],[MessageDescription]) 
VALUES (9,19,'Cannot able to create ticket - Failed!')
Go

Delete from PSGTMS.tblMessage_Lang where ProgramNumber = 9 and MessageNumber in (11,12,13,14,15,16,17,18,19) and Languageid = 1
Go
Insert into PSGTMS.tblMessage_Lang Values (1,9,11,'Icon not found: %1')
Insert into PSGTMS.tblMessage_Lang Values (1,9,12,'The following files are not allowed:')
Insert into PSGTMS.tblMessage_Lang Values (1,9,13,'File %1 exceeds the 1MB size limit and will not be attached.')
Insert into PSGTMS.tblMessage_Lang Values (1,9,14,'Failed to attach file: %1')
Insert into PSGTMS.tblMessage_Lang Values (1,9,15,'Please enter a Title.')
Insert into PSGTMS.tblMessage_Lang Values (1,9,16,'Please enter a Description.')
Insert into PSGTMS.tblMessage_Lang Values (1,9,17,'Please select a Group.')
Insert into PSGTMS.tblMessage_Lang Values (1,9,18,'Please select a Priority.')
Insert into PSGTMS.tblMessage_Lang Values (1,9,19,'Cannot able to create ticket - Failed!')
GO

Delete from psgtms.tblmessage Where Programnumber = 7 and MessageNumber in (7,8)
Insert into psgtms.tblmessage Values (7,7,'Do you want to save the current scanline selection for checks in this lockbox?')
Insert into psgtms.tblmessage Values (7,8,'Do you want to save the current scanline selection for stubs in this lockbox?')
GO
Delete from psgtms.tblmessage_lang Where Programnumber = 7 and MessageNumber in (7,8)
Insert into psgtms.tblmessage_lang Values (1,7,7,'Do you want to save the current scanline selection for checks in this lockbox?')
Insert into psgtms.tblmessage_lang Values (1,7,8,'Do you want to save the current scanline selection for stubs in this lockbox?')
GO

