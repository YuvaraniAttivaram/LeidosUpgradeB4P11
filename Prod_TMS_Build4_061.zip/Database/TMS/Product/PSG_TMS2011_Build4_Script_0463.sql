IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspCheckDateExistAndOpenForBod]') AND type in (N'P', N'PC'))
DROP PROCEDURE [PSGTMS].[uspCheckDateExistAndOpenForBod]
GO

Create Procedure [PSGTMS].[uspCheckDateExistAndOpenForBod] 
(
	@ProcessDate char(8),
	@SiteId smallint,
	@DateExist	Int output,  
    @DateOpen	Int output   
)
As
Begin
	SET NOCOUNT ON
	SELECT @DateExist = 0,@DateOpen = 0

	IF (@SiteId > 0)
	BEGIN
		IF EXISTS (
			SELECT 1
			FROM PSGTMS.ADMINFILE WITH (NOLOCK)
			WHERE ProcessingDate = @ProcessDate
			  AND SiteId = @SiteId
		)
		BEGIN
			SET @DateExist = 1
			IF EXISTS (
				SELECT 1
				FROM PSGTMS.ADMINFILE WITH (NOLOCK)
				WHERE ProcessingDate = @ProcessDate
				  AND BeginOfDayFlag = 1
				  AND SiteId = @SiteId
			)
			BEGIN
				SET @DateOpen = 1
			END
		END
	END
	ELSE
	BEGIN
		IF exists(
					SELECT 1 
					FROM  PSGTMS.ADMINFILE WITH (NOLOCK)
					WHERE ProcessingDate = @ProcessDate
					And SiteId > 0
					)
		BEGIN
			SET @DateExist = 1
			IF exists(
					SELECT 1 
					FROM  PSGTMS.ADMINFILE WITH (NOLOCK)
					WHERE ProcessingDate = @ProcessDate 
					and BeginOfDayFlag = 1
					And SiteId > 0
					)
			BEGIN
				SET @DateOpen = 1
			END
		END
	END
	SET NOCOUNT OFF	
End
GO
