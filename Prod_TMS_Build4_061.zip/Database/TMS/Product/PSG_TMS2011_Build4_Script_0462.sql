
IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspUpdateOrientationInFormatFields]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspUpdateOrientationInFormatFields]
GO

CREATE PROCEDURE [PSGTMS].[uspUpdateOrientationInFormatFields]      
(      
 @worksource char(10),            
 @pgmNo smallint ,            
 @formatNo smallint,    
 @Orientation char(1),    
 @key varchar(50)    
)      
AS         
BEGIN      
 SET NOCOUNT ON      
   UPDATE psgtms.tblcustdataentitems    
SET Orientation = @Orientation    
WHERE WorkSource = @worksource    
  AND ProgramNum = @pgmNo    
  AND FormatNo = @formatNo;    
    
  --When a format is updated, delete the corresponding cached entry to ensure the latest format is loaded.    
 DELETE FROM PSGTMS.tblCacheQueueMap    
WHERE CacheKey  = @key;    
     
 SET NOCOUNT OFF      
END 
Go

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspUpdateCfgOptionValues]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspUpdateCfgOptionValues]
GO

CREATE PROCEDURE [PSGTMS].[uspUpdateCfgOptionValues]  
(  
    @WorkSource    VARCHAR(10),  
    @OptionKey     INT,  
    @OptionValue   VARCHAR(255),  
	@programNbr  Int,  
    @WorksourceLevel  TINYINT  -- 1 for worksource level, 2 for program level       
)  
AS  
BEGIN  
    SET NOCOUNT ON;  
  
    -- Worksource Level: update or insert into WorkSrcCfgOption  
    IF @WorksourceLevel = 1  
    BEGIN  
        IF EXISTS (SELECT 1 FROM PSGTMS.WorkSrcCfgOption  with (nolock)
                   WHERE WorkSource = @WorkSource AND OptionKey = @OptionKey)  
        BEGIN  
            UPDATE PSGTMS.WorkSrcCfgOption  
            SET OptionValue = @OptionValue  
            WHERE WorkSource = @WorkSource AND OptionKey = @OptionKey;  
        END  
        ELSE  
        BEGIN  
            INSERT INTO PSGTMS.WorkSrcCfgOption (WorkSource, OptionKey, OptionValue)  
            VALUES (@WorkSource, @OptionKey, @OptionValue);  
        END  
    END  
    -- Program Level: update or insert into ProgramCfgOption, and delete from WorkSrcCfgOption if it exists  
    ELSE IF @WorksourceLevel = 2 
    BEGIN  
        -- Update or insert into ProgramCfgOption  
        IF EXISTS (SELECT 1 FROM PSGTMS.ProgramCfgOption with (nolock)  
                   WHERE ProgramNbr = @programNbr AND OptionKey = @OptionKey)   
        BEGIN  
            UPDATE PSGTMS.ProgramCfgOption  
            SET OptionValue = @OptionValue  
            WHERE ProgramNbr = @programNbr AND OptionKey = @OptionKey;  
        END  
        ELSE  
        BEGIN  
            INSERT INTO PSGTMS.ProgramCfgOption (ProgramNbr, OptionKey, OptionValue)  
            VALUES (@programNbr, @OptionKey, @OptionValue);  
        END  
		--Update to the worksource level also if available except the worksources '000000000' and '999999999'
		UPDATE PSGTMS.WorkSrcCfgOption SET OptionValue = @OptionValue  WHERE WorkSource = @WorkSource AND OptionKey = @OptionKey
			  AND WorkSource NOT IN ('000000000', '999999999');
    END  
  
    SET NOCOUNT OFF;  
END