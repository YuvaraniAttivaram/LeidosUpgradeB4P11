IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspGetBatchAndDetailRecordsForImageDataRecognitionStager]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspGetBatchAndDetailRecordsForImageDataRecognitionStager]
GO
CREATE PROCEDURE [PSGTMS].[uspGetBatchAndDetailRecordsForImageDataRecognitionStager]
(
  @ProcessDate char(8),
  @SiteId smallint,
  @BatchNo char(10),
  @BatchValue int,
  @PCIEncryption bit -- 1 represents enabled , 0 represents disabled
)
AS 
BEGIN
  SET NOCOUNT ON
  Declare @DayOfDate as smallint, @WorkSource Char(10),@IsWorkSrcEnrypted as bit,@BatchKey Bigint
  SET @DayOfDate = PSGTMS.GetDayOfDate(@siteId, @ProcessDate)
 
  UPDATE PSGTMS.BatchFile
  SET BatchValue = 17,
    PrevBatchValue = BatchValue,
    @WorkSource = WorkSrc,
    @BatchKey   = BatchKey
  WHERE SiteId      = @SiteId
    AND BatchNo     = @BatchNo
    AND ProcessDate = @ProcessDate
    AND DayOfDate   = @DayOfDate
    AND BatchValue  = @BatchValue

  IF (@@RowCount > 0)
  Begin
    SELECT  AllTransKilled,ArchiveFlag,AvailDone,BadCheckScanlines,BadStubScanlines,BalancingUsercode,
      BankID,BatchFixCode,BatchFixFlag,BatchhasDup,BatchKey,BatchMode,BatchNo,BatchPriorityTotal,BatchSubMode,
      BatchValue,BlankRearInvoice,BlankRearOCR,BlkNum,CarKillTrans,CCReviewStatus,CheckCount,ChecksCarred,
      CheckStubCount,CheckTotal,CheckZeroAmounts,ChksToFix,ChkswFrstKeyUsr,ChksWRekeyUsr,ContDepTime,DayOfDate,
      DDAcctNo,DDRTNo,DepCredDate,DepositItemCount,DocsCarred,DPM2CheckCount,DPM2CheckTotal,DPM2Date,DPM2StubCount,
      DPM2StubTotal,DPMCheckCount,DPMCheckTotal,DPMDate,DPMP1MachNo,DPMP2MachNo,DPMStubCount,DPMStubTotal,DupDone,
      ECSprocessed,ElapsedTime,EndTime,ExtractCutOffReqd,Extracted,FirstAmtUsercode,FrontImages,HardwareType,
      HasReviewTrans,IcrValue,ImageSeqNo,ItemsCarEntryMatch,ItemsCarMatch,ItemsRqAmtEnt,ItemsRqESPEnt,ItemsRqStbEnt,
      LastActionUsercode,LicenseFlag,LoadNbr,LockFlag,MarkSenseDoneFlag,MatchOption,MaxDetailTotal,MissingItem,
      NoCheckItems,OCRItemCount,OCRPageCount,P1TrackType,P2TrackType,Pass1Usercode,Pass2RunNo,Pass2SortPattern,
      Pass2Usercode,PCCreated,PrevBatchValue,PrevPgmBatchVal,Priority,PriorityManuallySet,ProcessDate,ProcessedInPass2,
      RDERequired,RearImages,ReassignTran,ReceiptDate,ReconAmount,ReportCutOffReqd,RunNo,ScanFixUsercode,SecondAmtUserCode,
      SingleSidedPageCount,SiteId,SortPattern,StartTime,StubCount,StubsCarred,StubsToFix,StubTotal,StubZeroAmounts,
      SuspendStatus,SystemDate,TotalTrans,TransUserLogKey,Unbalanced,UniqueID,UnProcessableItems,UserBatchNo,
      UserData,UserDate1,UserDate2,UserFlag1,UserFlag2,UserFlag3,UserFlag4,UserFlag5,UserInteger1,UserInteger2,
      UserInteger3,UserInteger4,UserInteger5,UserReal1,UserReal2,UserReal3,UserReal4,UserReal5,UserString1,UserString2,
      UserString3,UserString4,UserString5,WhlSlNScanDone,WorkDate,WorkSrc,UserFlag6,UserFlag7,UserFlag8,UserFlag9,
      UserFlag10,UserFlag11,UserFlag12,UserFlag13,UserFlag14,UserFlag15,UserFlag16,UserFlag17,UserFlag18,UserFlag19,UserFlag20
    FROM PSGTMS.Batchfile WITH (NOLOCK)
    WHERE BatchKey = @Batchkey AND DayOfDate=@DayOfDate

    SELECT [Forced],[Matched],[State],[Suspend], AcctNo, AcctType,Amount,AmountType,Amt3,Amt4,AmtChangedFlag,
      ApplicCode,AuxOnUs,BalDisplayCode,BatchMode,BatchNo,BlkNum,CarAmount,CheckNbr,CutNo,Cycle,
      DataEntFormatNo,DayOfDate,DayRelSeqNum,DDANumber,DerogReason,DestEndPoint,DetailKey,DocType,
      DontEncode,DontEndorse,DummyStub,FilmSeq,FirstAmount,Gross,ImageAction,ImageSeqNo,ItemDLN,
      ItemProofAmount,ItemSubType,ItemType,ItemTypeChgd,LockFlag,MatchLen,Net,Onus,Pass1FilmReel,Pass1FilmSeq,
      Pass1MachNo,Pass1PocketNo,Pass1RelSeqNum, Pass1Scanline, Pass1Selector,Pass2FilmReel,Pass2ImageSeqNo,
      Pass2ScanLine, PEMachNo,PktTktNum,PocketNo,PrevPgm,PrevUsercode,ProcCtrl,ProcessDate,Processed,
      ReasonCode,Recog1,Recog2,Reject,RejectPgm,RejectReason,RejectUsercode,RekeyAmount,RetInd,RID,RqAmtEntry,
      RqESPEntry,RqESPRekey,RqRekey,RqScnFix,RTNo, ScanFields, ScanlineCRC,ScanlineFormat,ScanLineHeight,
      Selector,SeqNo,SiteId,SLSource,SrcEndPoint,SubSeqNo,SystemDate,SystemTime,Trancode,Tranno,UniqueID,
      UserData,UserDate1,UserDate2, UserFlag1, UserFlag2,UserFlag3,UserFlag4,UserFlag5, UserInteger1, 
      UserInteger2,UserInteger3,UserInteger4,UserInteger5, UserReal1, UserReal2,UserReal3,UserReal4,
      UserReal5, UserString1, UserString2,UserString3,UserString4, UserString5,VarianceAmt,WhlIDEDone,
      WhlStubInsertWtg,WorkSrc,TracerMatchCode,CnvAcctNo,UserInteger6,UserInteger7,UserInteger8,UserInteger9,
      UserInteger10,UserInteger11,UserInteger12,UserInteger13,UserInteger14,UserInteger15,UserReal6,UserReal7,
      UserReal8,UserReal9,UserReal10,UserReal11,UserReal12,UserReal13,UserReal14,UserReal15,UserString6,UserString7,
      UserString8,UserString9,UserString10,UserString11,UserString12,UserString13,UserString14,UserString15,
      UserString16,UserString17,UserString18,UserString19,UserString20,UserString21,UserString22,
      UserString23,UserString24,UserString25,UserFlag6,UserFlag7,UserFlag8,UserFlag9,UserFlag10,
      UserFlag11,UserFlag12,UserFlag13,UserFlag14,UserFlag15,UserFlag16,UserFlag17,UserFlag18,
      UserFlag19,UserFlag20,UserDate3,UserDate4,UserDate5,UserDate6,UserDate7,UserDate8,UserDate9,UserDate10
      FROM PSGTMS.Detailfile WITH (NOLOCK)
      WHERE SiteId    = @SiteId 
      AND BatchNo     = @BatchNo 
      AND DayOfDate   = @DayOfDate 
      AND ProcessDate = @ProcessDate 
      Order By Tranno, SeqNo, SubSeqNo
  End
  SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspUpdateBatchFileForImageDataRecognitionStager]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspUpdateBatchFileForImageDataRecognitionStager]
GO
CREATE PROCEDURE [PSGTMS].[uspUpdateBatchFileForImageDataRecognitionStager]
    @SiteId SmallInt,
    @BatchNo CHAR(10),
    @MatchOption tinyint,
    @ProcessDate CHAR(8),
    @SortPattern char(10),
    @StartTime char(6),
    @SystemDate char(8),
    @HasReviewTrans Bit,
    @WorkSrc char(10),
    @PrevPgmBatchVal Int,
    @BatchFixFlag char(1),
    @BatchSubMode Int,
    @BatchFixCode SmallInt,
    @BatchValue Int,
    @P1TrackType SmallInt,
    @WorkDate char(8),
    @DPMP1MachNo SmallInt,
    @DocsCarred SmallInt,
    @PrevBatchValue Int,
    @ReassignTran char(1),
    @Pass1Usercode Varchar(30),
    @ImageSeqNo SmallInt,
    @HardwareType SmallInt,
    @AvailDone char(1),
    @BatchKey bigInt ,   
    @StubCount Smallint,
    @CheckCount Smallint
	,@UserInteger1		Smallint
	,@UserInteger2		Smallint
	,@UserInteger3		Smallint
	,@UserReal1			Money
	,@UserReal2			Money
	,@UserReal3			Money
	,@UserString1		Varchar(16)
	,@UserString2		Varchar(16)
	,@UserData			Char(8)
	,@UserFlag1			Char(1)
	,@UserFlag2			Char(1)
	,@UserFlag3			Char(1)
	,@UserFlag4			Char(1)
	,@UserFlag5			Char(1)
	,@UserInteger4		Smallint
	,@UserInteger5		Smallint	
	,@UserReal4			Money
	,@UserReal5			Money
	,@UserString3		Varchar(16)
	,@UserString4		Varchar(16)
	,@UserString5		Varchar(16)
	,@UserDate1			Char(8)
	,@UserDate2			Char(8)
	,@UserFlag6			Char(1)
	,@UserFlag7			Char(1)
	,@UserFlag8			Char(1)
	,@UserFlag9			Char(1)
	,@UserFlag10		Char(1)	
	,@UserFlag11		Char(1)
	,@UserFlag12		Char(1)
	,@UserFlag13		Char(1)
	,@UserFlag14		Char(1)
	,@UserFlag15		Char(1)
	,@UserFlag16		Char(1)	
	,@UserFlag17		Char(1)
	,@UserFlag18		Char(1)
	,@UserFlag19		Char(1)
	,@UserFlag20		Char(1)    
 AS 
 BEGIN

	DECLARE @DayOfDate as SmallInt
	SET @DayOfDate = PSGTMS.GetDayOfDate(@SiteID, @ProcessDate) --Cast(SubString(@ProcessDate, 7, 2) as SmallInt)

	if LTRIM(RTRIM(@UserData)) = ''
	BEGIN
	select @UserData = UserData from PSGTMS.BATCHFILE where BatchKey=@BatchKey AND DayOfDate=@DayOfDate;
	END
	
	UPDATE PSGTMS.Batchfile SET 
		WorkSrc =@WorkSrc,
		MatchOption=@MatchOption,   
		SortPattern=@SortPattern, 
		StartTime=@StartTime, SystemDate=@SystemDate,  
		HasReviewTrans=@HasReviewTrans,
		PrevPgmBatchVal=@PrevPgmBatchVal, 
		BatchFixFlag=@BatchFixFlag,   
                	BatchSubMode=@BatchSubMode,
		BatchFixCode=@BatchFixCode, BatchValue=@BatchValue,
		P1TrackType=@P1TrackType,   
		WorkDate=@WorkDate,    DPMP1MachNo=@DPMP1MachNo,    
		DocsCarred=@DocsCarred, 
		ReassignTran=@ReassignTran, Pass1Usercode=@Pass1Usercode, 
		ImageSeqNo=@ImageSeqNo,
		HardwareType=@HardwareType,  
		AvailDone=@AvailDone,
		StubCount = @StubCount,
		CheckCount = @CheckCount,
		UserInteger1 = @UserInteger1	,
		UserInteger2 = @UserInteger2	,
		UserInteger3 = @UserInteger3	,
		UserReal1	 = @UserReal1		,
		UserReal2	 = @UserReal2		,
		UserReal3	 = @UserReal3		,
		UserString1 = @UserString1	,
		UserString2 = @UserString2	,
		UserData	 = @UserData		,
		UserFlag1	 = @UserFlag1		,
		UserFlag2	 = @UserFlag2		,
		UserFlag3	 = @UserFlag3		,
		UserFlag4	 = @UserFlag4		,
		UserFlag5	 = @UserFlag5		,
		UserInteger4 = @UserInteger4	,
		UserInteger5 = @UserInteger5	,
		UserReal4	 = @UserReal4		,
		UserReal5	 = @UserReal5		,
		UserString3 = @UserString3	,
		UserString4 = @UserString4	,
		UserString5 = @UserString5	,
		UserDate1	 = @UserDate1		,
		UserDate2	 = @UserDate2		,
		UserFlag6	 = @UserFlag6		,
		UserFlag7	 = @UserFlag7		,
		UserFlag8	 = @UserFlag8		,
		UserFlag9	 = @UserFlag9		,
		UserFlag10	 = @UserFlag10		,
		UserFlag11	 = @UserFlag11		,
		UserFlag12	 = @UserFlag12		,
		UserFlag13	 = @UserFlag13		,
		UserFlag14	 = @UserFlag14		,
		UserFlag15	 = @UserFlag15		,
		UserFlag16	 = @UserFlag16		,
		UserFlag17	 = @UserFlag17		,
		UserFlag18	 = @UserFlag18		,
		UserFlag19	 = @UserFlag19		,
		UserFlag20	 = @UserFlag20		    		
	WHERE 
		BatchKey=@BatchKey AND DayOfDate=@DayOfDate
END
GO

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspUpdateDetailFileForImageDataRecognitionStager]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspUpdateDetailFileForImageDataRecognitionStager]
GO
CREATE PROCEDURE [PSGTMS].[uspUpdateDetailFileForImageDataRecognitionStager]
(
     @ImageSeqNo Smallint,
     @Amount money,
	 @CARAmount money,
	 @Suspend tinyint,
	 @Reject smallint,
     @DayOfDate Smallint,
     @DetailKey bigint	 
	,@UserInteger1	Smallint
	,@UserInteger2	Smallint
	,@UserInteger3	Smallint
	,@UserInteger4	Smallint
	,@UserInteger5	Smallint
	,@UserInteger6	Int
	,@UserInteger7	Int
	,@UserInteger8	Int
	,@UserInteger9	Int
	,@UserInteger10	Int
	,@UserInteger11	Int
	,@UserInteger12	Int
	,@UserInteger13	Int
	,@UserInteger14	Int
	,@UserInteger15	Int
	,@UserData		Varchar(150)
	,@UserReal1		Money
	,@UserReal2		Money
	,@UserReal3		Money	
	,@UserReal4		Money
	,@UserReal5		Money
	,@UserReal6		Money	
	,@UserReal7		Money
	,@UserReal8		Money
	,@UserReal9		Money
	,@UserReal10	Money
	,@UserReal11	Money
	,@UserReal12	Money
	,@UserReal13	Money
	,@UserReal14	Money
	,@UserReal15	Money
	,@UserString1	Varchar(16)
	,@UserString2	Varchar(16)
	,@UserString3	Varchar(16)
	,@UserString4	Varchar(16)
	,@UserString5	Varchar(16)
	,@UserString6	Varchar(200)
	,@UserString7	Varchar(200)
	,@UserString8	Varchar(200)
	,@UserString9	Varchar(200)
	,@UserString10	Varchar(200)
	,@UserString11	Varchar(200)
	,@UserString12	Varchar(200)
	,@UserString13	Varchar(200)
	,@UserString14	Varchar(200)
	,@UserString15	Varchar(200)
	,@UserString16	Varchar(200)
	,@UserString17	Varchar(200)	
	,@UserString18	Varchar(200)
	,@UserString19	Varchar(200)
	,@UserString20	Varchar(200)
	,@UserString21	Varchar(200)
	,@UserString22	Varchar(200)
	,@UserString23	Varchar(200)
	,@UserString24	Varchar(200)
	,@UserString25	Varchar(200)
	,@UserFlag1		Char(1)
	,@UserFlag2		Char(1)
	,@UserFlag3		Char(1)
	,@UserFlag4		Char(1)
	,@UserFlag5		Char(1)
	,@UserFlag6		Char(1)
	,@UserFlag7		Char(1)
	,@UserFlag8		Char(1)
	,@UserFlag9		Char(1)
	,@UserFlag10	Char(1)	
	,@UserFlag11	Char(1)
	,@UserFlag12	Char(1)
	,@UserFlag13	Char(1)
	,@UserFlag14	Char(1)
	,@UserFlag15	Char(1)
	,@UserFlag16	Char(1)
	,@UserFlag17	Char(1)
	,@UserFlag18	Char(1)
	,@UserFlag19	Char(1)
	,@UserFlag20	Char(1)
	,@UserDate1		Char(8)
	,@UserDate2		Char(8)
	,@UserDate3		Char(8)
	,@UserDate4		Char(8)
	,@UserDate5		Char(8)
	,@UserDate6		Char(8)	
	,@UserDate7		Char(8)
	,@UserDate8		Char(8)
	,@UserDate9		Char(8)
	,@UserDate10	Char(8)	 
	,@ImageAction	tinyint	
	,@DDANumber		varchar(20)
	,@RejectReason  SmallInt,  
     @RejectPgm     smallInt,  
     @RejectUsercode Varchar(30)   
    ,@PCIEncryption bit -- 1 represents enabled , 0 represents disabled
)
 AS 
 BEGIN
SET NOCOUNT ON

	
			
    UPDATE PSGTMS.Detailfile1 	
		Set	ImageSeqno = @ImageSeqNo
    WHERE DetailKey=@DetailKey 
	AND DayOfDate=@DayOfDate  
	
		
    UPDATE PSGTMS.Detailfile2 
		SET UserInteger1 = @UserInteger1
				
 	WHERE DetailKey=@DetailKey 
	AND DayOfDate=@DayOfDate  		

SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspBulkInsertForImageDataRecognitionStager_JSON]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspBulkInsertForImageDataRecognitionStager_JSON]
GO
CREATE PROCEDURE [PSGTMS].[uspBulkInsertForImageDataRecognitionStager_JSON]
(
    @Siteid SMALLINT,
    @Batchno CHAR(10),
    @Processdate CHAR(8),
    @ImageDataRecogJson NVARCHAR(MAX), -- JSON input
    @ErrorNo INT OUTPUT,
    @Error_Msg VARCHAR(2048) OUTPUT
)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @ErrorNo = 0, @Error_Msg = 'Success';

    IF @ImageDataRecogJson IS NULL OR LTRIM(RTRIM(@ImageDataRecogJson)) = ''
    BEGIN
        SELECT @ErrorNo = 1, @Error_Msg = 'Image Data Recog JSON is blank';
        SET NOCOUNT OFF;
        RETURN;
    END

    DECLARE @dayofdate SMALLINT;
    BEGIN TRY
        SET @dayofdate = PSGTMS.GetDayOfDate(@SiteId, @ProcessDate);

        -- Parse JSON into table variable
        DECLARE @ImageDataRecogTable TABLE (
            SiteId SMALLINT,
            BatchNo CHAR(10),
            ProcessDate CHAR(8),
            DayOfDate SMALLINT,
            SeqNo INT,
            SubSeqNo SMALLINT,
            RecogProvider VARCHAR(20),
            [Date] VARCHAR(255),
            Amount VARCHAR(255),
            AmountWords VARCHAR(255),
            PayeeName VARCHAR(255),
            PayerName VARCHAR(255),
            PayerAddressLine1 VARCHAR(255),
            PayerAddressLine2 VARCHAR(255),
            [Signature] VARCHAR(255),
            Memo VARCHAR(255),
            MICR NVARCHAR(255),
            DateConfidence FLOAT,
            AmountConfidence FLOAT,
            AmountWordsConfidence FLOAT,
            PayeeNameConfidence FLOAT,
            PayerNameConfidence FLOAT,
            PayerAddressLine1Confidence FLOAT,
            PayerAddressLine2Confidence FLOAT,
            SignatureConfidence FLOAT,
            MemoConfidence FLOAT,
            MICRConfidence FLOAT
        );

        INSERT INTO @ImageDataRecogTable
        SELECT
            @Siteid,
            @Batchno,
            @Processdate,
            @dayofdate,
            Rec.[SeqNo],
            Rec.[SubSeqNo],
            Rec.[RecogProvider],
            Rec.[Date],
            Rec.[Amount],
            Rec.[AmountWords],
            Rec.[PayeeName],
            Rec.[PayerName],
            Rec.[PayerAddressLine1],
            Rec.[PayerAddressLine2],
            Rec.[Signature],
            Rec.[Memo],
            Rec.[MICR],
            Rec.[DateConfidence],
            Rec.[AmountConfidence],
            Rec.[AmountWordsConfidence],
            Rec.[PayeeNameConfidence],
            Rec.[PayerNameConfidence],
            Rec.[PayerAddressLine1Confidence],
            Rec.[PayerAddressLine2Confidence],
            Rec.[SignatureConfidence],
            Rec.[MemoConfidence],
            Rec.[MICRConfidence]
        FROM OPENJSON(@ImageDataRecogJson)
        WITH (
            SeqNo INT,
            SubSeqNo SMALLINT,
            RecogProvider VARCHAR(20),
            Date VARCHAR(255),
            Amount VARCHAR(255),
            AmountWords VARCHAR(255),
            PayeeName VARCHAR(255),
            PayerName VARCHAR(255),
            PayerAddressLine1 VARCHAR(255),
            PayerAddressLine2 VARCHAR(255),
            Signature VARCHAR(255),
            Memo VARCHAR(255),
            MICR NVARCHAR(255),
            DateConfidence FLOAT,
            AmountConfidence FLOAT,
            AmountWordsConfidence FLOAT,
            PayeeNameConfidence FLOAT,
            PayerNameConfidence FLOAT,
            PayerAddressLine1Confidence FLOAT,
            PayerAddressLine2Confidence FLOAT,
            SignatureConfidence FLOAT,
            MemoConfidence FLOAT,
            MICRConfidence FLOAT
        ) AS Rec;

        BEGIN TRAN;

        -- Remove existing records for this batch
        IF EXISTS (
            SELECT 1 FROM PSGTMS.tblImageDataRecognition WITH (NOLOCK)
            WHERE siteid = @Siteid
              AND batchno = @Batchno
              AND ProcessDate = @Processdate
              AND dayofdate = @dayofdate
        )
        BEGIN
            DELETE FROM PSGTMS.tblImageDataRecognition
            WHERE siteid = @Siteid
              AND batchno = @Batchno
              AND ProcessDate = @Processdate
              AND dayofdate = @dayofdate;
        END

        -- Insert new records
        INSERT INTO PSGTMS.tblImageDataRecognition (
            SiteId, BatchNo, ProcessDate, DayOfDate, SeqNo, SubSeqNo, RecogProvider, [Date], Amount, AmountWords,
            PayeeName, PayerName, PayerAddressLine1, PayerAddressLine2, [Signature], Memo, MICR, DateConfidence,
            AmountConfidence, AmountWordsConfidence, PayeeNameConfidence, PayerNameConfidence, PayerAddressLine1Confidence,
            PayerAddressLine2Confidence, SignatureConfidence, MemoConfidence, MICRConfidence
        )
        SELECT
            SiteId, BatchNo, ProcessDate, DayOfDate, SeqNo, SubSeqNo, RecogProvider, [Date], Amount, AmountWords,
            PayeeName, PayerName, PayerAddressLine1, PayerAddressLine2, [Signature], Memo, MICR, DateConfidence,
            AmountConfidence, AmountWordsConfidence, PayeeNameConfidence, PayerNameConfidence, PayerAddressLine1Confidence,
            PayerAddressLine2Confidence, SignatureConfidence, MemoConfidence, MICRConfidence
        FROM @ImageDataRecogTable;

        COMMIT TRAN;
    END TRY
    BEGIN CATCH
        IF (@@TRANCOUNT > 0)
            ROLLBACK TRAN;
        SELECT @ErrorNo = ERROR_NUMBER(), @Error_Msg = ERROR_MESSAGE();
    END CATCH

    SET NOCOUNT OFF;
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspUpdateOCRConfig]') AND type in (N'P', N'PC'))
DROP PROCEDURE [PSGTMS].[uspUpdateOCRConfig]
GO
Create Procedure [PSGTMS].[uspUpdateOCRConfig]   
(   
 @SiteID   smallint,  
 @WorkSource  char(10),
 @ItemType smallint,
 @EngineType  varchar(30),
 @CoOrdinates varchar(20) 
)  
As  
Begin     
 Set Nocount ON  
 Update PSGTMS.tblOCRConfig set CoOrdinates = @CoOrdinates where SiteID = @SiteID 
 and WorkSource = @WorkSource and ItemType = @ItemType and EngineType = @EngineType 
 Set Nocount OFF 
End
Go