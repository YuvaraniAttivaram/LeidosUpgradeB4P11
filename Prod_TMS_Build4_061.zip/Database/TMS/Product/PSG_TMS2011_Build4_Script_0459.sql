
IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[tblImageDataRecognition]') AND type in (N'U'))
DROP TABLE [PSGTMS].[tblImageDataRecognition]
GO

CREATE TABLE [PSGTMS].[tblImageDataRecognition](
	[RecogId]						[bigint] IDENTITY(1,1) NOT NULL,
	[SiteId]						[smallint] NOT NULL,
	[BatchNo]						[char](10) NOT NULL,
	[ProcessDate]					[char](8) NOT NULL,
	[DayOfDate]						[smallint] NOT NULL,
	[SeqNo]							[int] NOT NULL,
	[SubSeqNo]						[smallint] NOT NULL,
	[RecogProvider]					[varchar](20) NOT NULL,
	[Date]							[varchar](255) NULL,
	[Amount]						[varchar](255) NULL,
	[AmountWords]					[varchar](255) NULL,
	[PayeeName]						[varchar](255) NULL,
	[PayerName]						[varchar](255) NULL,
	[PayerAddressLine1]				[varchar](255) NULL,
	[PayerAddressLine2]				[varchar](255) NULL,
	[Signature]						[varchar](255) NULL,
	[Memo]							[varchar](255) NULL,
	[MICR]							[nvarchar](255) NULL,
	[DateConfidence]				[float] NULL,
	[AmountConfidence]				[float] NULL,
	[AmountWordsConfidence]			[float] NULL,
	[PayeeNameConfidence]			[float] NULL,
	[PayerNameConfidence]			[float] NULL,
	[PayerAddressLine1Confidence]	[float] NULL,
	[PayerAddressLine2Confidence]	[float] NULL,
	[SignatureConfidence]			[float] NULL,
	[MemoConfidence]				[float] NULL,
	[MICRConfidence]				[float] NULL,
	[UserString1]					[varchar](255) NULL,
	[UserString2]					[varchar](255) NULL,
	[UserString3]					[varchar](255) NULL,
	[UserInteger1]					[bigint] NULL,
	[UserInteger2]					[bigint] NULL,
	[UserInteger3]					[bigint] NULL,
	[UserChar1]						[char](1) NULL,
	[UserChar2]						[char](1) NULL,
	[UserChar3]						[char](1) NULL,
	CONSTRAINT PK_tblImageDataRecognition PRIMARY KEY NONCLUSTERED 
	(
		[SiteId]		ASC,	
		[BatchNo]		ASC,
		[SeqNo]			ASC,
		[SubSeqNo]		ASC,
		[ProcessDate]	ASC,
		[DayOfDate]		ASC
	) With(Fillfactor = 70) ON #PARTITIONSCHEMETRANSACTION#
) ON #PARTITIONSCHEMETRANSACTION#
GO
CREATE CLUSTERED INDEX CI_tblImageDataRecognition ON [PSGTMS].[tblImageDataRecognition]
(
	[RecogId] ASC,
	[DayOfDate]	ASC
) With(Fillfactor = 80) ON #PARTITIONSCHEMETRANSACTION#
GO
