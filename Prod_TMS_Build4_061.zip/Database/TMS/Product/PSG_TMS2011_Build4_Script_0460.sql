Delete from PSGTMS.tblPgmConfigOptions where optionkey in (2308,2309)
GO
Insert into PSGTMS.tblPgmConfigOptions Values (0,2308)
Insert into PSGTMS.tblPgmConfigOptions Values (0,2309)
Go

Delete from PSGTMS.tblPgmConfigOptions where optionkey in (2310,2311)
GO
Insert into PSGTMS.tblPgmConfigOptions Values (0,2310)
Insert into PSGTMS.tblPgmConfigOptions Values (0,2311)
Go

Delete from PSGTMS.tblPgmConfigOptions where optionkey = 2312
GO
Insert into PSGTMS.tblPgmConfigOptions Values (0,2312)
Go