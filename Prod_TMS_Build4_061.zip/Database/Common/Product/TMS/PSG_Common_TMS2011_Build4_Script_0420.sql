DELETE From PSGTMS.tblOptionsForStagerNo  Where Stagerno = 337 and Optionkey = 2307
GO
Insert into PSGTMS.tblOptionsForStagerNo  values (337,2307)
GO