IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[UspGetImageAnnotationConfig]') AND type in (N'P', N'PC'))
DROP PROCEDURE [PSGTMS].[UspGetImageAnnotationConfig]
GO
CREATE PROCEDURE [PSGTMS].[UspGetImageAnnotationConfig] 
(
	@WorkSource char(10),
	@BatchMode int,
	@ProgramId int
)
AS
BEGIN
	SET NOCOUNT ON;
	
	Declare @BankId int
	
	select @BankId = BankID from PSGTMS.WorkSrcDesc WITH (NOLOCK)
	Where WorkSource = @WorkSource  
	And SiteID >=0   
	
	IF OBJECT_ID('tempdb.Dbo.#TempAnnotation') IS NOT NULL
		DROP TABLE #TempAnnotation
	
	IF OBJECT_ID('tempdb.Dbo.#ResultAnnotation') IS NOT NULL
		DROP TABLE #ResultAnnotation
		
	CREATE TABLE #TempAnnotation
	(
		AnnotateId Bigint, WorkSource char(10), BatchMode int, LineNum Smallint, ItemType Smallint, 
		ImageType Char(1), XAxis Smallint, YAxis Smallint, RotateAngle int, BottomRightCorner char(1),
		FontName Varchar(30), FontSize float, BoldFont Char(1), SchemeDefinition Varchar(200),BankId int
	)	
	
	CREATE TABLE #ResultAnnotation
	(
		AnnotateId Bigint, WorkSource char(10), BatchMode int, LineNum Smallint, ItemType Smallint, 
		ImageType Char(1), XAxis Smallint, YAxis Smallint, RotateAngle int, BottomRightCorner char(1),
		FontName Varchar(30), FontSize float, BoldFont Char(1), SchemeDefinition Varchar(200)
	)
	
	Insert INTO #TempAnnotation 
	(
		AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition,BankId 
	)	
	SELECT Annotate.AnnotateId, Annotate.WorkSource, Annotate.BatchMode, detail.LineNum,   
			detail.ItemType, detail.ImageType, detail.XAxis, detail.YAxis, detail.RotateAngle, detail.BottomRightCorner,   
			detail.FontName, detail.FontSize, detail.BoldFont, detail.SchemeDefinition,Annotate.BankId  
	FROM PSGTMS.tblAnnotation Annotate WITH (NOLOCK) INNER JOIN  
	PSGTMS.tblAnnotationDetail detail WITH (NOLOCK) 
	ON Annotate.AnnotateId = detail.AnnotateId  
	WHERE Annotate.WorkSource in('0000000000',@WorkSource)
	AND Annotate.BatchMode in(0,@BatchMode)
	AND detail.ItemType in(0,1,200)
	AND Annotate.BankId in (0,@BankId)   
	AND Annotate.AnnotateId > 0
	AND ProgramId in (0,@ProgramId)

	--Check

	IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=@BatchMode AND ItemType=0)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = @BatchMode AND ItemType = 0
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=0 AND ItemType=0)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = 0 AND ItemType = 0
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=0 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 0 AND BankId = @BankId 
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=0 AND ItemType=0 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = 0 AND ItemType = 0 And BankId = @BankId
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=0 And BankId = 0)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 0 And BankId = 0 
	END
	ELSE
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = '0000000000' AND BatchMode = 0 AND ItemType = 0 And BankId = 0
	END

	--Stub

	IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=@BatchMode AND ItemType=1)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = @BatchMode AND ItemType = 1
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=0 AND ItemType=1)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = 0 AND ItemType = 1
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=1 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 1 And BankId = @BankId  
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=0 AND ItemType=1 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = 0 AND ItemType = 1 And BankId = @BankId  
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=1 And BankId = 0)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 1 And BankId = 0  
	END
	ELSE
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)		
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = '0000000000' AND BatchMode = 0 AND ItemType = 1 And BankId = 0  
	END
	
	--Batch Header

	IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=@BatchMode AND ItemType=200)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = @BatchMode AND ItemType = 200
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource =@WorkSource AND BatchMode=0 AND ItemType=200)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = @WorkSource AND BatchMode = 0 AND ItemType = 200
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=200 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 200 AND BankId = @BankId 
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=0 AND ItemType=200 And BankId = @BankId)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = 0 AND ItemType = 200 And BankId = @BankId
	END
	ELSE IF EXISTS(SELECT 'X' FROM #TempAnnotation WHERE WorkSource ='0000000000' AND BatchMode=@BatchMode AND ItemType=200 And BankId = 0)
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource ='0000000000' AND BatchMode = @BatchMode AND ItemType = 200 And BankId = 0 
	END
	ELSE
	BEGIN
		Insert INTO #ResultAnnotation 
		(
			AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
		)
		SELECT AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
		BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition   
		FROM #TempAnnotation 
		WHERE WorkSource = '0000000000' AND BatchMode = 0 AND ItemType = 200 And BankId = 0
	END
	
	SELECT	AnnotateId, WorkSource, BatchMode, LineNum, ItemType, ImageType, XAxis, YAxis, RotateAngle, 
			BottomRightCorner, FontName, FontSize, BoldFont, SchemeDefinition
	FROM	#ResultAnnotation
	ORDER BY ItemType,LineNum		
	SET NOCOUNT OFF;
END
GO
