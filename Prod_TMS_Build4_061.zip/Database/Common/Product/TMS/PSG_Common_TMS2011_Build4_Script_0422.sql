IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspGetFormatsFromCustDataEntFileForRules]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspGetFormatsFromCustDataEntFileForRules]
GO

CREATE Procedure [PSGTMS].[uspGetFormatsFromCustDataEntFileForRules]      
(                      
 @SiteID  SmallInt,      
 @WorkSource Char(10),      
 @PgmNo  SmallInt      
)                      
As                      
Begin                   
 SET NOCOUNT ON                    
 Declare @SelectPgm     VarChar(10),      
   @ScanFixPgm     VarChar(10),      
   @WireBasketAssigned   Char(1),       
   @DuplicateReviewAssigned Char(1)        
        
 Set @ScanFixPgm = '7'        
      
 IF OBJECT_ID('tempdb.dbo.#SelectedPgmNo') IS NOT NULL      
 Begin      
  Drop Table #SelectedPgmNo      
 End      
 IF OBJECT_ID('tempdb.dbo.#ScanFixPgm') IS NOT NULL      
 Begin      
  Drop Table #ScanFixPgm      
 End      
       
 Create Table #SelectedPgmNo(Pgmno Smallint Primary Key)       
 Create Table #ScanFixPgm(Pgmno Smallint Primary Key)      
         
 If Not Exists(        
    Select 'x'       
    From PSGTMS.tblCustDataEntItems With (NoLock)        
    Where ProgramNum = 7       
    and ItemType = 1        
    And WorkSource in (@WorkSource,'0000000000')        
    And FormatId  >0      
    )        
 Begin        
  Set @ScanFixPgm = '7,501'        
 End        
       
 Insert into #ScanFixPgm(Pgmno)      
 Select Distinct ITEMS from PSGTMS.SPLIT(@ScanFixPgm,',')      
       
 Select @SelectPgm  = Case When @PgmNo in (5,257,228,37,177)       
       Then Cast(@PgmNo as Varchar(10))+ ',' + @ScanFixPgm      
       Else Cast(@PgmNo as Varchar(10))         
      End        
      
        
 Insert into #SelectedPgmNo(Pgmno)      
 Select Distinct ITEMS from PSGTMS.SPLIT(@SelectPgm,',')      
      
 If @PgmNo = 5                
 Begin              
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType ,T.Orientation as 'Orientation',C.Delchars                
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Where C.WorkSource = @WorkSource           
  And C.Siteid in (0,@Siteid)          
  and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId  as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                           
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId            
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid  in (0,@Siteid)          
  And C.PgmNo   in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
  And C.FormatNo Not In           
       (          
       Select Distinct TC.FormatNo        
       From   PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)          
       Where TC.WorkSource = @WorkSource --Specific WorkSoruce        
       And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
       And TC.FormatId >0        
       )          
  And T.FormatId >0        
  Order by C.FormatNo , C.FieldNo             
 End            
 Else          
 If @PgmNo = 257                
 Begin              
  If Exists (Select 'X' from PSGTMS.tblCustDataEntItems With (NOLOCK) Where ProgramNum = 257 and WorkSource  in (@WorkSource,'0000000000') And FormatId > 0)        
  Begin        
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId             
   Where C.WorkSource = @WorkSource           
   And C.Siteid in (0,@Siteid)          
   and C.PgmNo  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
   Union All          
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId            
   Where C.WorkSource = '0000000000' --All WorkSoruce          
   And C.Siteid in (0,@Siteid)          
   And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
   And C.FormatNo Not In           
        (          
        Select Distinct TC.FormatNo        
        From   PSGTMS.tblCustDataEntItems TC  With (Index(1),NOLOCK)          
        Where TC.WorkSource = @WorkSource --Specific WorkSoruce        
        And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
        And TC.FormatId >0        
        )        
   And T.FormatId>0        
   Order by C.FormatNo , C.FieldNo          
  End     
  Else        
  Begin        
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',        
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId             
   Where C.WorkSource = @WorkSource           
   And C.Siteid in (0,@Siteid)          
   and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
   Union All          
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
       T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)         
   On C.FormatId = T.FormatId            
   Where C.WorkSource = '0000000000' --All WorkSoruce          
   And C.Siteid in (0,@Siteid)          
   And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
   And C.FormatNo Not In           
        (          
        Select Distinct TC.FormatNo        
        From PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)          
        Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
        And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
        And TC.FormatID > 0        
        )        
   And T.FormatId>0      
   Order by C.FormatNo , C.FieldNo             
  End        
 End           
 Else If @PgmNo = 228                
 Begin            
  If Exists (Select 'X' from PSGTMS.tblCustDataEntItems With (NOLOCK) Where FormatId > 0 and ProgramNum = 228 and WorkSource  in (@WorkSource,'0000000000'))        
  Begin        
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId             
   Where C.WorkSource = @WorkSource           
   And C.Siteid in (0,@Siteid)          
   and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)            
   Union All          
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
        T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)          
   On C.FormatId = T.FormatId            
   Where C.WorkSource = '0000000000' --All WorkSoruce          
   And C.Siteid in (0,@Siteid)          
   And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
   And C.FormatNo Not In           
        (          
        Select Distinct TC.FormatNo        
        From PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)          
        Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
        And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
        And TC.FormatID > 0        
        )        
   And T.FormatId > 0        
   Order by C.FormatNo , C.FieldNo          
  End        
  Else         
  Begin        
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId             
   Where C.WorkSource = @WorkSource           
   And C.Siteid in (0,@Siteid)          
   and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
   Union All          
   Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
    C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
    C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
    C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
    C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
    C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
    C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
       T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
   From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
   Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
   On C.FormatId = T.FormatId            
   Where C.WorkSource = '0000000000' --All WorkSoruce          
   And C.Siteid in (0,@Siteid)          
   And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
   And C.FormatNo Not In           
        (          
        Select DISTINCT TC.FormatNo        
        From PSGTMS.tblCustDataEntItems TC With (INDEX(1),NOLOCK)          
        Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
        And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
        And TC.FormatID >0        
        )        
   And T.FormatId >0      
   Order by C.FormatNo , C.FieldNo           
  End           
 End      
 Else If @PgmNo = 37               
 Begin              
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Where C.WorkSource = @WorkSource           
  And C.Siteid in (0,@Siteid)          
  and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId            
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid in (0,@Siteid)          
  And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
  And C.FormatNo Not In           
       (          
       Select TC.FormatNo          
       From  PSGTMS.tblCustDataEntItems TC With (INDEX(1), NOLOCK)            
       Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
       And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
       And TC.FormatID >= 0        
       )        
  And T.FormatId >= 0        
  Order by C.FormatNo , C.FieldNo                 
 End             
 ELSE If @PgmNo = 177               
 Begin              
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                            
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Where C.WorkSource = @WorkSource           
  And C.Siteid in (0,@Siteid)      
  and C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)      
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId            
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid in (0,@Siteid)          
  And C.PgmNo in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
  And C.FormatNo Not In           
       (          
       Select distinct TC.FormatNo          
       From PSGTMS.tblCustDataEntItems TC With (INDEX(1), NOLOCK)            
       Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
       And TC.ProgramNum  in (Select PT.Pgmno From #SelectedPgmNo PT With(nolock) Where PT.Pgmno>=0)              
       And TC.FormatID >= 0          
       )          
  And T.FormatID >= 0            
  Order by C.FormatNo , C.FieldNo                 
 End            
 Else If @PgmNo <> 0             
 Begin              
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,             
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Where C.WorkSource = @WorkSource           
  And C.Siteid in (0,@Siteid)          
  and C.PgmNo = @PgmNo           
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId            
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid in (0,@Siteid)          
  And C.PgmNo = @PgmNo          
  And C.FormatNo Not In      
       (          
       Select Distinct TC.FormatNo        
       From PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)          
       Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
       And TC.ProgramNum  = @PgmNo          
       And TC.FormatID > 0        
       )          
  And T.FormatId >0        
  Order by C.FormatNo , C.FieldNo                
  End          
  Else --Pgmno =0          
  Begin          
  Select @WireBasketAssigned ='Y', @DuplicateReviewAssigned = 'Y'        
      
  If Not Exists(        
     Select 'x' From PSGTMS.tblCustDataEntItems With (NoLock)        
     Where ProgramNum = 257 -- WireBasket        
     And WorkSource in (@WorkSource,'0000000000')        
     And FormatId > 0      
     )        
  Begin        
   Set @WireBasketAssigned = 'N'        
  End        
      
  If Not Exists(        
     Select 'x' From PSGTMS.tblCustDataEntItems With (NoLock)        
     Where ProgramNum = 228 -- Duplicate Review        
     And WorkSource in (@WorkSource,'0000000000')        
     And FormatId  > 0      
     )        
  Begin        
   Set @DuplicateReviewAssigned = 'N'        
  End        
      
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', C.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',    
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Where C.WorkSource  = @WorkSource          
  And C.Siteid in (0,@Siteid)          
  And C.Pgmno > 0          
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', C.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId            
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid in (0,@Siteid)          
  And C.PgmNo > 0             
  And C.FormatNo Not In           
       (          
       Select Distinct CD.FormatNo        
       From PSGTMS.tblCustDataEntItems CD With (Index(1),NOLOCK)          
       Where CD.WorkSource = @WorkSource --Specific WorkSoruce        
       And CD.ProgramNum  = C.pgmNo        
       And CD.FormatID >= 0        
       )          
  And C.Siteid >= 0      
  Union All      
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', P.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Cross Join (Select 5 As 'Pgmno' Union Select 228 Union Select 37 Union Select 177 Union Select 257) as P          
  Where C.WorkSource = @WorkSource          
  And C.Siteid in (0,@Siteid)          
  And C.Pgmno in (Select SF.Pgmno From #ScanFixPgm SF With(nolock) Where SF.Pgmno>=0)      
  Union All           
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', P.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Cross Join (        
     Select Case When @WireBasketAssigned = 'N' Then 257 End As 'Pgmno'        
     )as P          
  Where C.WorkSource = @WorkSource          
  And C.Siteid in (0,@Siteid)          
  And T.ProgramNum = 5 -- BatchEdit              
  And @WireBasketAssigned = 'N'        
  Union All           
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', P.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
      T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Cross Join (        
     Select Case When @DuplicateReviewAssigned = 'N' Then 228 End As 'Pgmno'        
     ) as P          
  Where C.WorkSource = @WorkSource          
  And C.Siteid in (0,@Siteid)          
  And T.ProgramNum = 5 -- BatchEdit           
  And @DuplicateReviewAssigned = 'N'         
  Union All          
  Select @SiteID as 'SiteID', C.CustNo, @WorkSource as 'WorkSource', P.Pgmno, C.FormatNo,                    
   C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,                    
   C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,                    
   C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,                    
   C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,                    
   C.MaskFormat, C.DisabledFlag, C.RegularExpression, IsNull(C.CropImageAttributes,'') as 'CropImageAttributes',                  
   C.FormatId,C.EarlyStart ,C.LateStart ,IsNull(C.CDVScheme,0) as 'CDVScheme', IsNull(T.CDVScheme,0) as 'FormatCDV',T.AccountLookUpId as 'AccountLookUpId',          
    T.LookupDBObjectId as 'LookupDBObjectId',T.FormatName,C.ControlType,T.Orientation as 'Orientation',C.Delchars                                 
  From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)        
  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)                   
  On C.FormatId = T.FormatId             
  Cross Join (Select 5 As 'Pgmno' Union Select 228 Union Select 37 Union Select 177 Union Select 257) as P          
  Where C.WorkSource = '0000000000' --All WorkSoruce          
  And C.Siteid in (0,@Siteid)          
  And C.PgmNo in (Select SF.Pgmno From #ScanFixPgm SF With(nolock) Where SF.Pgmno>=0)      
  And C.FormatNo Not In           
       (          
       Select Distinct TC.FormatNo        
       From   PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)          
       Where TC.WorkSource = @WorkSource --Specific WorkSoruce          
       And TC.ProgramNum  in (Select SF.Pgmno From #ScanFixPgm SF With(nolock) Where SF.Pgmno>=0)      
       And TC.FormatID>0        
       )          
  And T.FormatID > 0            
  Order by C.Pgmno,C.FormatNo , C.FieldNo           
   End             
      
 IF OBJECT_ID('tempdb.dbo.#SelectedPgmNo') IS NOT NULL      
 Begin      
  Drop Table #SelectedPgmNo      
 End      
 IF OBJECT_ID('tempdb.dbo.#ScanFixPgm') IS NOT NULL      
 Begin      
  Drop Table #ScanFixPgm      
 End      
  SET NOCOUNT OFF                    
 End 
Go

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspGetFormatsAndDSFromCustDataEntFileForRules]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspGetFormatsAndDSFromCustDataEntFileForRules]
GO
Create Procedure [PSGTMS].[uspGetFormatsAndDSFromCustDataEntFileForRules]
(
		@SiteID			SmallInt,
		@WorkSource Char(10),
		@PgmNo			SmallInt
)
as 
Begin 
SET NOCOUNT ON
	IF  Object_Id('tempdb.dbo.#testcustdata') IS NOT NULL
	Begin
		DROP Table #testcustdata
	End

	CREATE TABLE #testcustdata
	(
		[SiteID] [smallint] ,
		[CustNo] [int] ,
		[WorkSource] [char](10) ,
		[Pgmno] [smallint] ,
		[FormatNo] [smallint] ,
		[FieldNo] [tinyint] ,
		[JBFieldNo] [smallint] ,
		[Description] [varchar](100) ,
		[DataType] [varchar](5) ,
		[RequiredFlag] [char](1) ,
		[Length] [smallint] ,
		[PCFieldNo] [smallint] ,
		[ItemType] [smallint] ,
		[HiddenFlag] [char](1) ,
		[PurposeCode] [tinyint] ,
		[RightJustify] [char](1) ,
		[PadChar] [char](1) ,
		[TrimBlanks] [char](1) ,
		[FontName] [varchar](30) ,
		[FontSize] [tinyint] ,
		[BoldFont] [char](1) ,
		[DefValue] [varchar](20) ,
		[GroupId] [smallint] ,
		[BalType] [char](1) ,
		[EncryptFlag] [char](1) ,
		[MaskFormat] [varchar](20) ,
		[DisabledFlag] [char](1) ,
		[RegularExpression] [varchar](100) ,
		[CropImageAttributes] [varchar](20) ,
		[FormatId] [bigint] ,
		[EarlyStart] [int] ,
		[LateStart] [int] ,
		[CDVScheme] [bigint] ,
		[FormatCDV] [bigint] ,
		[AccountLookUpId] [bigint] ,
		[LookupDBObjectId] [int] ,
		[FormatName] [varchar](250),
		[ControlType] [Tinyint],
		[Orientation] [char](1),    
		[Delchars] [VARCHAR](100)    
	) ON [PRIMARY]
	Create Clustered index CI_#testcustdata ON #testcustdata (FormatNo)

	Insert into #testcustdata (SiteID,CustNo,WorkSource,Pgmno,FormatNo,FieldNo,JBFieldNo,[Description],DataType,RequiredFlag,[Length],PCFieldNo,ItemType,HiddenFlag,PurposeCode,RightJustify,
				PadChar,TrimBlanks,FontName,FontSize,BoldFont,DefValue,GroupId,BalType,EncryptFlag,MaskFormat,DisabledFlag,RegularExpression,CropImageAttributes,FormatId,EarlyStart,LateStart,CDVScheme,
    FormatCDV,AccountLookUpId,LookupDBObjectId,FormatName,ControlType,Orientation,Delchars      
				)
	-- Calling SP, This SP need to change, whenever calling SP column result set change. 
	-- All new column changes at the end of above #temp table onwards.
	Exec [PSGTMS].[uspGetFormatsFromCustDataEntFileForRules] @SiteID,@WorkSource, @PgmNo
	
	Select * From #testcustdata

	Select	Distinct
				A.[FormatId] ,
				A.[PCFieldNo] ,
				A.[DisplayField] ,
				A.[ValueField] ,
				B.FormatNo,
				B.FieldNo,
				A.SNo 
	From [PSGTMS].[tblCustDataEntDataSource] A With(Nolock)
	Inner Join #testcustdata B With(Nolock)
	ON A.FormatId = B.FormatId
	And A.PCFieldNo = B.PCFieldNo
	Where A.FormatId>=0
	ORDER BY B.FormatNo, B.FieldNo,A.SNo 

	IF  Object_Id('tempdb.dbo.#testcustdata') IS NOT NULL 
	Begin
		DROP Table #testcustdata
	End

SET NOCOUNT Off
END
GO

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspGetFormatsFromCustDataEntFileForStagerRules]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspGetFormatsFromCustDataEntFileForStagerRules]
GO

CREATE Procedure [PSGTMS].[uspGetFormatsFromCustDataEntFileForStagerRules]
(            
	@SiteID		SmallInt,            
	@WorkSource Char(10),            
	@PgmNo		SmallInt            
)            
As            
Begin         
 SET NOCOUNT ON          
	IF OBJECT_ID('tempdb.dbo.#PgmNo') IS NOT NULL
	Begin
		Drop Table #PgmNo
	End
	Create Table #Pgmno(Pgmno Smallint Primary Key)
	
	Insert into #Pgmno(Pgmno)
	Select @PgmNo
		
	If @PgmNo = 7 
	Begin
		If Not Exists(  
						Select 'x' 
						From PSGTMS.tblCustDataEntItems With (NoLock)
						Where ProgramNum= 7 
						and ItemType	= 1
						And WorkSource	IN (@WorkSource,'0000000000')
						And FormatId	> 0
						)
			Begin
				Insert into #Pgmno(Pgmno)
				Select 501
			End
	End   

	Select @SiteID as 'SiteId', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,          
			C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,          
			C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,          
			C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,          
			C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,          
			C.MaskFormat, C.DisabledFlag, C.RegularExpression, C.CropImageAttributes,        
			C.FormatId,C.EarlyStart ,C.LateStart ,C.CDVScheme, T.CDVScheme as 'FormatCDV', C.CompressSymbols, C.ControlType ,T.Orientation,C.DelChars
	From PSGTMS.CUSTDATAENTFILE C With (Index(1),NOLOCK)  
	Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)         
	On C.FormatId = T.FormatId   
	Where C.WorkSource	= @WorkSource  
	And C.Siteid		IN (0,@siteID)  
	And C.Pgmno			IN (Select PT.Pgmno From #Pgmno PT With(nolock) Where PT.Pgmno>=0)
	And C.Siteid		>= 0
	Union All
	Select @SiteID as 'SiteId', C.CustNo, @WorkSource as 'WorkSource', @Pgmno as 'Pgmno', C.FormatNo,          
			C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,          
			C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,          
			C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,          
			C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,          
			C.MaskFormat, C.DisabledFlag, C.RegularExpression, C.CropImageAttributes,        
			C.FormatId,C.EarlyStart ,C.LateStart ,C.CDVScheme, T.CDVScheme as 'FormatCDV', C.CompressSymbols, C.ControlType  ,T.Orientation,C.DelChars    
	From PSGTMS.CUSTDATAENTFILE C With (NOLOCK)  
	Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)         
	On C.FormatId = T.FormatId
	Where C.WorkSource	= '0000000000'  
	And C.Siteid		IN (0,@siteID)
	And C.Pgmno			IN  (Select PT.Pgmno From #Pgmno PT With(nolock) Where PT.Pgmno>=0)
	And T.FormatId		> 0
	And C.FormatNo		Not In   
							(
								Select Distinct TC.FormatNo  
								From PSGTMS.tblCustDataEntItems TC With (Index(1),NOLOCK)    
								Where TC.WorkSource = @WorkSource --Specific WorkSoruce  
								And TC.ProgramNum  IN (Select PT.Pgmno From #Pgmno PT With(nolock) Where PT.Pgmno>=0)
								And TC.FormatNo		>=0
								And TC.FormatId		> 0
							)
	And C.Siteid >= 0    
	Order by C.FormatNo,C.EarlyStart
  
	IF OBJECT_ID('tempdb.dbo.#PgmNo') IS NOT NULL
	Begin
		Drop Table #PgmNo
	End
 SET NOCOUNT OFF          
End     
GO

IF  EXISTS (SELECT 'x' FROM sys.objects WHERE object_id = OBJECT_ID(N'[PSGTMS].[uspGetFormatsFromCustDataEntFile]') AND type ='P')
DROP PROCEDURE [PSGTMS].[uspGetFormatsFromCustDataEntFile]
GO

CREATE Procedure [PSGTMS].[uspGetFormatsFromCustDataEntFile]  
(  
	@SiteID			SmallInt,  
	@WorkSource Char(10),  
	@PgmNo	SmallInt  
)  
As  
Begin  
	SET NOCOUNT ON

		IF  Object_Id('tempdb.dbo.#testcustdata') IS NOT NULL
	Begin
		DROP Table #testcustdata
	End

	CREATE TABLE #testcustdata
	(
		[SiteID] [smallint] ,
		[CustNo] [int] ,
		[WorkSource] [char](10) ,
		[Pgmno] [smallint] ,
		[FormatNo] [smallint] ,
		[FieldNo] [tinyint] ,
		[JBFieldNo] [smallint] ,
		[Description] [varchar](100) ,
		[DataType] [varchar](5) ,
		[RequiredFlag] [char](1) ,
		[Length] [smallint] ,
		[PCFieldNo] [smallint] ,
		[ItemType] [smallint] ,
		[HiddenFlag] [char](1) ,
		[PurposeCode] [tinyint] ,
		[RightJustify] [char](1) ,
		[PadChar] [char](1) ,
		[TrimBlanks] [char](1) ,
		[FontName] [varchar](30) ,
		[FontSize] [tinyint] ,
		[BoldFont] [char](1) ,
		[DefValue] [varchar](20) ,
		[GroupId] [smallint] ,
		[BalType] [char](1) ,
		[EncryptFlag] [char](1) ,
		[MaskFormat] [varchar](20) ,
		[DisabledFlag] [char](1) ,
		[RegularExpression] [varchar](100) ,
		[CropImageAttributes] [varchar](20) ,
		[AccountLookUpId] [bigint] ,
		[LookupDBObjectId] [int] ,
		[FormatName] [varchar](250),
		[FormatId] [bigint] ,
		[ControlType] [Tinyint],
		[Orientation]   [char](1),
		[Delchars] VARCHAR(100)
	) ON [PRIMARY]
	Create Clustered index CI_#testcustdata ON #testcustdata (FormatNo)

	Insert into #testcustdata (SiteID,CustNo,WorkSource,Pgmno,FormatNo,FieldNo,JBFieldNo,[Description],DataType,RequiredFlag,[Length],PCFieldNo,ItemType,HiddenFlag,PurposeCode,RightJustify,
				PadChar,TrimBlanks,FontName,FontSize,BoldFont,DefValue,GroupId,BalType,EncryptFlag,MaskFormat,DisabledFlag,RegularExpression,CropImageAttributes,
				AccountLookUpId,LookupDBObjectId,FormatName,FormatId,ControlType,Orientation,Delchars 
				)
	Select       
	  C.SiteId, C.CustNo, @WorkSource as 'WorkSource',  C.Pgmno, C.FormatNo,      
	  C.FieldNo, C.JBFieldNo, C.[Description], C.DataType, C.RequiredFlag,      
	  C.[Length], C.PCFieldNo, C.ItemType, C.HiddenFlag, C.PurposeCode,      
	  C.RightJustify, C.PadChar, C.TrimBlanks, C.FontName, C.FontSize,      
	  C.BoldFont, C.DefValue, C.GroupId, C.BalType, C.EncryptFlag,      
	  C.MaskFormat, C.DisabledFlag, C.RegularExpression, C.CropImageAttributes,
	  IsNull(T.AccountLookUpId,0) as 'AccountLookUpId',
	  IsNull(T.LookupDBObjectId ,0) as 'LookupDBObjectId',T.FormatName,C.FormatId,C.ControlType,T.Orientation,C.DelChars      
	From       
	   PSGTMS.CustDataEntFile C With (NOLOCK)  Inner join PSGTMS.tblCustDataEntItems T With (NOLOCK)           
	  On C.FormatId = T.FormatId     
	Where       
	  C.WorkSource = @WorkSource  
	And C.Siteid = Case when @SiteID = 0  then Siteid Else @Siteid End      
	And C.PgmNo = Case when @PgmNo = 0  then PgmNo Else @PgmNo End      
	And C.Siteid > 0      
	Order By C.PgmNo, C.FormatNo, C.FieldNo   
    
	Select	SiteID,CustNo,WorkSource,Pgmno,FormatNo,FieldNo,JBFieldNo,[Description],DataType,RequiredFlag,[Length],PCFieldNo,ItemType,HiddenFlag,
				PurposeCode,RightJustify,PadChar,TrimBlanks,FontName,FontSize,BoldFont,DefValue,GroupId,BalType,EncryptFlag,MaskFormat,DisabledFlag,RegularExpression,
				CropImageAttributes,AccountLookUpId,LookupDBObjectId,FormatName,FormatId,ControlType,Orientation,Delchars  
	From #testcustdata With(Nolock)
	ORDER BY Pgmno,FormatNo, FieldNo

	Select	Distinct
				A.[FormatId] ,
				A.[PCFieldNo] ,
				A.[DisplayField] ,
				A.[ValueField] ,
				B.FormatNo,
				B.FieldNo,
				A.SNo 
	From [PSGTMS].[tblCustDataEntDataSource] A With(Nolock)
	Inner Join #testcustdata B With(Nolock)
	ON A.FormatId = B.FormatId
	And A.PCFieldNo = B.PCFieldNo
	Where A.FormatId>=0
	ORDER BY B.FormatNo, B.FieldNo,A.SNo 

	IF  Object_Id('tempdb.dbo.#testcustdata') IS NOT NULL 
	Begin
		DROP Table #testcustdata
	End
      
 SET NOCOUNT OFF    
End 
GO

