Delete from PSGTMS.tblMenumanager Where MenuId = 376 and MenuKey = 1
Go
INSERT into PSGTMS.TBLMENUMANAGER (MenuId, MenuLevel, MenuReferenceID, MenuGroupID, MenuGroupName, MenuName, MenuDisplayName, ExecutableName, IconImageFileName, DateClassifier, ProgramNo, MenuPosition, AuthorityLevel, ShowMenu, MenuKey)
VALUES (376, 4, 0, 0, N'', N'TMS Ticketing', N'TMS Ticketing', N'TMSTicketing', N'tmsTicketingIcon.png', 0, 0, 1, 4, N'N', 1)
GO

DELETE FROM PSGTMS.tblMenuManager_Lang WHERE MenuId=376 and MenuKey = 1
GO
INSERT INTO PSGTMS.tblMenuManager_Lang(LanguageID,MenuId,MenuDisplayName,MenuKey,MenuGroupName) VALUES(1,376,'TMS Ticketing',1,NULL)
GO