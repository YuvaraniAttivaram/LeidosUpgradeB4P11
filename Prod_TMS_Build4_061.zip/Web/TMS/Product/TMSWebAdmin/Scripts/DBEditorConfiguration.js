﻿KendoLicensing.setScriptKey(KendoApiKey);
document.addEventListener("DOMContentLoaded", function () {

    // ---------- Add New Tab ----------
    document.getElementById("btnAddTab").addEventListener("click", function () {
        const tableId = document.getElementById("ddlTable").value;//$("#ddlTable").val().replace("number:", "");
        $('#AddTab').modal('show');
        tabGridOptions(tableId);
    });

    // ---------- Assign Tab ----------
    document.getElementById("btnAssignTab").addEventListener("click", function () {
        const tableId = document.getElementById("ddlTable").value;
        $.ajax({
            url: DBEGetTabUrl,
            method: "GET",
            data: { TableID: tableId },
            success: function (tabResponse) {
                const tabs = tabResponse;
                const selectedTabName = tabs.length > 0 ? tabs[0].TabName : "";
                const ddlTabAssign = document.getElementById('ddlTabAssign');
                ddlTabAssign.innerHTML = "";
                tabs.forEach(tab => {
                    if (/^[a-zA-Z0-9 _-]+$/.test(tab.TabName)) {
                        const option = document.createElement('option');
                        option.value = String(tab.TabID).replace(/[^a-zA-Z0-9_-]/g, '');
                        option.textContent = tab.TabName.replace(/[^a-zA-Z0-9 _-]/g, '');
                        ddlTabAssign.appendChild(option);
                    }
                });
                ddlTabAssign.dispatchEvent(new Event('change'));

                // Now get column config
                $.ajax({
                    url: ColumnConfigDataUrl,
                    method: "GET",
                    data: { TableID: tableId },
                    success: function (columnResponse) {
                        //const columnConfig = columnResponse;
                        $("#ddlTabAssign").val("1");
                        $('#AssignTabs').modal('show');
                        $(".assignTabCtls").mCustomScrollbar({ scrollInertia: 0 });

                    }
                });
            }
        });
    });

    // ---------- On Assign Tab Dropdown Change ----------
    $('#ddlTabAssign').on('change', function () {
        const tableId = $('#ddlTable').val();
        loadTabConfigForTable(tableId);
    });

    // ---------- On Assign Tab Save Button Click ----------
    $('#btnUpdateAsignTab').on('click', function () {
        const tableId = $('#ddlTable').val();
        updateColumnTabConfig(tableId);
    });

    // ---------- Update Edit Column Config ----------
    $('#btnUpdateColumnTabConfig').on('click', function () {
        updateColumnConfigDetails();
    });

    // ---------- Add New Table ----------
    $("#btnAddNewTable").on('click', function () {
        openTableDialog();
    });

    $("#searchTableNameLink").on("click", function () {
        searchTable();
    });

    $("#btnInsertTableDetails").on("click", function () {
        insertTableDetails();
    });

    $("#btnUpdateTableDetails").on("click", function () {
        updateTableDetails();
    });

    $("#btnDeleteTableDetails").on("click", function () {
        deleteTableDetails();
    });
});
function loadTabConfigForTable(tableId) {
    $.ajax({
        url: ColumnConfigDataUrl,
        method: 'GET',
        data: { TableID: tableId },
        success: function (columnConfig) {
            const selectedTabName = $('#ddlTabAssign option:selected').text();
            const $list = $('#columnList');
            $list.empty();

            columnConfig.forEach(function (tb) {
                const isChecked = tb.TabName === selectedTabName;
                // Sanitize all server-provided values
                const safeSno = String(tb.Sno).replace(/[^a-zA-Z0-9_-]/g, '');
                const safeColumnName = tb.ColumnName.replace(/[^a-zA-Z0-9 _()-]/g, '');

                const li = document.createElement('li');
                li.className = 'list-group-item border-0 col-6 col-sm-4';

                const span = document.createElement('span');
                span.className = 'form-check form-check-inline';

                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.id = `${safeSno}_chkcol`;
                checkbox.name = 'coltabchkbx';
                checkbox.value = safeSno;
                if (isChecked) checkbox.checked = true;

                const label = document.createElement('label');
                label.setAttribute('for', `${safeSno}_chkcol`);
                label.textContent = ` ${safeColumnName}`;

                span.appendChild(checkbox);
                span.appendChild(label);
                li.appendChild(span);
                $list[0].appendChild(li);
            });

            $(".assignTabCtls").mCustomScrollbar({ scrollInertia: 0 }); // re-init scrollbar
        }
    });
}

function updateColumnTabConfig(tableId) {
    let selectedTabName = $('#ddlTabAssign option:selected').text();
    let selectedColIds = [];

    $('input[name="coltabchkbx"]:checked').each(function () {
        selectedColIds.push(this.value);
    });

    $.ajax({
        method: 'POST',
        url: UpdateColumnConfigTabNameUrl,
        data: {
            TableID: tableId,
            TabName: selectedTabName,
            commaseparetedcol: selectedColIds.join(',')
        },
        success: function (response) {
            if (response.Message === true) {
                alert(DBEUpdated);
            } else {
                alert(DBEUpdatedFailure);
            }

        }
    });
}

function tabGridOptions(tableId) {
    const TabGridOptions = {
        columns: [
            {
                field: "Tabid",
                title: "Tabid",
                width: "180px",
                hidden: true
            },
            {
                field: "TabName",
                title: "TabName"
            },
            {
                field: "TabOrder",
                title: "TabOrder"
            },
            {
                command: [
                    {
                        name: "edit",
                        text: {
                            edit: "",
                            cancel: "",
                            update: ""
                        }
                    },
                    { name: "destroy", text: " " }
                ],
                title: "Action",
                width: "100px"
            }
        ],
        pageable: false,
        editable: "inline",
        toolbar: ["create"],
        dataSource: {
            transport: {
                read: function (e) {
                    $.ajax({
                        url: GetTabDetailUrl,
                        dataType: "json",
                        contentType: "application/json",
                        data: { TableID: tableId || "1" },
                        success: function (response) {
                            e.success(response);
                        },
                        error: function (response) {
                            e.error(response);
                        }
                    });
                },
                create: function (e) {
                    const form = $('#__AjaxAntiForgeryForm');
                    const token = $('input[name="__RequestVerificationToken"]', form).val();
                    const tableID = parseInt(document.getElementById("ddlTable").value);
                    const objDBETabConfig = {
                        //Tabid: TabID,
                        TableId: tableID,
                        TabName: e.data.TabName,
                        TabOrder: e.data.TabOrder,
                        Message: ""
                    };

                    $.ajax({
                        method: "POST",
                        url: InsertTabDetailUrl,
                        headers: {
                            'Content-Type': 'application/json',
                            '__RequestVerificationToken': token
                        },
                        data: JSON.stringify(objDBETabConfig),
                        success: function () {
                            alert(DBEAdded);
                            $(".assignTabTable").data("kendoGrid").dataSource.read(); // reinitialize
                            //tabGridOptions(tableId); // reinitialize
                        }
                    });
                },
                update: function (e) {
                    const form = $('#__AjaxAntiForgeryForm');
                    const token = $('input[name="__RequestVerificationToken"]', form).val();
                    const objDBETabConfig = {
                        Tabid: e.data.Tabid,
                        TableId: tableId,
                        TabName: e.data.TabName,
                        TabOrder: e.data.TabOrder,
                        Message: ""
                    };

                    $.ajax({
                        method: "POST",
                        url: UpdateTabDetailUrl,
                        headers: {
                            'Content-Type': 'application/json',
                            '__RequestVerificationToken': token
                        },
                        data: JSON.stringify(objDBETabConfig),
                        success: function () {
                            alert(DBEUpdated);
                            $(".assignTabTable").data("kendoGrid").dataSource.read(); // reinitialize
                            //tabGridOptions(tableId);
                        }
                    });
                },
                destroy: function (e) {
                    const form = $('#__AjaxAntiForgeryForm');
                    const token = $('input[name="__RequestVerificationToken"]', form).val();
                    const objDBETabConfig = {
                        Tabid: e.data.Tabid,
                        TableId: tableId,
                        TabName: e.data.TabName,
                        TabOrder: e.data.TabOrder,
                        Message: ""
                    };

                    $.ajax({
                        method: "POST",
                        url: DeleteTabDetailUrl,
                        headers: {
                            'Content-Type': 'application/json',
                            '__RequestVerificationToken': token
                        },
                        data: JSON.stringify(objDBETabConfig),
                        success: function () {
                            alert(DBEDeleted);
                            $(".assignTabTable").data("kendoGrid").dataSource.read(); // reinitialize
                            //tabGridOptions(tableId);
                        }
                    });
                }
            },
            schema: {
                model: {
                    id: "Tabid",
                    fields: {
                        Tabid: { editable: false, nullable: true, type: "number" },
                        TabName: { editable: true, nullable: true, type: "string" },
                        TabOrder: { editable: true, nullable: true, type: "number" },
                        TableId: { editable: false, nullable: true, type: "number" },
                        Message: { editable: false, nullable: true, type: "string" }
                    }
                }
            }
        },
        dataBound: function () {
            const windHit = $(window).height();
            $(".assignTabTable .k-grid-header").css({ "padding-right": "12px" });
            $(".assignTabTable .k-grid-content").css({ "height": (windHit - 370) + "px", "padding-right": "12px" });
            $(".assignTabTable .k-grid-content").niceScroll({ autohidemode: false });
        }
    };

    $(".assignTabTable").html("");
    // Assume you initialize a Kendo Grid here using TabGridOptions
    $(".assignTabTable").kendoGrid(TabGridOptions);
}

function populateTabDropdown(tabs, selectedTabName) {
    const $ddlTab = $('#ddlTab');
    $ddlTab.empty(); // clear existing options

    tabs.forEach(function (tab) {
        const isSelected = tab.TabName === selectedTabName;
        const option = $('<option>')
            .val(tab.TabID)
            .text(tab.TabName)
            .prop('selected', isSelected);

        $ddlTab.append(option);
    });
}

function loadColumnConfig(tableID) {
    $("#gridColumConfig").html("");
    $("#gridColumConfig").kendoGrid({
        columns: [
            { field: "ColumnNo", title: "ColumnNo" },
            { field: "ColumnName", title: "ColumnName" },
            { field: "DisplayName", title: "DisplayName" },
            { field: "DataType", title: "DataType" },
            { title: "IsVisible", template: '<input type="checkbox" disabled #= IsVisible ? "checked=\'checked\'" : "" #>' },
            { title: "AllowEdit", template: '<input type="checkbox" disabled #= AllowEdit ? "checked=\'checked\'" : "" #>' },
            { field: "FieldSerialNo", title: "FieldSerialNo" },
            { field: "TabName", title: "TabName" },
            { field: "ColumnLength", title: "ColumnLength" },
            { title: "Action", template: '<a class="fa fa-pencil fontSize16" data-column-no="#=ColumnNo#"></a>' }
        ],
        dataSource: {
            transport: {
                read: function (options) {
                    $.ajax({
                        url: ColumnConfigDataUrl,
                        data: { TableID: tableID },
                        success: options.success,
                        error: options.error
                    });
                }
            }
        },
        dataBound: function () {
            $("#gridColumConfig .fa-pencil").click(function () {
                const columnNo = $(this).attr("data-column-no");
                openColumnConfig(columnNo);
            });
            var contHit = $("#tab1").height();
            $("#gridColumConfig .k-grid-content.k-auto-scrollable").css({ "height": (contHit - 81) + "px", "padding-right": "15px" });
            $("#gridColumConfig .k-grid-content.k-auto-scrollable").niceScroll({ autohidemode: false });
        }
    });
}

function openColumnConfig(columnNo) {

    const tableId = document.getElementById("ddlTable").value;
    $.ajax({
        url: DBEGetTabUrl,
        method: "GET",
        async: false,
        data: { TableID: tableId },
        success: function (tabResponse) {
            const tabs = tabResponse;
            //const selectedTabName = tabs.length > 0 ? tabs[0].TabName : "";
            const ddlTabAssign = document.getElementById('ddlTab');
            //ddlTabAssign.innerHTML = "";
            while (ddlTabAssign.firstChild) {
                ddlTabAssign.removeChild(ddlTabAssign.firstChild);
            }
            tabs.forEach(tab => {
                const safeTabId = String(tab.TabID).replace(/[^a-zA-Z0-9_-]/g, '');
                const safeTabName = String(tab.TabName).replace(/[^a-zA-Z0-9 _()-]/g, '');

                const option = document.createElement('option');
                option.value = safeTabId;
                option.textContent = safeTabName;
                ddlTabAssign.appendChild(option);
            });
        }
    });

    $.get(GetColumnDataForEditUrl, { TableID: tableId, ColumnNo: columnNo }, function (data) {
        const ec = data[0];
        $("#spnColumnNo").text(ec.ColumnNo);
        $("#spnColumnName").text(ec.ColumnName);
        $("#txtTabDisplayName").val(ec.DisplayName);
        $("#spnDataType").text(ec.DataType);
        $("#ddlTabIsVisible").val(ec.IsVisible ? "true" : "false");
        $("#ddlAllowEdit").val(ec.AllowEdit ? "true" : "false");
        $("#txtFieldSerialNo").val(ec.FieldSerialNo);
        $("#editColumnConfig").modal("show");
        $("#ddlTab option").filter(function () {
            return $(this).text() === ec.TabName;
        }).prop("selected", true);
    });
}

function updateColumnConfigDetails() {
    var form = $('#__AjaxAntiForgeryForm');
    var token = $('input[name="__RequestVerificationToken"]', form).val();
    var objDBEColumnConfig = {
        Sno: 0, // or parseInt(value) if you have one, but not ""
        TableID: parseInt($('#ddlTable').val()),
        TableName: $("#ddlTable option:selected").text(),
        ColumnNo: parseInt($("#spnColumnNo").html()),
        ColumnName: $("#spnColumnName").html(),
        DisplayName: $("#txtTabDisplayName").val(),
        DataType: $("#spnDataType").html(),
        IsVisible: $("#ddlTabIsVisible").val() === "true",  // convert to boolean
        AllowEdit: $("#ddlAllowEdit").val() === "true",     // convert to boolean
        FieldSerialNo: parseInt($("#txtFieldSerialNo").val()),
        TabName: $("#ddlTab option:selected").text(),
        ColumnLength: 0
    };
    $.ajax({
        type: 'POST',
        url: UpdateColumnConfigDataUrl,
        contentType: 'application/json',
        headers: {
            '__RequestVerificationToken': token
        },
        data: JSON.stringify(objDBEColumnConfig),
        success: function () {
            var tableID = $("#ddlTable").val();
            loadColumnConfig(tableID);
            alert(DBEUpdated);
            $("#editColumnConfig").modal("hide");
        },
        error: function (xhr) {
            console.error('Error updating column config:', xhr.responseText);
        }
    });
}

function openTableDialog() {
    $("#txtTableDispName").val("");
    $("#txtTableName").val("");
    $("#tableList").hide(); // clear table list if needed
    $('#AddTable').modal('show');
}

function searchTable() {
    var tableName = $("#txtTableName").val();
    if (tableName === "") {
        alert(DBEPlsEntTable);
        return false;
    }

    $("#tableList").slideDown();

    $.ajax({
        url: GetSearchTableUrl,
        method: "GET",
        data: { SearchTableName: tableName },
        success: function (data) {
            if (!data || data.length === 0) {
                alert(DBENoTableFound);
            }
            window.SearchTableList = data; // set globally or bind to your component
            const container = document.getElementById("tableNameLists");
            if (!container) return;
            //container.innerHTML = "";
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
            var i = 0;
            window.SearchTableList.forEach(batch => {
                const safeTblName = String(batch.TblName).replace(/[^a-zA-Z0-9 _()-]/g, '');
                const li = document.createElement("li");
                li.className = "list-group-item border-0 w-100 p-1";

                // Create radio input element
                const radioInput = document.createElement("input");
                radioInput.type = "radio";
                radioInput.id = `tblRadio${i}`;
                radioInput.className = "radBatchNo";
                radioInput.value = safeTblName;
                radioInput.name = "radTblName";

                // Create label element
                const label = document.createElement("label");
                label.setAttribute("for", `tblRadio${i}`);
                label.textContent = safeTblName;

                const span = document.createElement("span");
                span.className = "form-check form-check-inline";
                span.appendChild(radioInput);
                span.appendChild(label);

                li.appendChild(span);

                container.appendChild(li);
                i++;
            });
            //}
        },
        error: function (xhr) {
            console.error("Error searching table:", xhr.responseText);
        }
    });

    $(".tableList").mCustomScrollbar({ scrollInertia: 0 });
}

function insertTableDetails() {
    var selectedRadio = $('input[name="radTblName"]:checked');
    var displayName = $("#txtTableDispName").val();

    if (selectedRadio.length === 0) {
        alert(DBESelectTable);
        return false;
    }

    if (displayName === "") {
        alert(DBEEntDisplayName);
        $("#txtTableDispName").focus();
        return false;
    }

    $.ajax({
        type: 'POST',
        url: InsertTableForEditUrl,
        contentType: 'application/json',
        data: JSON.stringify({
            TableName: selectedRadio[0].value,
            DispTableName: displayName
        }),
        success: function () {
            var tableID = $("#ddlTable").val();
            loadTableConfig(tableID); // your existing reload method
            alert(DBEAdded);
            $('#AddTable').modal('hide');
        },
        error: function (xhr) {
            console.error("Error inserting table details:", xhr.responseText);
        }
    });
}

function loadTableConfig(tableID) {
    $("#gridTableConfig").html("");
    $("#gridTableConfig").kendoGrid({
        columns: [
            { field: "TableName", title: "TableName" },
            { field: "DisplayName", title: "DisplayName" },
            { title: "AllowUpdate", template: '<input type="checkbox" disabled #= AllowUpdate ? "checked" : "" #' },
            { field: "UpdateDbObjectId", title: "UpdateDbObjectId" },
            { title: "AllowInsert", template: '<input type="checkbox" disabled #= AllowInsert ? "checked" : "" #' },
            { field: "InsertDbObjectId", title: "InsertDbObjectId" },
            { title: "AllowDelete", template: '<input type="checkbox" disabled #= AllowDelete ? "checked" : "" #' },
            { field: "DeleteParams", title: "DeleteParams" },
            { field: "DeleteDbObjectId", title: "DeleteDbObjectId" },
            { title: "IsVisible", template: '<input type="checkbox" disabled #= IsVisible ? "checked" : "" #' },
            { field: "SearchParams", title: "SearchParams" },
            { field: "GetDataDbObjectId", title: "GetDataDbObjectId" },
            { field: "GoToParams", title: "GoToParams" },
            { title: "Action", template: '<a class="fa fa-pencil fontSize16" data-table-id="#=TableID#"></a>' }
        ],
        dataSource: {
            transport: {
                read: function (options) {
                    $.ajax({
                        url: TableConfigDataUrl,
                        data: { TableID: tableID },
                        success: options.success,
                        error: options.error
                    });
                }
            }
        },
        dataBound: function () {
            $("#gridTableConfig .fa-pencil").click(function () {
                const tableId = $(this).attr("data-table-id");
                openTableConfig(tableId);
            });
        }
    });
}

function openTableConfig(tableId) {
    $.get(GetTableDataForEditUrl, { TableID: tableId }, function (d) {
        $("#spnTableId").text(d.TableID);
        $("#spnTableName").text(d.TableName);
        $("#TableDisplayName").val(d.DisplayName);
        $("#ddlAllowUpdate").val(String(d.AllowUpdate));
        $("#txtUpdateDBObjectID").val(d.UpdateDbObjectId);
        $("#ddlAllowInsert").val(String(d.AllowInsert));
        $("#txtInsertDBObjectID").val(d.InsertDbObjectId);
        $("#ddlAllowDelete").val(String(d.AllowDelete));
        $("#txtDeleteParams").val(d.DeleteParams);
        $("#txtDeleteDBObjectID").val(d.DeleteDbObjectId);
        $("#ddlIsVisible").val(String(d.IsVisible));
        $("#txtGetDataParameters").val(d.SearchParams);
        $("#txtGetDataDBObjectID").val(d.GetDataDbObjectId);
        $("#txtGoToConfigParameter").val(d.GoToParams);
        $("#editTableConfig").modal("show");
    });
}

function updateTableDetails() {
    var form = $('#__AjaxAntiForgeryForm');
    var token = $('input[name="__RequestVerificationToken"]', form).val();

    var objDBEConfigTable = {
        TableID: $("#spnTableId").html(),
        TableName: $("#spnTableName").html(),
        DisplayName: $("#TableDisplayName").val(),
        AllowUpdate: $("#ddlAllowUpdate").val(),
        UpdateDbObjectId: $("#txtUpdateDBObjectID").val(),
        AllowInsert: $("#ddlAllowInsert").val(),
        InsertDbObjectId: $("#txtInsertDBObjectID").val(),
        AllowDelete: $("#ddlAllowDelete").val(),
        DeleteParams: $("#txtDeleteParams").val(),
        DeleteDbObjectId: $("#txtDeleteDBObjectID").val(),
        IsVisible: $("#ddlIsVisible").val(),
        SearchParams: $("#spnSearchParams").html(),
        GetDataDbObjectId: $("#txtGetDataDBObjectID").val(),
        GoToParams: $("#txtGoToConfigParameter").val()
    };

    $.ajax({
        type: 'POST',
        url: UpdateTableConfigDataUrl,
        contentType: 'application/json',
        headers: {
            '__RequestVerificationToken': token
        },
        data: JSON.stringify(objDBEConfigTable),
        success: function () {
            const tableID = $("#ddlTable").val();
            loadTableConfig(tableID);
            alert(DBEUpdated);
            $("#editTableConfig").modal("hide");
        },
        error: function (xhr) {
            console.error('Update failed:', xhr.responseText);
        }
    });
}

function deleteTableDetails() {
    var form = $('#__AjaxAntiForgeryForm');
    var token = $('input[name="__RequestVerificationToken"]', form).val();

    var data = {
        TableID: $("#spnTableId").html()
    };

    $.ajax({
        type: 'POST',
        url: DeleteTableConfigDataUrl,
        contentType: 'application/json',
        headers: {
            '__RequestVerificationToken': token
        },
        data: JSON.stringify(data),
        success: function () {
            const tableID = $("#ddlTable").val();
            loadTableConfig(tableID);
            alert(DBEDeleted);
            $("#editTableConfig").modal("hide");
        },
        error: function (xhr) {
            console.error('Delete failed:', xhr.responseText);
        }
    });
}

$(document).ready(function () {
    $("#lnkClose").removeAttr("href");
    $("#lnkClose").click(function () {
        document.location.href = "../DBEditor/DBEditorMenu";
    });
});

$(document).ready(function () {
    var tableID = "";
    function loadTables() {
        $.get(DBEGetTableUrl, function (data) {
            const $ddlTable = $("#ddlTable");
            $ddlTable.empty();
            data.forEach(table => {
                const $option = $('<option>', {
                    value: table.TableID,
                    text: table.TableName // This is safe against XSS
                });
                $ddlTable.append($option);
            });
            const tableID = data[0]?.TableID || 1;
            $ddlTable.val(tableID);
            loadColumnConfig(tableID);
            loadTableConfig(tableID);
        });
    }

    $("#ddlTable").on("change", function () {
        tableID = $(this).val();
        loadColumnConfig(tableID);
        //loadTableConfig();
    });

    loadTables();
});

