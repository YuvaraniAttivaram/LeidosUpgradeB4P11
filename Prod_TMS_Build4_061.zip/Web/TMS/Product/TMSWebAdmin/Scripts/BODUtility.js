﻿$(document).ready(function () {
    FillBODDateGrid();
    var footerHit = $(".footer").height();
    $(".SelectionGridWrapper").css({ "height": ($(window).height() - ($(".topNavBtnsWrapper").height() + footerHit + 163)) + "px" });
    $("#DateGrid").on('click', 'tbody tr', function (event) {
        $(this).addClass('highlight').siblings().removeClass('highlight');
        var Status = $(this).find('td').eq(1).text();
        var CodeStatus = $(this).find('td').eq(1).attr("data-status").trim();
        $("#lblProcessDate").text($(this).find('td').eq(0).text());
        EnableDisableButtons(CodeStatus);
    });
    $(document).on("keydown", function (e) {
        if ((e.ctrlKey || e.altKey || e.shiftKey) && sCtrlEventKeys.indexOf(e.keyCode) < 0) {
            HandleShortCutKey(e);
        }
    });
    stickyTable();

    LoadSiteData();

    $("#siteIdModal").on('hide.bs.modal', function (event) {
        if ($('#siteDropdownId')[0].selectedIndex == 0) {
            $('.error-label').show();
        }
        else {
            $('.error-label').hide();
        }
        if (isOkButtonClick == false) {
            event.preventDefault();
        }
    });
});

var isOkButtonClick = false;
var siteDataList = [];

var sCtrlEventKeys = [17, 16, 18];
// Ctrl=17 Alt =18 Shift=16
var scShortCutKeysWithElementId = {
    "16+72": "btnHelp",  // Shift+H
    "16+78": "btnNewDate", // Shift+N
    "16+67": "btnCloseDate", // Shift+C
    "16+71": "btnGoToDate", // Shift+G
    "16+83": "btnSetWorkSource", //Shift+S
    "16+76": "btnClearWorkSource", // Shift+L
    "16+82": "btnReOpen", // Shift+R
};
function HandleShortCutKey(e) {
    var sShortCutKey = e.keyCode;
    var sElementId = scShortCutKeysWithElementId[sShortCutKey];
    if (sElementId == null) {
        if (e.shiftKey && e.keyCode > 0)
            sShortCutKey = "16+" + e.keyCode;
        else if (e.ctrlKey && e.keyCode > 0)
            sShortCutKey = "17+" + e.keyCode;
        else if (e.altKey && e.keyCode > 0)
            sShortCutKey = "18+" + e.keyCode;
        sElementId = scShortCutKeysWithElementId[sShortCutKey];
    }
    if (sElementId != null)
        $("#" + sElementId + ":not(.disabled)").trigger("click");
}

//$(function () {
//    var visited = sessionStorage['BODvisited'];
//    if (typeof (visited) == "undefined" || visited == "false" ){
//        SelectFirstRow();
//        sessionStorage['BODvisited'] = true;
//    }    
//});

function SelectFirstRow() {
    var $row = $("#DateGrid").find('tr')[1];
    if (typeof ($row) != "undefined") {
        $($row).addClass('highlight').siblings().removeClass('highlight');
        var Status = $($row).find('td').eq(1).attr("data-status").trim();
        $("#lblProcessDate").text($($row).find('td').eq(0).text());
        EnableDisableButtons(Status);
    }
}

function ShowModalPopup(Action) {
    if ($("#HDNaction") != null)
        $("#HDNaction").val(Action);
    $('#PopupHeader').text(Action == "NewDate" ? HeaderCreateDate : HeaderGoTo);
    bDrag = false;
    if ($("#_divcreateDateCtrl").length > 0) {
        $(".mainDiv_").remove();
        $(".dateCtrlWrapper").append("<div id='_divcreateDateCtrl' class='mainDiv_'></div>");
    }
    else {
        $(".dateCtrlWrapper").append("<div id='_divcreateDateCtrl' class='mainDiv_'></div>");
    }
    setTimeout(function () {
        $(".showCalendar").trigger('mouseover');
        $(".showCalendar").trigger('click');
        $(".mainDiv_").css({ "position": "relative", "left": "0", "top": "0", "display": "block", "box-shadow": "none" });
        $(".calendarTable_").attr("onMouseDown", "");
        if ($(".mainDiv_").length == 1) {
            $(".mainDiv_").appendTo(".dateCtrlWrapper").fadeIn();
        }
        isClose = 'true';
        isCalclosed = 'true';
        openCalendar = true;
        $("#createDateCtrl").val(formatDate());
        if (Action == 'GoToDate') {
            $(".siteSelectionCtrlWrapper").hide();
        }
        else {
            $(".siteSelectionCtrlWrapper").show();
        }
        $("#myModal").modal('show');
    }, 500);
}

var clickedAction = '';
function promptCloseReopenModal(Action) {
    clickedAction = Action;

    if (Action == 'Close') {
        $("#CloseSiteSelection").show();
        $("#ReOpenSiteSelection").hide();
    }
    if (Action == 'Reopen') {
        $("#ReOpenSiteSelection").show();
        $("#CloseSiteSelection").hide();
    }

    $("#SitePopupHeader").text(Action == 'Close' ? CloseDateHeaderText : ReopenDateHeaderText);
    var siteList = JSON.parse(sessionStorage.getItem("SiteList"));
    if (siteList != null && siteList != undefined && siteList.length > 0) {

        // Fetch the existing date details from the grid list
        var rows = getHighlightRow();
        var ProcessDate = $(rows).find('td').eq(0).text();
        var dateDetailList = JSON.parse(sessionStorage.getItem("DateResult"));
        var dateDetail = dateDetailList.filter(item => {
            return item.ProcessDate == ProcessDate;
        });

        if (dateDetail != null && dateDetail != undefined && dateDetail.length > 0) {
            let siteDateData = dateDetail[0].SiteIds;
            var existingSiteIds = [];
            var sites = siteDateData.SiteIds;
            var siteArray = siteDateData.split(',');
            let allSitesAvailable = false;

            if (siteArray.length > 0 && siteArray[siteArray.length - 1] != '') {

                for (let i = 0; i < siteArray.length; i++) {
                    existingSiteIds.push(parseInt(siteArray[i]));
                }

                // Check the all sites are available for the selected date
                var fullSiteList = JSON.parse(sessionStorage.getItem("SiteList"));
                var siteWithoutAll = fullSiteList.filter(item => {
                    return item.SiteId != 0;
                });

                var finalSiteList = [];

                siteWithoutAll.forEach(function (site) {
                    let itemIndex = siteArray.findIndex(item => { return item == site.SiteId });
                    if (itemIndex != -1) { finalSiteList.push(siteWithoutAll[itemIndex]) };
                    allSitesAvailable = itemIndex == -1 ? false : true;
                });

                //$('#siteSelectControl').html('');
                //var options = '';
                const $select = $('#siteSelectControl');
                $select.empty(); // safer than .html('')

                if (!allSitesAvailable) {

                    // Remove the opened site option for the reopen action and remove the closed site option for the close action.
                    var optionToBeRemoved;
                    var action = Action == 'Close' ? "Closed" : "Open";

                    optionToBeRemoved = dateDetail[0].SiteData.filter(item => { return item.Status == action });

                    if (optionToBeRemoved != null && optionToBeRemoved != undefined && optionToBeRemoved.length > 0) {
                        finalSiteList = finalSiteList.filter(site =>
                            !optionToBeRemoved.some(val => site.SiteId === val.SiteID)
                        );
                    }

                    // Add finalSiteList to dropdown safely
                    finalSiteList.forEach(function (site) {
                        $('<option>', {
                            value: parseInt(site.SiteId),
                            text: site.SiteName
                        }).appendTo($select);
                    });

                    if (formatData(finalSiteList) === "true") return;

                    if (finalSiteList.length === 1) {
                        $select.attr('disabled', 'disabled');
                    } else {
                        $select.removeAttr('disabled');
                    }
                }
                else {

                    // Remove the opened site option for the reopen action and remove the closed site option for the close action.
                    var optionToBeRemoved;
                    var action = Action == 'Close' ? "Closed" : "Open";

                    optionToBeRemoved = dateDetail[0].SiteData.filter(item => { return item.Status == action });

                    if (optionToBeRemoved != null && optionToBeRemoved != undefined && optionToBeRemoved.length > 0) {
                        siteList = siteList.filter(site =>
                            !optionToBeRemoved.some(val => site.SiteId === val.SiteID)
                        );
                    }

                    // Add siteList to dropdown safely
                    siteList.forEach(function (site) {
                        $('<option>', {
                            value: parseInt(site.SiteId),
                            text: site.SiteName
                        }).appendTo($select);
                    });

                    if (formatData(siteList) === "true") return;

                    if (siteList.length === 1) {
                        $select.attr('disabled', 'disabled');
                    } else {
                        $select.removeAttr('disabled');
                    }
                }
            }
        }
    }
    $("#siteDropdownModal").modal('show');
}

function EscapeHTML(strParam) {
    return strParam.replace(/\&/g, '&amp;')
        .replace(/\</g, '&lt;')
        .replace(/\>/g, '&gt;')
        .replace(/\"/g, '&quot;')
        .replace(/\'/g, '&#x27;')
        .replace(/\//g, '&#x2F;');
}
function InvokeCloseReopen() {
    CloseRepoenDate(clickedAction);
}

function CloseRepoenDate(Action) {
    var rows = getHighlightRow();
    if (typeof (rows) != "undefined" && rows.length > 0) {
        var ProcessDate = EscapeHTML($(rows).find('td').eq(0).text());
        var AcionURL;
        var tabStatus;
        var siteId;
        // Fetch the SiteId from the sessionStorage variable.
        var dateResult = JSON.parse(sessionStorage.getItem("DateResult"));

        let selectedSite = $('#siteSelectControl option:selected').attr("value");
        let result = dateResult.filter(item => { return item.ProcessDate == ProcessDate });
        siteId = selectedSite;

        if (siteId > 0) {
            if (result != null && result != undefined) {
                let siteDateData = result[0].SiteIds; // result.filter(item => { return item.SiteId == selectedSite });
                var siteIds = [];
                var sites = result[0].SiteIds;
                var siteArray = sites.split(',');
                var existingSite;
                if (siteArray.length > 0 && siteArray[siteArray.length - 1] != '') {

                    for (let i = 0; i < siteArray.length; i++) {
                        siteIds.push(parseInt(siteArray[i]));
                    }
                    existingSite = siteIds.find(item => { return item == selectedSite });
                }

                if (existingSite == undefined || existingSite == null) {
                    let siteName = siteDataList[$('#siteSelectControl')[0].selectedIndex].SiteName;
                    let messageString = Action == "Reopen" ? msgSelectOtherSiteReOpen : msgSelectOtherSiteClose;
                    alert(MsgDateNotOpenForSite + siteName + ".\n" + messageString + ".");
                    return false;
                }
            }
        }

        if (Action == "Reopen") {
            if (!confirm(MsgReopenDate + ": " + ProcessDate))
                return false;
            tabStatus = "Open";
            AcionURL = ReOpenDateURL;
        }
        else if (Action == "Close") {
            if (!confirm(MsgCloseDate))
                return false;
            tabStatus = "Closed";
            AcionURL = CloseDateURL;
        }

        if ($("#DateGrid tr").length <= 0)
            return;

        var ReqData = {
            ProcessDate: ProcessDate,
            SiteId: siteId
        }
        $.ajax({
            url: AcionURL,
            type: "POST",
            dataType: "json",
            data: JSON.stringify(ReqData),
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                if (result != null && result != undefined) {
                    if (Action == "Close" && result.Error == false && result.ErrorMessage != null && result.ErrorMessage != "") {
                        alert(result.ErrorMessage);
                        SelectNewDate(ProcessDate);
                        return;
                    }
                    else if (result.Error == false) {
                        FillBODDateGrid();
                        if (tabStatus == "Closed") {
                            $("#DateGrid").find(".highlight").children("td.DateGridStatus").text(tabStatus);
                            $("#DateGrid").find(".highlight").children("td.DateGridStatus").next().text(0);
                        }
                        if (tabStatus == "Open") {
                            FillBODDateGrid();
                        }
                        $("#siteDropdownModal .modal-header .btn-close").trigger("click");
                        if (tabStatus == "Open")
                            tabStatus = Msg_BODOpenStatus;
                        else if (tabStatus == "Closed")
                            tabStatus = Msg_BODClosedStatus;
                        EnableDisableButtons(tabStatus);

                        if (result.Result == "msgCloseDatevalidation") {
                            alert(msgCloseDatevalidation);
                        }
                    }
                }
            },
            error: function (eror) {
                alert("Error occured. Please try again");
            }
        });

        document.getElementById("HDN_ProcessDate").value = ProcessDate;
        return true;
    }
    else {
        alert(MsgSelectDate);
        ShowLoading(false);
        return false;
    }
}

function LoadSiteData() {
    $.ajax({
        url: SiteDataLoadURL,
        type: "GET",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                sessionStorage.setItem("SiteList", result);
                var siteData = JSON.parse(result);
                siteDataList = siteData;
                if (siteData != null && siteData != undefined && siteData.length > 0) {
                    //$('#siteDropdownId').html('');
                    $('#siteDropdownId').empty();
                    var options = '';

                    //for (var i = 0; i < siteData.length; i++) {

                    //    options += '<option value="' + parseInt(siteData[i].SiteId) + '">' + EscapeHTML(siteData[i].SiteName) + '</option>';
                    //}
                    //if  (formatData(options) == "true") {
                    //    return;
                    //}
                    //$('#siteDropdownId').html(options);
                    for (var i = 0; i < siteData.length; i++) {
                        $('<option>', {
                            value: parseInt(siteData[i].SiteId),
                            text: siteData[i].SiteName
                        }).appendTo('#siteDropdownId');
                    }
                    if (siteData.length == 1) {
                        $('#siteDropdownId').attr('disabled', 'disabled');
                    }
                    else {
                        $('#siteDropdownId').removeAttr('disabled');
                    }
                }
            }
        },
        error: function (eror) {
            alert("Error occured. Please try again");
        }
    });
}

function formatDate() {
    var d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    var newformat = dateformatinculture();
    var strdate = [month, day, year].join('/');
    var strNewDate = $.datepicker.formatDate(newformat, new Date(strdate));
    return strNewDate;
    //return [month, day, year].join('/');
}

function SetForAllWorksources(Action) {
    var rows = getHighlightRow();
    if (typeof (rows) != "undefined" && rows.length > 0) {
        var ProcessDate = $(rows).find('td').eq(0).text();
        var bolSetWS;
        if (Action == "SetAllWorkSource") {
            if (!confirm(MsgSetDefaultDate + " : " + ProcessDate))
                return false;
            bolSetWS = true;
        }
        else if (Action == "ClearAllWorkSource") {
            if (!confirm(MsgClearDefault + " : " + ProcessDate))
                return false;
            bolSetWS = false;
        }
        var ReqData = {
            ProcessDate: ProcessDate,
            bolSetWS: bolSetWS
        }
        ShowLoading(true);
        $.ajax({
            url: SetOrClearForAllWorksourcesURL,
            type: "POST",
            dataType: "json",
            data: JSON.stringify(ReqData),
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                if (result != null && result != undefined) {
                    if (result.Error == false) {
                        FillBODDateGrid(result.Result);
                        return;
                    }
                }
            },
            error: function (eror) {
                alert("Error occured. Please try again");
            },
            complete: function () {
                ShowLoading(false);
            }
        });
        document.getElementById("HDN_ProcessDate").value = ProcessDate;
        return true;
    }
    else {
        alert(MsgSelectDate);
        return false;
    }
}

function SelectNewDate(Date) {
    var matchDate = isNumericString(Date);
    if (formatData(matchDate) == "true") {
        return;
    }
    //var $row = $("tr td:nth-child(1):contains('" + matchDate + "')").closest('tr');
    var selector = "tr td:nth-child(1):contains('" + matchDate + "')";
    var $row = $(selector).closest('tr');
    if ($row.length > 0) {
        $($row[0]).addClass('highlight').siblings().removeClass('highlight');
        var Status = $("tr.highlight").find("td").eq(1).attr("data-status").trim();
        $("#lblProcessDate").text(matchDate);
        EnableDisableButtons(Status);
    }
    else {
        alert(MsgDateNotFound);
    }
}

function getHighlightRow() {
    return $('table > tbody > tr.highlight');
}

function EnableDisableButtons(Status) {
    if (Status == "2") {
        $("#btnCloseDate").removeClass('disabled');
        $("#btnReOpen").removeClass('disabled');
    }
    else if (Status == Msg_BODClosedStatus) {
        $("#btnCloseDate").addClass('disabled');
        $("#btnReOpen").removeClass('disabled');
    }
    else if (Status == Msg_BODOpenStatus) {
        $("#btnCloseDate").removeClass('disabled');
        $("#btnReOpen").addClass('disabled');
    }
    else {
        $("#btnCloseDate").addClass('disabled');
        $("#btnReOpen").addClass('disabled');
    }
}

function InsertNewDate() {
    var DateSelected = $("#createDateCtrl").val();
    var selectedSiteId = parseInt(siteDataList[$('#siteDropdownId')[0].selectedIndex].SiteId);
    if (DateSelected != "") {
        if (!ValidateDateIncultureSpecfic(DateSelected)) {
            document.getElementById("createDateCtrl").focus();
            return false;
        }
        var d = new Date(DateSelected);
        var month = d.getMonth() + 1;
        var day = d.getDate();
        var year = d.getFullYear();
        var stryr = year.toString();
        var shortyear = stryr.substring(2, 4);
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10) {
            day = '0' + day;
        }
        var ModDate = month.toString().concat(day.toString().concat(shortyear));
        var Action = $("#HDNaction").val();
        var $row = $("tr td:nth-child(1):contains('" + ModDate + "')");

        // Fetch the existing date details from the grid list
        var dateDetailList = JSON.parse(sessionStorage.getItem("DateResult"));

        var dateDetail = dateDetailList.filter(item => {
            return item.ProcessDate == ModDate;
        });

        var isSiteExist = false;

        if (dateDetail != null && dateDetail != undefined && dateDetail.length > 0) {
            let siteDateData = dateDetail[0].SiteIds;
            var existingSiteIds = [];
            var sites = siteDateData.SiteIds;
            var siteArray = siteDateData.split(',');
            let allSiteNotAvailable = false;

            if (selectedSiteId == 0) {
                isSiteExist = true;
            }
            else {
                if (siteArray.length > 0 && siteArray[siteArray.length - 1] != '') {

                    for (let i = 0; i < siteArray.length; i++) {
                        existingSiteIds.push(parseInt(siteArray[i]));
                    }

                    var existingSite = existingSiteIds.find(item => { return item == selectedSiteId });

                    if (existingSite != null && existingSite != undefined && existingSite != '') {
                        isSiteExist = true;
                    }
                }
            }
        }

        if (Action == "GoToDate") {
            if ($row.length > 0) {
                $("#myModal .modal-header .btn-close").trigger("click");
                SelectNewDate(ModDate);
                var rowFocus = (($("tr.highlight").position().top) - ($("tr.tableHeader").height()));
                $(".SelectionGridWrapper").mCustomScrollbar("scrollTo", rowFocus);
                return false;
            }
            else {
                alert(MsgDateNotFound);
                $("#myModal .modal-header .btn-close").trigger("click");
                return false;
            }
        }
        else if (Action == "NewDate") {
            if ($row.length > 0 && isSiteExist) {
                if (!confirm(ConfirmSynchronize)) {
                    $("#myModal .modal-header .btn-close").trigger("click");
                    return false;
                }
                else {
                    $("#myModal .modal-header .btn-close").trigger("click");
                }
            }
            var data = {
                ProcessDate: ModDate,
                SiteId: selectedSiteId
            }
            ShowLoading(true);
            $.ajax({
                url: CreateNewDateURL,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                success: function (result) {
                    if (result != null && result != undefined) {
                        if (result.Error == false && result.ErrorMessage != null && result.ErrorMessage != "") {
                            alert(result.ErrorMessage);
                            SelectNewDate(result.Result);
                            return;
                        }
                        $("#myModal .modal-header .btn-close").trigger("click");
                        FillBODDateGrid(result.Result);
                    }
                },
                error: function (eror) {
                    alert("Error occured. Please try again");
                },
                complete: function () {
                    ShowLoading(false);
                }
            });
            document.getElementById("HDN_ProcessDate").value = DateSelected;
            return true;
        }
        return false;
    }
    else {
        alert(MsgSelectDate);
        document.getElementById('createDateCtrl').focus();
        return false;
    }
}

function ValidateDateIncultureSpecfic(inputObj) {
    var ErrMsg = ValidDateFormat(inputObj);
    if (ErrMsg != "") {
        if (document.getElementById(inputObj) != null) {
            try { document.getElementById(inputObj).focus(); } catch (e) { }
        }
        alert(ErrMsg);
        return false;
    }
    return true;
}

function ShowHelp(strScreenName) {
    var strFilePath = "";
    try {
        if (strScreenName == "BODUtility") {
            strFilePath = "BOD_Utility/BOD_Operations.htm";
        }
        if (strFilePath != "") {
            strFilePath = "../BOD_WebHelpNew/" + strFilePath;
            newwindow = window.open(strFilePath, 'name', 'scrollbars=1,menubar=1,resizable=1,height=450,width=850');
            if (window.focus) {
                newwindow.focus()
            }
            return false;
        }
    }
    catch (err) {
        alert(err);
    }
}

function gridRowSelection(row) {
    var cell = row.getElementsByTagName("td")[0];
    var processDate = cell.innerHTML;
    var dateDetailList = JSON.parse(sessionStorage.getItem("DateResult"));
    var dateDetail = dateDetailList.filter(item => {
        return item.ProcessDate == processDate;
    });

    if (dateDetail != null && dateDetail != undefined && dateDetail.length > 0) {
        var closedSiteExists = dateDetail[0].SiteData.filter(item => { return item.Status == 'Closed' });
        if (closedSiteExists != null && closedSiteExists != undefined && closedSiteExists.length > 0) {
            $("#btnReOpen").removeAttr('disabled', 'disabled');
        }
        else {
            $("#btnReOpen").attr('disabled', 'disabled');
        }
    }
}

function FillBODDateGrid(NewDate) {
    ShowLoading(true);
    $.ajax({
        url: GetDateGridDetailsURL,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var DateResult = JSON.parse(result);
                if (DateResult != null) {
                    sessionStorage.setItem("DateResult", result);
                    $("#DateGrid tbody").empty();
                    var openStatus = 0;
                    var closeStatus = 0;
                    var dispStatusOpen;
                    var dispStatusClose;
                    for (var i = 0; i <= DateResult.length - 1; i++) {
                        var trRow = document.createElement("tr");
                        for (var j = 0; j < DateResult[i].SiteData.length; j++) {
                            var currentStatus = DateResult[i].SiteData[j].Status;
                            if (currentStatus == "Open") {
                                openStatus += 1;
                                dispStatusOpen = DateResult[i].SiteData[j].Status;
                            }
                            else {
                                closeStatus += 1;
                                dispStatusClose = DateResult[i].SiteData[j].Status;
                            }
                        }
                        if (openStatus == DateResult[i].SiteData.length)
                            var ProcessStatus = Msg_BODOpenStatus;
                        else if (closeStatus == DateResult[i].SiteData.length)
                            var ProcessStatus = Msg_BODClosedStatus;
                        else
                            var ProcessStatus = "2";
                        openStatus = 0;
                        closeStatus = 0;
                        var processDate = ValidateHTML(DateResult[i].ProcessDate);
                        var processStatus = ValidateHTML(ProcessStatus);
                        var resultStatus = ValidateHTML(DateResult[i].Status);
                        var openWS = ValidateHTML(DateResult[i].OpenWorksources);
                        $(trRow).append("<td>" + processDate + "</td>");
                        $(trRow).append("<td class='DateGridStatus' data-status='" + processStatus + "'>" + resultStatus + "</td>");
                        $(trRow).append("<td>" + openWS + "</td>");
                        trRow.onclick = gridRowSelection(trRow);
                        $("#DateGrid tbody").append(trRow);
                    }
                }
                if (NewDate != null) {
                    SelectNewDate(NewDate);
                    var rowFocus = (($("tr.highlight").position().top) - ($("tr.tableHeader").height()));
                    $(".SelectionGridWrapper").mCustomScrollbar("scrollTo", rowFocus);
                }

                if ($("#lblProcessDate").text() == "")
                    SelectFirstRow();

            }
        },
        error: function (eror) {
            alert("Error occured. Please try again");
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}
function isNumericString(input) {
    // Regular expression to match only numeric characters
    var numericRegex = /^[0-9]+$/;

    if (numericRegex.test(input))
        return input;

    // Test the input against the regex
    //return numericRegex.test(input);
}
function formatData(strData) {
    var strObj = "&gt;,%3e,set-cookie,having,%253e,%255cx3cscript,%3cscript,%5cx3cscript,#,%23,waitfor+delay,waitfor delay,<>";
    var strObjArr = strObj.split(",");
    for (var i = 0; i < strObjArr.length; i++) {
        if (strData.includes(strObjArr[i])) {
            return "true";
        }
        else {
            return "false";
        }
    }
}
function ValidateHTML(strResult) {
    var strData = ["SESSIONTIMEOUT", "WebForm_AutoFocus", "Session+Has+Expired", "AJAXEXCEPTION", "Vulnerable String Presents", "EMPTYIMAGE", "XmlHttpException", "Server encountered an error", "Server side exception", "System.Data.SqlClient.SqlException", "Unable to connect the server. Please contact Administrator", "Service Unavailable", "WarningMessage"];
    var strResult = String(strResult);
    for (var i = 0; i < strData.length; i++) {
        if (strResult.indexOf(strData[i]) >= 0)
            return "";
    }
    return strResult;
}