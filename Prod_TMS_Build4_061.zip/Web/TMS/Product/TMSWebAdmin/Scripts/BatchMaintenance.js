﻿const cAddJob = 41;
const cDeleteJob = 42;
const cChangeStatus = 43;
const cCarryOver = 44;
const cPriority = 45;
const cInUseBatches = 46;
const cResetBatches = 47;
const cChangeWorkSource = 77;
const cHoldBatchs = 48;
const cReleaseBatches = 49;
const cSkipPass2 = 79;
const cAddVirtualBatchPocketCut = 80;
const cGenerateVirtualBatch = 84;
const cViewBatch = 86;
const cResetVRRItems = 89;
const cP1BatchCollectVal = 16;
const cGetInUse = "GETINUSE";
const cGetNotInUse = "GETNOTINUSE";
const cGhold = "GETHOLDBATCH";
const cGRelease = "GETRELEASEBATCH";
const cGetPktCutAdd = "GETPKTCUTADD";
const cGetVirtualBatchToAdd = "GETP2EXBATCH";
var strBatchNo = "";
var strBatchValue = "";
var strSiteId = "";
var strSelectedWS = "";
var RegxNumber = /^\d+$/;
var LockedByUser = "";

const cUserKeying = 98;
const cUserBatches = 99;

const cDeleteChildBatchList = 100;
const cDeleteAddNotes = 101;
const cDeleteResult = 102;
const cDeleteBatchCreatedinTMS = 103;
const cConfirmDelete = 104;
const cConfirmDeleteOk = 105;
const cConfirmCW = 106;
const cConfirmCWOk = 107;
const cChangeWSNotes = 108;
const cCWDeleteChildBatchList = 109;
const cCWDeleteBatchCreatedinTMS = 110;

var GetBatchesURL = "";
var LoadSkipPass2EnabledWSForUserURL = "";
var LoadWorkSourceForSiteURL = "";
var GetSelectedActionDBObjectIdURL = "";
var IsUserKeyingURL = "";
var LoadBatchValuesURL = "";
var ChageBatchStatusURL = "";
var GetAllowPass2BatchDeleteToValidateURL = "";
var ValidateAndDeleteBatchInAllProductsURL = "";
var ValidateTMSBatchStatusURL = "";
var RevertBatchesToOriginalStatusURL = "";
var ValidateILBBatchStatusURL = "";
var ValidateNewBatchCreatedinTMSURL = "";
var ValidateDeleteInOtherProductsURL = "";
var DeleteBatchFromAllProductsURL = "";
var GetDeleteNotesURL = "";
var AddAuditAndMarkedProductForDeleteURL = "";
var AddJobControlEntryURL = "";
var AddVirtualPocketTriggerURL = "";
var Skip2PassURL = "";
var UpdatePriorityURL = "";
var ResetBatchesURL = "";
var GetHoldReasonURL = "";
var UpdateBatchHoldStatusURL = "";
var GenerateVirtualBatchURL = "";
var CheckProcessDateExistURL = "";
var CarryOverBatchesURL = "";
var BatchHasVRRPendingItemsURL = "";
var ValidateVRRPendingItemsURL = "";
var ResetVRRItemsURL = "";
var LoadWorkSourceAndBatchValueForChangeWorksourceURL = "";
var ValidateChangeWorksourceAndDeleteBatchInAllProductsURL = "";
var RevertBatchesToOriginalStatusForCWURL = "";
var ValidateTMSBatchStatusForCWURL = "";
var ValidateILBBatchStatusForCWURL = "";
var ValidateNewBatchCreatedinTMSForCWURL = "";
var ValidateDeleteInOtherProductsForCWURL = "";
var AddAuditAndMarkedProductForDeleteForCWURL = "";
var DeleteBatchFromAllProductsForCWURL = "";
var GetAnnotateBatchHeaderURL = "";
var AnnotateBatchHeaderAndDeleteImageFilesURL = "";
var CheckJobEntryRequiredURL = "";
var LoadErrorOccured = "";
var CheckValidBatchURL = "";

$(document).ready(function () {
    KendoLicensing.setScriptKey(KendoApiKey);
    if ($('#cmbSiteID option:eq(0)').text() == "msgAllSites") {
        location.reload();
    }

    if (LoadErrorOccured != undefined && LoadErrorOccured != null && LoadErrorOccured == 'True') {
        alert(MsgApperroccured);
        DisableAllControls();
    }
    if ($('#cmbWorkSrc').next("div").hasClass("ms-parent"))
        $('#cmbWorkSrc').multipleSelect('destroy');
    $("#cmbWorkSrc").multipleSelect({
        filter: true,
        singleRadio: true
    });
    $(".advFilterToggle").click(function () {
        $(".advSearchCtrlWrapper").slideToggle(function () {
            setHeight();
        });
        $(this).children("i").toggleClass("fa-angle-down");
    });

    setHeight();

    $('#myModal').on('shown.bs.modal', function () {
        $(this).find("#modal_btnClose").focus();
    });

    $("#modal_btnAccept").click(function () {
        var mode = $(this).attr('data-modalmode');
        var action = $("#cmbAction").val();

        switch (parseInt(mode)) {
            case cChangeStatus: {
                var strBatchValue = $("#modal_dropdown").val();
                if (strBatchValue == null || strBatchValue == undefined || strBatchValue == "-1") {
                    alert(MsgSelectBatchValue);
                    return;
                }
                UpdateBatchStatus(strBatchValue);                
                break;
            }
            case cUserKeying: {
                if (UserKeyingData != null && UserKeyingData != undefined && UserKeyingData.DtBatches.length > 0) {
                    if (action == cChangeStatus || action == cInUseBatches || action == cResetBatches || action == cHoldBatchs || action == cReleaseBatches) {
                        $("#myModal .modal-body").html("");
                        $("#myModal .modal-title").text(cUsersKeyingTitle);
                        $("#myModal #modal_btnAccept").text(cBtnCapionOk);
                        $("#myModal #modal_btnAccept").attr('data-modalmode', cUserBatches);
                        $("#myModal #modal_btnCancel").text(cBtnCapionCancel);
                        $("#myModal .modal-body").append("<p>" + MsgItemsFromBelow + "</p>");
                        $("#myModal .modal-body").append(GenerateModalFields(UserKeyingData.DtBatches, "grid", cUserBatches));
                        ShowAndHideModal(true);
                        return;
                    }
                }
                switch (parseInt(action)) {
                    case cChangeStatus:
                        ChangeBatchStatusModal();
                        break;
                    case cDeleteJob:
                        // Call method to check if the batch has VRR pending items.
                        IsBatchHasVRRPendingItems(cDeleteJob).then((data) => {
                            if (data)
                                DeleteValidationForProcessed();
                        });
                        break;
                    case cCarryOver:
                        CarryOverBatch();
                        break;
                    case cChangeWorkSource:
                        ShowChangeWorksourceModal();
                        break;
                    case cInUseBatches:
                        CheckJobEntryRequiredBeforeRelease(cGetInUse);
                        break;
                    case cResetBatches:
                        ReleaseInUse(false, cGetNotInUse);
                        break;
                    case cHoldBatchs:
                        ShowHoldReasonModal();
                        break;
                    case cReleaseBatches:
                        CheckJobEntryRequiredBeforeRelease(cGRelease);
                        break;
                }
                break;
            }
            case cUserBatches: {
                switch (parseInt(action)) {
                    case cChangeStatus:
                        ChangeBatchStatusModal();
                        break;
                    case cInUseBatches:
                        CheckJobEntryRequiredBeforeRelease(cGetInUse);
                        break;
                    case cResetBatches:
                        ReleaseInUse(false, cGetNotInUse);
                        break;
                    case cHoldBatchs:
                        ShowHoldReasonModal();
                        break;
                    case cReleaseBatches:
                        CheckJobEntryRequiredBeforeRelease(cGRelease);
                        break;
                }
                break;
            }
            case cPriority: {
                var strPriority = $("#modal_dropdown").val();
                if (strPriority == null || strPriority == "") {
                    alert(MsgPriorityValidation3);
                    return;
                } else if (strPriority != "") {
                    if (!(RegxNumber.test(strPriority))) {
                        alert(MsgPriorityValidation2);
                        return;
                    }
                    if (strPriority < 0 || strPriority > 99) {
                        alert(MsgPriorityValidation1);
                        return;
                    }
                }
                UpdatePriority(strPriority);
                break;
            }
            case cHoldBatchs: {
                var comment = $("#modal_text").val();
                if (comment == "") {
                    alert(MsgValidateHoldReason);
                    return;
                }
                UpdateHoldbatchStatus(comment);
                break;
            }
            case cDeleteChildBatchList: {
                ShowAndHideModal(false)
                ValidateNewBatchCreatedinTMS();
                break;
            }
            case cCWDeleteChildBatchList: {
                ShowAndHideModal(false)
                ValidateNewBatchCreatedinTMSForCW();
                break;
            }
            case cDeleteBatchCreatedinTMS: {
                ShowAndHideModal(false)
                ValidateDeleteInOtherProducts();
                break;
            }
            case cCWDeleteBatchCreatedinTMS: {
                ShowAndHideModal(false)
                ValidateDeleteInOtherProductsForCW();
                break;
            }
            case cConfirmDelete: {
                ShowAndHideModal(false)
                ShowAddDeleteNotesModal();
                break;
            }
            case cConfirmDeleteOk: {
                ShowAndHideModal(false)
                alert(MsgDeleteBatchFailed + strBatchNo);
                RevertBatchesToOriginalStatus();
                break;
            }
            case cDeleteAddNotes: {
                var txtNote = $("#modal_textarea").val();
                if (txtNote.trim() == "") {
                    alert(MsgEnterValidNotes);
                    return false;
                }
                ShowAndHideModal(false)
                DeleteBatchFromAllProducts(txtNote.trim());
                break;
            }
            case cDeleteResult: {
                ShowAndHideModal(false)
                DeleteBatchStatus = null;
                FillBatchData();
                break;
            }
            case cCarryOver: {
                if (!ValidateProcessedDate("txtmodaldate"))
                    return false;
                var strProcessDate = $("#txtProcDate").val();
                var strDate = $("#txtmodaldate").val();
                if (strProcessDate === strDate) {
                    alert(MsgCompareProcessDate);
                    $("#txtmodaldate").focus();
                    return false;
                }
                if (new Date(strProcessDate) > new Date(strDate)) {
                    if (!confirm(MsgCarrydateNotLessThan)) {
                        $("#txtmodaldate").focus();
                        return false;
                    }
                }
                // Call method to check if the batch has VRR pending items.
                IsBatchHasVRRPendingItems(cCarryOver).then((data) => {
                    if (data)
                        CheckCarryDateExist(strDate);
                });
                break;
            }
            case cChangeWorkSource: {
                var strWrkSrc = $("#dropdown_" + cChangeWorkSource + "_WS").find("#modal_dropdown").val();
                var strBatchVal = $("#dropdown_" + cChangeWorkSource + "_BV").find("#modal_dropdown").val();
                if (strWrkSrc == null || strWrkSrc == undefined || strWrkSrc == "-1") {
                    alert(MsgSelectWorksource);
                    return false;
                }
                if (strBatchVal == null || strBatchVal == undefined || strBatchVal == "-1") {
                    alert(MsgSelectBatch);
                    return false;
                }
                // Call method to check if the batch has VRR pending items.
                IsBatchHasVRRPendingItems(cChangeWorkSource).then((data) => {
                    if (data)
                        ValidateProcessedForChangeWorksource(strWrkSrc, strBatchVal);
                });
                break;
            }
            case cConfirmCW: {
                ShowAndHideModal(false)
                DeleteBatchFromAllProductsForCW();
                break;
            }
            case cConfirmCWOk: {
                ShowAndHideModal(false)
                alert(MsgChangeWSFailed + strBatchNo);
                RevertBatchesToOriginalStatusForCW();
                break;
            }
            case cChangeWSNotes: {
                var txtNote = $("#modal_textarea").val();
                if (txtNote.trim() == "") {
                    alert(MsgEnterValidNotes);
                    return false;
                }
                ShowAndHideModal(false)
                AnnotateAndDeleteImageFilesCW(txtNote);
                break;
            }
        }

    });

    $("#modal_btnCancel, #modal_btnClose").click(function () {
        var mode = $(this).attr('data-modalmode');
        var action = $("#cmbAction").val();
        if (mode == cConfirmDelete) {
            RevertBatchesToOriginalStatus();
            //FillBatchData();                 
        }
        else if (mode == cConfirmCW) {
            RevertBatchesToOriginalStatusForCW();
            //FillBatchData();
        }
    });

    $("#cmbAction").change(function () {
        SetEnableDisableForAction();
        SetOKButtonTextForAction();
        GetSelectedActionDBObjectId();
        var grid = $("#gridBatchMain").data("kendoGrid");
        if (grid != null && grid != undefined) {
            $("#gridBatchMain").empty();
        }
    });

    $("#cmbSiteID").change(function () {
        LoadWorksourceForSite();
    });

    $("#btnReset").click(function () {
        if ($('#cmbSiteID > option').length > 0)
            $('#cmbSiteID').val($('#cmbSiteID option:eq(0)').val());
        if ($('#cmbWorkSrc > option').length > 0)
            $('#cmbWorkSrc').val($('#cmbWorkSrc option:eq(0)').val());
        if ($('#cmbCurBatValue > option').length > 0)
            $('#cmbCurBatValue').val($('#cmbCurBatValue option:eq(0)').val());
        if ($('#cmbPrevBatVal > option').length > 0)
            $('#cmbPrevBatVal').val($('#cmbPrevBatVal option:eq(0)').val());
        if ($('#cmbBatMode > option').length > 0)
            $('#cmbBatMode').val($('#cmbBatMode option:eq(0)').val());        
        $('#txtBatFrom').val("");
        $('#txtBatTo').val("");
        var grid = $("#gridBatchMain").data("kendoGrid");
        if (grid != null && grid != undefined) {
            $("#gridBatchMain").empty();
        }
    });

    if ($('#cmbSiteID > option').length > 0 && $('#cmbSiteID > option').length == 2) {
        $('#cmbSiteID').val($('#cmbSiteID option:eq(1)').val());
    }
});

function setHeight() {
    var windowHit = $(window).height();
    var filterHit = $(".seatchCtrlSet").height();
    $("#gridBatchMain").css({ "height": (windowHit - (filterHit + 155)) + "px" });
    $(".bmGridWrapper .k-grid-content").css({ "height": ($("#gridBatchMain").height() - 70) + "px" });
    $(".bmGridWrapper .k-grid-header").css({ "padding-right": "0px" });
    $(".bmGridWrapper .k-grid-content").niceScroll();
}

function ShowCustomConfirmMessage(Message) {
    $("#hdnConfirmResult").val("");
    if (confirm(Message))
        $("#hdnConfirmResult").val("true");
    else
        $("#hdnConfirmResult").val("false");
}

function ShowCustomMessage(Message, Method) {
    alert(Message);
}

function ValidateBatchAndGetBatchNo() {
    var BatchGrid = $("#gridBatchMain").data("kendoGrid");
    if (BatchConfirm == null || BatchGrid == undefined) {
        alert(MsgNobatchisselected);
        return false;
    }
    var rows = BatchGrid.select();
    if (rows == null || rows == undefined || rows.length <= 0) {
        alert(MsgNobatchisselected);
        return false;
    }
    else if (rows.length > 1 && $("#cmbAction option:selected").val() == cDeleteJob) {
        alert(MsgMultipleBatchDelete);
        return false;
    }
    else if (rows.length > 1 && $("#cmbAction option:selected").val() == cChangeWorkSource) {
        alert(MsgMultipleBatchCW);
        return false;
    }
    else {
        strBatchNo = "";
        strBatchValue = "";
        strSiteId = "";
        strSelectedWS = "";
        LockedByUser = "";
        rows.each(function (index, row) {
            var selectedItem = BatchGrid.dataItem(row);
            if (selectedItem != null && selectedItem != undefined && selectedItem.BatchNo != "") {
                strBatchNo = strBatchNo + "," + selectedItem.BatchNo;
                strBatchValue = strBatchValue + "," + selectedItem.BatchValue;
                strSiteId = strSiteId + "," + selectedItem.SiteId;
                strSelectedWS = strSelectedWS + "," + selectedItem.WorkSrc;
                LockedByUser = LockedByUser + "," + selectedItem.Usercode;
            }
        });
    }

    if (strBatchNo[0] == ",")
        strBatchNo = strBatchNo.slice(1);
    if (strBatchValue[0] == ",")
        strBatchValue = strBatchValue.slice(1);
    if (strSiteId[0] == ",")
        strSiteId = strSiteId.slice(1);
    if (strSelectedWS[0] == ",")
        strSelectedWS = strSelectedWS.slice(1);
    if (LockedByUser[0] == ",")
        LockedByUser = LockedByUser.slice(1);

    return true;
}

function BatchConfirm() {
    var Action = $("#cmbAction option:selected").val();

    if (Action == cGenerateVirtualBatch) {
        if (!ValidateMandatoryFields(Action) || !ValidateProcessedDate("txtProcDate"))
            return false;

        GenerateVirtualBatch();
    }
    else {
        if (!ValidateBatchAndGetBatchNo())
            return false;
    }


    if (Action == cAddJob) {
        AddJob();
    }
    else if (Action == cPriority) {
        ShowPriorityModal();
    }
    else if (Action == cHoldBatchs) {
        if (!confirm(MsgConfirmHoldBatchs)) {
            return false;
        }
        IsUserKeying(strBatchNo, MsgItemsFromUser, MsgItemsFromBelow);
    }
    else if (Action == cReleaseBatches) {
        GetHoldReason();
    }
    else if (Action == cAddVirtualBatchPocketCut) { //cAddVirtualBatchPocketCut
        if (!confirm(PSGMessage471)) {
            return false;
        }
        AddVirtualPocketTrigger();
    }
    else if (Action == cResetVRRItems) { // Unlock reject reprocess items
        if (!confirm(PSGMessage486)) {
            return false;
        }
        ResetVRRItems();
    }
    else if (Action == cSkipPass2) { //cSkipPass2 
        if (!confirm(PSGMessage466))
            return false;
        Skip2Pass();
    }
    else if (Action == cDeleteJob) { //cDeleteJob
        if (!confirm(PSGMessage419)) {
            return false;
        }
        IsUserKeying(strBatchNo, MsgUserKeyingDelete);

    }
    else if (Action == cCarryOver || Action == cChangeWorkSource) { //CarryOver        
        IsUserKeying(strBatchNo, MsgUserKeyingDelete);
    }
    else if (Action == cChangeStatus || Action == cInUseBatches
        || Action == cResetBatches) { //cChaneStatus or InUseBatches
        if (Action == cChangeStatus) {
            CheckIsValidBatch(strBatchNo).then(function (isValid) {
                if (!isValid) {
                    IsUserKeying(strBatchNo, MsgItemsFromUser, MsgItemsFromBelow);
                }
            });
        }
        else {
            IsUserKeying(strBatchNo, MsgItemsFromUser, MsgItemsFromBelow);
        }
    }
    return false;
}

function FillBatchData() {
    var Action = $("#cmbAction").val();
    strBatchValue = "";
    strBatchNo = "";

    if (!ValidateProcessedDate("txtProcDate") || !ValidateMandatoryFields(Action) || !ValidateBatchNumber())
        return false;

    $.ajax({
        url: GetBatchesURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(GetFilterReqData()),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data != null && data != undefined) {
                var grid = $("#gridBatchMain").data("kendoGrid");
                var BatchData = JSON.parse(data);
                if (BatchData.Error == false && BatchData.dtBatchDetails != null) {
                    GenerateGrid(BatchData);
                    var grid = $("#gridBatchMain").data("kendoGrid");
                    var new_data = BatchData.dtBatchDetails;
                    grid.dataSource.data(new_data);
                    grid.refresh();
                    setHeight();
                }
                else if (BatchData.Error == true) {
                    if (BatchData.ErrorMessage == null)
                        BatchData.ErrorMessage = MsgProcDateNotExist;
                    var new_data = BatchData.dtBatchDetails;
                    if (grid != null && grid != undefined) {
                        grid.dataSource.data(new_data);
                        grid.refresh();
                    }
                    alert(BatchData.ErrorMessage);
                    var BatchDataCtrl = BatchData.ControlToFocus;
                    if (BatchDataCtrl && /^[a-zA-Z0-9_-]+$/.test(BatchDataCtrl)) {
                        var el = document.getElementById(BatchDataCtrl);
                        if (el) el.focus();
                    }
                }
            }
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        }
    });
    return false;

}

function LoadWorksourceForSite() {
    var SelectedAction = $("#cmbAction").val();
    var ReqData = {
        Action: SelectedAction,
        SiteId: $("#cmbSiteID").val()
    }

    $.ajax({
        url: LoadWorkSourceForSiteURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data != null && data != undefined) {
                var WorksrcData = data;
                if (WorksrcData != null && WorksrcData.length > 0) {
                    $("#cmbWorkSrc").empty();
                    $.each(WorksrcData, function () {
                        $("#cmbWorkSrc").append($("<option     />").val(this.WorkSrc).text(this.WorkSourceDesc));
                    });
                    var length = $('#cmbWorkSrc > option').length;
                    if (SelectedAction == cGenerateVirtualBatch && length > 0) {
                        $("#cmbWorkSrc").val($("#cmbWorkSrc option:eq(0)").val());
                    }
                    else if (length == 2) {
                        $("#cmbWorkSrc").val($("#cmbWorkSrc option:eq(1)").val())
                    }
                    else
                        $("#cmbWorkSrc").val($("#cmbWorkSrc option:eq(0)").val());

                }
                else {
                    alert(MsgWorkSrcNotAssigned);
                    $("#cmbWorkSrc").empty();
                    return false;
                }
                if ($('#cmbWorkSrc').next("div").hasClass("ms-parent"))
                    $('#cmbWorkSrc').multipleSelect('destroy');
                $("#cmbWorkSrc").multipleSelect({
                    filter: true,
                    singleRadio: true
                });
            }
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        }
    });
}

function GetSelectedActionDBObjectId() {
    var SelectedAction = $("#cmbAction").val();
    var ReqData = {
        Action: SelectedAction
    }

    $.ajax({
        url: GetSelectedActionDBObjectIdURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data != null && data != "") {
                $("#hdnSelectedDBObjectID").val(data);
                return;
            }
            $("#hdnSelectedDBObjectID").val();
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        }
    });
}

function LoadSkipPass2EnabledWSForUser() {
    var ReqData = {
        Action: $("#cmbAction").val(),
        SiteId: $("#cmbSiteID").val()
    }

    $.ajax({
        url: LoadSkipPass2EnabledWSForUserURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data != null && data != undefined) {
                var WorksrcData = data;
                if (WorksrcData != null) {
                    $("#cmbWorkSrc").empty();
                    $.each(WorksrcData, function () {
                        $("#cmbWorkSrc").append($("<option     />").val(this.WorkSrc).text(this.WorkSourceDesc));
                    });
                    var length = $('#cmbWorkSrc > option').length;
                    if (length == 2) {
                        $("#cmbWorkSrc").val($("#cmbWorkSrc option:eq(1)").val());
                    }
                }
                else {
                    alert(MsgWorkSrcNotAssigned);
                    $("#cmbWorkSrc").empty();
                    return false;
                }
                if ($('#cmbWorkSrc').next("div").hasClass("ms-parent"))
                    $('#cmbWorkSrc').multipleSelect('destroy');
                $("#cmbWorkSrc").multipleSelect({
                    filter: true,
                    singleRadio: true
                });
            }
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        }
    });
}

function ValidateProcessedDate(EleId) {
    var DateVal = $("#" + EleId).val();
    if (DateVal == "") {
        alert(MsgEnterValidProcDate);
        $("#" + EleId).focus();
        return false;
    }
    else {
        if (!ValidateDateIncultureSpecfic(EleId))
            return false;
    }
    return true;
}

function GetFilterReqData() {
    var postData = "";

    //postData = postData + "&ProcessDate=" + $("#txtProcDate").val();
    //postData = postData + "&WorkSource=" + $("#cmbWorkSrc").val();
    //postData = postData + "&SiteId=" + $("#cmbSiteID").val();
    //postData = postData + "&CurrentBatchVale=" + $("#cmbCurBatValue").val();
    //postData = postData + "&PreviousBatchValue=" + $("#cmbPrevBatVal").val();
    //postData = postData + "&BatchMode=" + $("#cmbBatMode").val();
    //postData = postData + "&BatchFrom=" + $("#txtBatFrom").val();
    //postData = postData + "&BatchTo=" + $("#txtBatTo").val();
    //postData = postData + "&SelectedAction=" + $("#cmbAction").val();
    //postData = postData + "&SelectedDBObjectID=" + $("#hdnSelectedDBObjectID").val()

    var data = {
        ProcessDate: $("#txtProcDate").val(),
        WorkSource: $("#cmbWorkSrc").val(),// == 1 ? true : false,
        SiteId: $("#cmbSiteID").val(),
        CurrentBatchVale: $("#cmbCurBatValue").val(),
        PreviousBatchValue: $("#cmbPrevBatVal").val(),
        BatchMode: $("#cmbBatMode").val(),
        BatchFrom: $("#txtBatFrom").val(),
        BatchTo: $("#txtBatTo").val(),
        Action: $("#cmbAction").val(),
        SelectedDBObjectID: $("#hdnSelectedDBObjectID").val()
    }
    return data;
}

function ValidateMandatoryFields(Action) {

    if (Action == cGenerateVirtualBatch) {
        if ($("#cmbSiteID option:selected").index() <= 0) {
            alert(MsgSelectValidSite);
            $("#cmbSiteID").focus();
            return false;
        }
    }
    else {
        if ($("#cmbSiteID option:selected").index() < 0) {
            alert(MsgSelectValidSite);
            $("#cmbSiteID").focus();
            return false;
        }
    }

    if ($("#cmbWorkSrc option:selected").index() < 0) {
        alert(MsgSelectWorkSrc);
        $("#cmbWorkSrc").focus();
        return false;
    }
    return true;
}

function ValidateBatchNumber() {
    var BatchFrom = $("#txtBatFrom").val();
    var BatchTo = $("#txtBatTo").val();
    if ((BatchFrom == "") || (BatchFrom != "" && RegxNumber.test(BatchFrom))) {
        if ((BatchTo == "") || (BatchTo != "" && RegxNumber.test(BatchTo))) {
            return true;
        }
        else {
            alert(MsgEnterValidBatchT);
            $("#txtBatTo").focus();
            return false;
        }
    }
    else {
        alert(MsgEnterValidBatchF);
        $("#txtBatFrom").focus();
        return false;
    }
}

var UserKeyingData;
function IsUserKeying(BatchNo, strUserMsg, strBatchMsg) {
    if (BatchNo == "")
        BatchNo == strBatchNo;

    var Action = $("#cmbAction").val();
    var data = {
        ProcDate: $("#txtProcDate").val(),
        SiteId: $("#cmbSiteID").val(),
        BatchNo: BatchNo
    }
    ShowLoading(true);
    return $.ajax({
        url: IsUserKeyingURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                UserKeyingData = JSON.parse(result);
                if (UserKeyingData.IsUserKeying == true) {
                    if (UserKeyingData.DtUsers != null && UserKeyingData.DtUsers.length > 0) {
                        $("#myModal .modal-body").html("");
                        $("#myModal .modal-title").text(cUsersKeyingTitle);
                        $("#myModal #modal_btnAccept").text(cBtnCapionOverride);
                        if (parseInt(Action)==cCarryOver)
                            $("#myModal #modal_btnAccept").hide();
                        else
                            $("#myModal #modal_btnAccept").show();
                        $("#myModal #modal_btnAccept").attr('data-modalmode', cUserKeying);
                        $("#myModal #modal_btnCancel").text(cBtnCapionOk);
                        $("#myModal #modal_btnCancel").show();
                        $("#myModal .modal-body").append("<p>" + strUserMsg + "</p>");
						$("#myModal .modal-body").append("<div class='BatchGridWrapper freeze_header' style='max-height: calc(100vh - 280px); overflow: auto;'></div>");
                        $("#myModal .modal-body .BatchGridWrapper").append(GenerateModalFields(UserKeyingData.DtUsers, "grid", cUserKeying));
                        ShowAndHideModal(true);
						stickyTable("nice");
                        return;
                    }
                    else if (UserKeyingData.DtBatches != null && UserKeyingData.DtBatches.length > 0) {
                        $("#myModal .modal-body").html("");
                        $("#myModal .modal-title").text(cUsersKeyingTitle);
                        $("#myModal #modal_btnAccept").text(cBtnCapionOk);
                        $("#myModal #modal_btnAccept").attr('data-modalmode', cUserBatches);
                        $("#myModal #modal_btnCancel").text(cBtnCapionCancel);
                        $("#myModal .modal-body").append("<p>" + strBatchMsg + "</p>");
                        $("#myModal .modal-body").append(GenerateModalFields(UserKeyingData.DtBatches, "grid", cUserBatches));
                        ShowAndHideModal(true);
                        return;
                    }
                }
            }

            switch (parseInt(Action)) {
                case cChangeStatus:
                    ChangeBatchStatusModal();
                    break;
                case cDeleteJob:
                    // Call method to check if the batch has VRR pending items.
                    IsBatchHasVRRPendingItems(cDeleteJob).then((data) => {
                        if (data)
                            DeleteValidationForProcessed();
                    });
                    break;
                case cCarryOver:
                    CarryOverBatch();
                    break;
                case cChangeWorkSource:
                    ShowChangeWorksourceModal();
                    break;
                case cInUseBatches:
                    CheckJobEntryRequiredBeforeRelease(cGetInUse);
                    break;
                case cResetBatches:
                    ReleaseInUse(false, cGetNotInUse);
                    break;
                case cHoldBatchs:
                    ShowHoldReasonModal();
                    break;
                case cReleaseBatches:
                    CheckJobEntryRequiredBeforeRelease(cGRelease);
                    break;
            }

            return false;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ChangeBatchStatusModal() {
    ShowLoading(true);
    var ReqData = {
        "Worksource": strSelectedWS
    }
    $.ajax({
        url: LoadBatchValuesURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.length > 0) {
                    $("#myModal .modal-body").html("");
                    $("#myModal .modal-title").text(cChangeBatchTitle);
                    var divFH = document.createElement("div");
                    divFH.className = "mt-2";
                    var select = GenerateModalFields(JsonResult, "dropdown", cChangeStatus, cDefaultBatch);
                    $(divFH).append('<div class="form-group"><label class="col-form-label text-sm-right col-sm-3">Batch Value :</label><div class="col-sm-8" id="dropdown_' + cChangeStatus + '"></div></div>');
                    $(divFH).find("#dropdown_" + cChangeStatus + "").append(select);
                    $("#myModal .modal-body").append(divFH);
                    $("#myModal #modal_btnAccept").text(cBtnCapionChange);
                    $("#myModal #modal_btnAccept").attr('data-modalmode', cChangeStatus);
                    $("#myModal #modal_btnCancel").text(cBtnCapionClose);
                    ShowAndHideModal(true);
                }
            }
            else {
                alert(MsgBatchValuesNotFound);
                return false;
            }
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function GenerateGrid(datasource) {
    ShowLoading(true);
    var grid = $("#gridBatchMain").data("kendoGrid");
    if (grid != undefined)
        grid.destroy();
    $("#gridBatchMain").empty();
    var columns = GenerateColumns(datasource.dtGridSettings);
    var model = GenerateModel(datasource.dtGridSettings);
    var grid = $("#gridBatchMain").kendoGrid({
        autoBind: false,
        dataSource: {
            data: datasource.dtBatchDetails,
            schema: {
                model: model
            }
        },
        columns: columns,
        filterable: {
            mode: "row"
        },
        height: 400,
        scrollable: true,
        selectable: false,
        noRecords: false,
        pageable: false,
        sortable: true,
        dataBound: function (e) {
            setHeight();
            ShowLoading(false);
        }
    });

}

function GenerateColumns(gridSettings) {
    if (gridSettings == null || gridSettings == undefined)
        return;
    var columns = [];
    if (gridSettings.length > 0) {
        for (var i = 0; i <= gridSettings.length - 1; i++) {
            var column = gridSettings[i].Column1.split("|");
            if (column != undefined) {
                columns.push({
                    field: column[0],
                    title: (column[1] == "") ? column[0] : column[1],
                    width: column[2] + "px",
                    selectable: (i == 0) ? true : false,
                    filterable: (i == 0) ? false : { cell: { inputWidth: "100%", operator: "contains", suggestionOperator: "contains", showOperators: false } },
                    sortable: (i == 0) ? false : true
                });
            }
        }
    }
    return columns;
}

function GenerateModel(gridSettings) {
    if (gridSettings == null || gridSettings == undefined)
        return;
    var model = {};
    var fields = {};
    if (gridSettings.length > 0) {
        for (var i = 0; i <= gridSettings.length - 1; i++) {
            var column = gridSettings[i].Column1.split("|");
            if (column != undefined) {
                fields[column[0]] = { type: "string" };
            }
        }
    }
    model.fields = fields;
    return model;
}

function GenerateModalFields(Datasource, mode, Action, defaultValue) {
    if ((Datasource == null || Datasource == undefined) && mode != "datetime")
        return;

    if (mode == "dropdown") {
        var select = document.createElement("select");
        $(select).attr('class', 'form-control form-control_Cust');
        $(select).attr('id', 'modal_dropdown');
        $(select).attr('data-modalmode', Action);
        $(select).attr('onchange', 'ModalDropdownChange()');
        if (defaultValue != null) {
            var option = document.createElement("option")
            option.text = defaultValue;
            option.value = "-1";
            select.options.add(option);
        }

        for (var i = 0; i <= Datasource.length - 1; i++) {
            var option = document.createElement("option")
            if (Object.keys(Datasource[i]).length > 1)
                option.text = Datasource[i][Object.keys(Datasource[i])[1]];
            else
                option.text = Datasource[i][Object.keys(Datasource[i])[0]];
            option.value = Datasource[i][Object.keys(Datasource[i])[0]];
            select.options.add(option);
        }
        return select;
    }
    else if (mode == "grid" && (Action == cUserKeying || Action == cUserBatches || Action == cDeleteChildBatchList || Action == cConfirmDelete ||
        Action == cConfirmDeleteOk || Action == cCWDeleteBatchCreatedinTMS || Action == cCWDeleteChildBatchList || Action == cConfirmCW || Action == cConfirmCWOk)) {
        if (Datasource == null || Datasource == undefined)
            return;

        var table = document.createElement("table");
        var tbody = document.createElement("tbody");
        $(table).attr('class', 'table table-hover table-striped freeze_Table cont_TableCustom');
        var tr = document.createElement('tr');
        $(tr).attr('class', 'tableHeader')
        var lth = Object.keys(Datasource[0]).length;
        for (var j = 0; j <= lth - 1; j++) {
            var tdh = document.createElement("th");
            $(tdh).text(Object.keys(Datasource[0])[j]);
            $(tr).append($(tdh));
        }
        $(tbody).append($(tr));
        for (var i = 0; i <= Datasource.length - 1; i++) {
            var trr = document.createElement('tr');
            for (var j = 0; j <= lth - 1; j++) {
                var td = document.createElement("td");
                $(td).text(Datasource[i][Object.keys(Datasource[i])[j]]);
                $(trr).append($(td));
            }
            $(tbody).append($(trr));
        }
        $(table).append($(tbody));
        return table;
    } else if (mode == "text") {
        var txt = document.createElement("input");
        txt.type = "text";
        txt.id = "modal_text";
        $(txt).attr('class', 'form-control form-control_Cust');
        return txt;
    } else if (mode == "datetime") {
        var divFH = document.createElement("div");
        var divFG = document.createElement("div");
        var divIG = document.createElement("div");
        var divIGA = document.createElement("div");
        var divCol = document.createElement("div");
        var spanCalender = document.createElement("span");
        var todaydate = populateTodaydate();
        divFH.className = "mt-2";
        divFG.className = "form-group";
        divIGA.className = "input-group-append";
        divCol.className = "col-sm-6";
        divIG.className = "input-group searchCustDate";
        spanCalender.className = "fa fa-calendar input-group-text p-2 border-0 bg-transparent";
        $(spanCalender).attr("onmouseover", "fnInitCalendar(this, 'txtmodaldate', 'style=PSGStyles.css,close=true')");

        $(divIG).css('float', 'none');
        $(divFG).append('<span class="col-form-label text-sm-right col-sm-4">' + cCarryOverTitle + '</span>');
        $(divIG).append('<input id="txtmodaldate" data-modalmode=' + Action + ' type="text" value="' + todaydate + '" class="form-control form-control_Cust" data-datable="mmddyyyy" data-datable-divider="/">');
        $(divIG).append($(divIGA));
        $(divIGA).append($(spanCalender));
        $(divCol).append($(divIG));
        $(divFG).append($(divCol));
        $(divFH).append($(divFG));
        return divFH;
    }
}

function DeleteValidationForProcessed() {
    var BatchGrid = $("#gridBatchMain").data("kendoGrid");
    var rows = BatchGrid.select();
    if (rows != null && rows != undefined && rows.length > 0) {
        var selectedItem = BatchGrid.dataItem(rows[0]);
        if (selectedItem != null && selectedItem != undefined) {
            var strPcCreated = selectedItem["PCCreated"];
            var strProcessedInPass2 = selectedItem["ProcessedInPass2"];
            var strECSProcessed = selectedItem["ECSprocessed"];

            var FilterData = {
                SiteId: selectedItem["SiteId"],
                strWorkSource: selectedItem["WorkSrc"],
                BatchKey: selectedItem["BatchKey"],
                ProcessDate: $("#txtProcDate").val(),
                BatchNo: strBatchNo

            }
            ShowLoading(true);
            $.ajax({
                url: GetAllowPass2BatchDeleteToValidateURL,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(FilterData),
                contentType: "application/json; charset=utf-8",
                success: function (resp) {
                    var bolProceed = true;
                    if (resp != null && resp != undefined) {
                        var result = JSON.parse(resp);
                        if (result != null && result != undefined) {
                            if (result.Error == false) {
                                if (strProcessedInPass2 == 'Y' || strECSProcessed == 'Y') {
                                    if (result.AllowPass2BatchDelete == 'Yes') {
                                        if (strProcessedInPass2 == "Y" && !confirm(strBatchNo + MsgConfPass2Delete))
                                            bolProceed = false;
                                    }
                                    else {
                                        if (strECSProcessed == "Y") {
                                            alert(strBatchNo + MsgECSProcessedDelete);
                                            bolProceed = false;
                                        }
                                    }
                                }

                                if (strPcCreated == 'R') {
                                    alert(MsgDeleteBatchcannotBePerformed)
                                    bolProceed = false;
                                }

                                if (strPcCreated == 'H' && result.IsVirtualBatchExists) {
                                    alert(MsgVirutalBatchExist + strBatchNo);
                                    bolProceed = false;
                                }

                                if (result.TaskResult == false)
                                    bolProceed == false;

                            }
                            else if (result.Error == true && result.ErrorMessage != "") {
                                alert(result.ErrorMessage);
                                return false;
                                bolProceed = false;
                            }
                            else if (result.Error == true && result.ErrorMessage == "") {
                                return false;
                                bolProceed = false;
                            }
                        }
                    }
                    if (bolProceed) {
                        ValidateAndDeleteBatchInAllProducts();
                        return true;
                    }
                    else {
                        FillBatchData();
                    }
                },
                error: function (error) {
                    alert(MsgExceptionDelete);
                    RevertBatchesToOriginalStatus
                    return false;
                },
                complete: function () {
                    ShowLoading(false);
                }
            });

        }

    }
    return true;
}

var DeleteBatchStatus = null;
function ValidateAndDeleteBatchInAllProducts() {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "InputData": GetFilterReqData()

    }
    ShowLoading(true);
    $.ajax({
        url: ValidateAndDeleteBatchInAllProductsURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    if (JsonResult.Error == false) {
                        DeleteBatchStatus = JsonResult.objDeleteBatch;
                        ValidateTMSBatchStatus();
                        return true;
                    }
                    else {
                        if (JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            RevertBatchesToOriginalStatus();
                            return false;
                        }
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateTMSBatchStatus() {
    if (strBatchNo == "")
        return;

    if (DeleteBatchStatus == null)
        ValidateAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateTMSBatchStatusURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && JSON.parse(result) != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    if (JsonResult.Error == false) {
                        DeleteBatchStatus = JsonResult.objDeleteBatch;
                        ValidateILBBatchStatus();
                    }
                    else {
                        if (JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            RevertBatchesToOriginalStatus();
                            return false;
                        }
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateILBBatchStatus() {
    if (strBatchNo == "")
        return;

    if (DeleteBatchStatus == null)
        ValidateAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateILBBatchStatusURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    DeleteBatchStatus = JsonResult.objDeleteBatch;
                    if (JsonResult.Error == false) {
                        ValidateNewBatchCreatedinTMS();
                    }
                    else if (JsonResult.Error == true && JsonResult.DsPopupDetails != null && JsonResult.DsPopupDetails["ChildBatchList"].length > 0) {
                        ShowChildBatchListModal(JsonResult.DsPopupDetails["ChildBatchList"], cDeleteChildBatchList);
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateNewBatchCreatedinTMS() {
    if (strBatchNo == "")
        return;

    if (DeleteBatchStatus == null)
        ValidateAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo,
        "objDeleteBatchDetails": DeleteBatchStatus
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateNewBatchCreatedinTMSURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    DeleteBatchStatus = JsonResult.objDeleteBatch;
                    if (JsonResult.Error == false) {
                        if (DeleteBatchStatus.DeleteBatchResult.ECSStatus == 2 || DeleteBatchStatus.DeleteBatchResult.ECSStatus == 3) {
                            if (!(DeleteBatchVars.UserAuthLevel < DeleteBatchVars.AuthlevelToDeleteICLJobCreatedBatch)) {
                                if (!confirm(MsgConfirECSDelete)) {
                                    RevertBatchesToOriginalStatus();
                                    //FillBatchData();
                                    DeleteBatchStatus.DeleteBatchResult.UserCancelledDelete = true;
                                    return false;
                                }
                            }
                        }
                        ValidateDeleteInOtherProducts();
                    }
                    else if (JsonResult.Error == true && JsonResult.DsPopupDetails != null && JsonResult.DsPopupDetails["ChildBatchList"].length > 0) {
                        ShowChildBatchListModal(JsonResult.DsPopupDetails["ChildBatchList"], cDeleteBatchCreatedinTMS);
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateDeleteInOtherProducts() {
    if (strBatchNo == "")
        return;

    if (DeleteBatchStatus == null)
        ValidateAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateDeleteInOtherProductsURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    DeleteBatchStatus = JsonResult.objDeleteBatch;
                    if (!(DeleteBatchStatus.DeleteBatchVars.UserAuthLevel < DeleteBatchStatus.DeleteBatchVars.AuthlevelToDeleteICLJobCreatedBatch) && DeleteBatchStatus.DeleteBatchResult.ECSStatus == 2 || DeleteBatchStatus.DeleteBatchResult.ECSStatus == 3) {
                        if (!confirm(MsgConfirmECStoDelete))
                            AddAuditAndMarkedProductForDelete("false");
                        else
                            AddAuditAndMarkedProductForDelete("true");
                    }
                    else {
                        ShowConfirmDeleteModal();
                        return true;
                    }
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatus();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function AddAuditAndMarkedProductForDelete(bolValue) {
    var ReqData = {
        "bolAddProduct": bolValue

    }
    ShowLoading(true);
    $.ajax({
        url: AddAuditAndMarkedProductForDeleteURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    DeleteBatchStatus = JsonResult.objDeleteBatch;
                    ShowConfirmDeleteModal();
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "")
                        alert(JsonResult.ErrorMessage);
                    RevertBatchesToOriginalStatus();
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function AddJob() {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: AddJobControlEntryURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    alert(MsgJobAdded);
                    FillBatchData();
                    return true;
                }
                else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                    alert(JsonResult.ErrorMessage);
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function Skip2Pass() {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: Skip2PassURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    FillBatchData();
                    return true;
                }
                else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                    alert(JsonResult.ErrorMessage);
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ResetVRRItems() {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "WorkSrc": strSelectedWS,
        "Usercodes": LockedByUser,
        "InputData": GetFilterReqData()
    }
    ReqData.InputData.SiteId = strSiteId.split(',')[0];
    ShowLoading(true);
    $.ajax({
        url: ResetVRRItemsURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    alert(PSGMessage485);
                    FillBatchData();
                    return true;
                }
                else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                    alert(JsonResult.ErrorMessage);
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ShowPriorityModal() {
    if (strBatchNo == "")
        return;
    var JsonResult = [];

    for (var i = 0; i <= 99; i++) {
        JsonResult.push({
            Id: i,
            text: i
        });
    }

    $("#myModal .modal-body").html("");
    $("#myModal .modal-title").text(cSetPriorityTitle);
    var divFH = document.createElement("div");
    divFH.className = "mt-2";
    var select = GenerateModalFields(JsonResult, "dropdown", cPriority, "");
    $(divFH).append('<div class="form-group"><label class="col-form-label text-sm-right col-sm-3">' + cPriorityLblCaption + '</label><div class="col-sm-8" id="dropdown_' + cPriority + '"></div></div>');
    $(divFH).find("#dropdown_" + cPriority + "").append(select);
    $("#myModal .modal-body").append(divFH);
    $("#myModal #modal_btnAccept").text(cPriorityBtnCaption);
    $("#myModal #modal_btnAccept").attr('data-modalmode', cPriority);
    $("#myModal #modal_btnCancel").text(cBtnCapionClose);
    ShowAndHideModal(true);

}

function UpdatePriority(strPriority) {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "strPriority": strPriority,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: UpdatePriorityURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ShowAndHideModal(false)
                    alert(MsgPrioritySuccess);
                    FillBatchData();
                    return true;
                }
                else if (JsonResult.Error == true) {
                    alert(MsgPriorityFail);
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function CheckJobEntryRequiredBeforeRelease(action) {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "ActionTo": action,        
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    
     var strMsg = action == cGRelease ? MsgConfirmReleaseBatch : MsgConfirmResetBatches;
     canAddJob = false;
        if (confirm(strMsg)) {
            canAddJob = true;
    }

    ReleaseInUse(canAddJob, action);
    ShowLoading(false);

    //confirm message to be displayed irrespective of if job entry reqd or not .
    //$.ajax({
    //    url: CheckJobEntryRequiredURL,
    //    type: "POST",
    //    dataType: "json",
    //    data: JSON.stringify(ReqData),
    //    contentType: "application/json; charset=utf-8",
    //    success: function (result) {
    //        if (result != null && result != undefined) {                
    //            var canAddJob = false;
    //            if (result.Error == false && (result.ErrorMessage == null || result.ErrorMessage =='')) {                    
    //                var strMsg = action == cGRelease ? MsgConfirmReleaseBatch : MsgConfirmResetBatches;
    //                if (confirm(strMsg)) {
    //                    canAddJob = true;
    //                }
    //            }
    //            ReleaseInUse(canAddJob, action);
    //        }
    //    },
    //    error: function (eror) {           
    //        if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
    //            document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
    //        }
    //        return false;
    //    },
    //    complete: function () {
    //        ShowLoading(false);
    //    }
    //});    
}


function ReleaseInUse(canAddJob, action) {
    if (strBatchNo == "")
        return;

    //var canAddJob = true;
    //var strMsg = action == cGRelease ? MsgConfirmReleaseBatch : MsgConfirmResetBatches;
    //if (!confirm(strMsg)) {
    //    canAddJob = false;
    //}

    var ReqData = {
        "BatchNo": strBatchNo,
        "ActionTo": action,
        "bolAddJob": canAddJob,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: ResetBatchesURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                ShowAndHideModal(false)
                if (JsonResult.Error == false) {
                    switch (action) {
                        case cGetInUse:
                            alert(MsgRetrievedSuccess);
                            break;
                        case cGetNotInUse:
                            alert(MsgResetSuccess);
                            break;
                        case cGRelease:
                            alert(MsgBatchReleaseSuccess);
                            break;
                    }
                }
                else if (JsonResult.Error == true) {
                    switch (action) {
                        case cGetInUse:
                            alert(MsgRetrievalFailed);
                            break;
                        case cGetNotInUse:
                            alert(MsgResetFailed);
                            break;
                        case cGRelease:
                            alert(MsgBatchReleaseFailed);
                            break;
                    }
                }

                FillBatchData();
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function GetHoldReason() {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "ProcessDate": $("#txtProcDate").val(),
        "SiteId": strSiteId,
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    return $.ajax({
        url: GetHoldReasonURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined && result != "") {
                var msgResult = result;
                if (msgResult != null && msgResult != "") {
                    msg = msgResult;
                }
            }
            if (!confirm(msg)) {
                return false;
            }
            IsUserKeying(strBatchNo, MsgItemsFromUser, MsgItemsFromBelow);
        },
        error: function (error) {
            console.log(error);
            if (error.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });

}

function ShowHoldReasonModal() {
    if (strBatchNo == "")
        return;

    $("#myModal .modal-body").html("");
    $("#myModal .modal-title").text(cHoldBatchTitle);
    var text = GenerateModalFields("", "text", cHoldBatchs, "");
    $("#myModal .modal-body").append('<div class="form-group"><label class="col-form-label text-sm-right col-sm-3">' + cHoldReasonLbl + '</label><div class="col-sm-8" id="text_' + cHoldBatchs + '"></div></div>');
    $("#myModal .modal-body #text_" + cHoldBatchs + "").append(text);
    $("#myModal #modal_btnAccept").text(cBtnCapionOk);
    $("#myModal #modal_btnAccept").attr('data-modalmode', cHoldBatchs);
    $("#myModal #modal_btnCancel").text(cBtnCapionCancel);
    ShowAndHideModal(true);

}

function UpdateHoldbatchStatus(Reason) {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "HoldComments": Reason,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: UpdateBatchHoldStatusURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                ShowAndHideModal(false)
                if (JsonResult.Error == false) {
                    alert(MsgHoldSuccess);
                }
                else if (JsonResult.Error == true) {
                    alert(MsgHoldFailed)
                }

                FillBatchData();
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function UpdateBatchStatus(strBatchValue) {

    var ReqData = {
        "BatchNo": strBatchNo,
        "BatchValue": strBatchValue,
        "objInputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: ChageBatchStatusURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {                    
                    ShowAndHideModal(false)
                    alert(MsgBatchModified);
                    FillBatchData();
                }
                else {
                    alert(JsonResult.ErrorMessage == "" ? "Update Failed" : JsonResult.ErrorMessage);
                    return false;
                }
            }
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ShowChildBatchListModal(datasource, action) {
    $("#myModal .modal-body").html("");
    $("#myModal .modal-title").text(cUsersKeyingTitle);
    $("#myModal #modal_btnAccept").text(cBtnCaptionProceed);
    $("#myModal #modal_btnAccept").attr('data-modalmode', action);
    $("#myModal #modal_btnCancel").text(cBtnCaptionCancelDelete);
    $("#myModal .modal-body").append("<p>" + MsgDeleteChildbatchLbl1.replace("%1", strBatchNo) + "</p>");
    $("#myModal .modal-body").append(GenerateModalFields(datasource, "grid", action));
    $("#myModal .modal-body").append("<p>" + MsgDeleteChildbatchLbl2 + "</p>");
    $("#myModal .modal-body").append("<p>" + MsgDeleteChildbatchLbl3.replace("%1", strBatchNo) + "</p>");
    var modalFoot = document.getElementsByClassName("modal-footer");
    var btn = document.createElement("button");
    btn.type = "button";
    btn.id = "modal_btnPrint";
    btn.className = "btn btn_primaryAction";
    $(btn).text(cBtnCaptionPrint);
    //$(modalFoot).insertBefore(btn, modalFoot[0].childNodes[0]);
    $(modalFoot).prepend(btn);
    ShowAndHideModal(true);
}

function ShowConfirmDeleteModal() {
    if (DeleteBatchStatus != null) {
        if (DeleteBatchStatus.ValidateResultsForAllProducts != null && DeleteBatchStatus.ValidateResultsForAllProducts.length > 0) {
            var datasource = [];
            for (var i = 0; i <= DeleteBatchStatus.ValidateResultsForAllProducts.length - 1; i++) {
                datasource.push({
                    Product: GetProductName(DeleteBatchStatus.ValidateResultsForAllProducts[i]["ProductName"]),
                    Status: DeleteBatchStatus.ValidateResultsForAllProducts[i]["CurrentStatus"],
                    Comments: DeleteBatchStatus.ValidateResultsForAllProducts[i]["Comments"]
                });
            }

            var headerCap = '';
            var btnAcceptCaption = "";
            var btnCancelCaption = "";

            var btnAction = cConfirmDelete;
            if (DeleteBatchStatus.DeleteBatchResult.ValidationFailed) {
                headerCap = MsgConfirmDeleteOk;
                btnAcceptCaption = cBtnCapionOk;
                btnAction = cConfirmDeleteOk;
                btnCancelCaption = cBtnCapionClose;
            }
            else {
                headerCap = MsgConfirmDelete;
                btnAcceptCaption = cBtnCapionConfDelete;
                btnAction = cConfirmDelete;
                btnCancelCaption = cBtnCaptionCancelDelete;
            }
            headerCap = headerCap.replace("%1", strBatchNo);
            $("#myModal .modal-body").html("");            
            $("#myModal .modal-title").text(cConirmBatchDeleteTitle);
            $("#myModal #modal_btnAccept").text(btnAcceptCaption);
            $("#myModal #modal_btnAccept").attr('data-modalmode', btnAction);
            $("#myModal #modal_btnCancel").text(btnCancelCaption);
            $("#myModal #modal_btnCancel").attr('data-modalmode', btnAction);
            $("#myModal #modal_btnClose").attr('data-modalmode', btnAction);
            $("#myModal .modal-body").append("<p>" + headerCap + "</p>");
            $("#myModal .modal-body").append(GenerateModalFields(datasource, "grid", btnAction));
            ShowAndHideModal(true);
        }
        else {
            RevertBatchesToOriginalStatus();
        }
    }
}

function RevertBatchesToOriginalStatus() {
    ShowLoading(true);
    $.ajax({
        url: RevertBatchesToOriginalStatusURL,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    DeleteBatchStatus = null;
                    FillBatchData();
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        DeleteBatchStatus = null;
                        FillBatchData();
                        return false;
                    }
                }

            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function GetProductName(ProductCode) {
    if (ProductCode > 0) {
        switch (ProductCode) {
            case 1:
                return "TMS";
            case 2:
                return "ECS";
            case 3:
                return "ILB";
            case 4:
                return "NQ";
            case 5:
                return "eCapture";
        }
    }
}

function ShowAddDeleteNotesModal() {
    ShowLoading(true);
    $.ajax({
        url: GetDeleteNotesURL,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null) {
                    $("#myModal .modal-body").html("");                    
                    $("#myModal .modal-title").text(cConirmBatchNotesTitle);
                    $("#myModal #modal_btnAccept").text(cBtnCapionOk);
                    $("#myModal #modal_btnAccept").attr('data-modalmode', cDeleteAddNotes);
                    $("#myModal #modal_btnCancel").hide();
                    $("#myModal #modal_btnClose").hide();
                    $("#myModal .modal-body").append("<p>" + cAddNotesHeaderText + "</p>");
                    $("#myModal .modal-body").append(GenerateModalFields(JsonResult, "dropdown", cDeleteAddNotes));
                    $("#myModal .modal-body").append('<textarea id="modal_textarea" style="width:100%;max-width:567px;" data-modalmode="' + cDeleteAddNotes + '" name="mdl_textara" rows="8" cols="50"></textarea>');
                    ShowAndHideModal(true);
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatus();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function DeleteBatchFromAllProducts(note) {
    if (strBatchNo == "")
        return;

    if (DeleteBatchStatus == null)
        ValidateAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo,
        "Notes": note
    }
    ShowLoading(true);
    $.ajax({
        url: DeleteBatchFromAllProductsURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    DeleteBatchStatus = JsonResult.objDeleteBatch;
                    ShowDeleteBatchResultModal(cConirmBatchResultTitle, DeleteBatchStatus.MsgToUser.m_StringValue);
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatus();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatus();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ShowDeleteBatchResultModal(title, Msg) {
    $("#myModal .modal-body").html("");
    $("#myModal .modal-title").text(title);
    $("#myModal #modal_btnAccept").text(cBtnCapionOk);
    $("#myModal #modal_btnAccept").attr('data-modalmode', cDeleteResult);
    $("#myModal #modal_btnCancel").hide();
    $("#myModal #modal_btnClose").hide();
    $("#myModal .modal-body").append('<textarea id="modal_textarea" style="width:100%;max-width:567px;" data-modalmode="' + cDeleteAddNotes + '" name="mdl_textara" rows="10" cols="50" disabled></textarea>');
    $("#myModal #modal_textarea").val(Msg);
    ShowAndHideModal(true)
}

function ModalDropdownChange() {
    var mode = $("#modal_dropdown").attr('data-modalmode');
    var selectedIndex = $("#modal_dropdown").prop('selectedIndex');
    var selectedValue = $("#modal_dropdown").val();
    if (mode == cDeleteAddNotes) {
        if (selectedIndex > 0 && selectedValue != "") {
            $("#modal_textarea").val(selectedValue);
        }
    }
}

function GenerateVirtualBatch() {
    var ReqData = {
        "ProcessDate": $("#txtProcDate").val(),
        "SiteId": $("#cmbSiteID").val(),
        "WorkSource": $("#cmbWorkSrc").val()

    }
    ShowLoading(true);
    $.ajax({
        url: GenerateVirtualBatchURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    alert(MsgVirtualBatchSuccess);
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        return false;
                    }
                    else {
                        alert(MsgVirtualBatchFailed);
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgErrorVirtualBatch);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function CarryOverBatch() {
    $("#myModal .modal-body").html("");
    $("#myModal .modal-title").text(cCarryOverTitle);
    $("#myModal #modal_btnAccept").text(cBtnCaptionCarryOver);
    $("#myModal #modal_btnAccept").attr('data-modalmode', cCarryOver);
    $("#myModal #modal_btnCancel").hide()
    $("#myModal .modal-body").append(GenerateModalFields(null, "datetime", cCarryOver, cCarryOverTitle));
    ShowAndHideModal(true);
    $("#myModal #txtmodaldate").focus();
}

function IsBatchHasVRRPendingItems(action) {
    var ReqData = {
        "strBatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ReqData.InputData.SiteId = strSiteId.split(',')[0];
    ShowLoading(true);
    return new Promise((resolve, reject) => {
        $.ajax({
            url: BatchHasVRRPendingItemsURL,
            type: "POST",
            dataType: "json",
            data: JSON.stringify(ReqData),
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                if (result != null && result != undefined) {
                    var JsonResult = JSON.parse(result);
                    if (JsonResult.Error == false) {
                        var proceed = false;
                        if (JsonResult.VRRItemStatus == "2") {
                            var message = "";
                            if (action == cCarryOver)
                                message = PSGMessage482;
                            else if (action == cChangeWorkSource)
                                message = PSGMessage481;
                            else if (action == cDeleteJob)
                                message = PSGMessage478; 
                            if (action == cDeleteJob) {
                                alert(message);
                                resolve(false)
                            }
                            else {
                                // If action is Carry Over or Change Work Source, then confirm the message. 
                                if (confirm(message)) {
                                    // Call Validate VRR pending items.
                                    let first_promise = new Promise((resolve, reject) => resolve(VaildateVRRItems()));

                                    let result = Promise.all([first_promise]);

                                    proceed = result;
                                }
                            }
                        }
                        else if (JsonResult.VRRItemStatus == "1") {
                            if (action == cCarryOver)
                                message = PSGMessage483;
                            else if (action == cChangeWorkSource || action == cDeleteJob)
                                message = PSGMessage479;
                            if (confirm(message)) {
                                // Call Validate VRR pending items.
                                let first_promise = new Promise((resolve, reject) => resolve(VaildateVRRItems()));

                                let result = Promise.all([first_promise]);

                                proceed = result;
                            }
                        }
                        else
                            proceed = true;

                        resolve(proceed);
                    }
                    else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        reject(false);
                    }
                }
            },
            error: function (eror) {
                console.log(eror);
                if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                    document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
                }
                reject(false);
            },
            complete: function () {
                ShowLoading(false);
            }
        });
    });
}

function VaildateVRRItems()
{
    var ReqData = {
        "strBatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ReqData.InputData.SiteId = strSiteId.split(',')[0];
    return new Promise((resolve, reject) => {
        $.ajax({
            url: ValidateVRRPendingItemsURL,
            type: "POST",
            dataType: "json",
            data: JSON.stringify(ReqData),
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                if (result != null && result != undefined) {
                    var JsonResult = JSON.parse(result);
                    if (JsonResult.Error == false) {
                        if (JsonResult.IsVRRPendingItemsValid == false) {
                            if (alert(PSGMessage480)) {
                                resolve(false);
                            }
                        }
                        else {
                            resolve(true);
                        }
                    }
                    else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        reject(false);
                    }
                }
            },
            error: function (eror) {
                console.log(eror);
                if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                    document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
                }
                reject(false);
            },
            complete: function () {
                ShowLoading(false);
            }
        });
    });    
}

function CarryOverBatches(strDate) {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "strCarryDate": strDate,
        "strBatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: CarryOverBatchesURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ShowAndHideModal(false)
                    $("#myModal #modal_btnCancel").show()
                    alert(MsgCarryOverSuccess);
                    FillBatchData();
                    return true;
                }
                else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                    alert(JsonResult.ErrorMessage);
                    return false;
                }
                FillBatchData();
            }
            return true;
        },
        error: function (eror) {
            console.log(eror);
            if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
            }
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function CheckCarryDateExist(strDate) {
    if (strDate == "")
        return;

    var ReqData = {
        "ProcessDate": strDate

    }
    ShowLoading(true);
    $.ajax({
        url: CheckProcessDateExistURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (resp) {
            if (resp != null && resp != undefined) {
                var result = resp;
                if (result != null && result != undefined) {
                    var JsonResult = JSON.parse(result);
                    if (JsonResult != null && JsonResult != undefined) {
                        if (JsonResult.Error == false) {
                            CarryOverBatches(strDate);
                        }
                        else if (JsonResult.Error == true && (JsonResult.ErrorMessage == null || JsonResult.ErrorMessage == "")) {
                            alert(MsgCarryDateClosed);
                            $("#txtmodaldate").focus();
                            return false;
                        }
                        else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            return false;
                        }
                    }
                }
            }
        },
        error: function (error) {
            alert(MsgErrorCarryBatch);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
        });
}

//Change Worksource Start here
function ShowChangeWorksourceModal() {
    var ReqData = {
        "BatchNo": strBatchNo,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: LoadWorkSourceAndBatchValueForChangeWorksourceURL,
        type: "POST",
        data: JSON.stringify(ReqData),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null) {
                    $("#myModal .modal-body").html("");
                    $("#myModal .modal-title").text(cBtnCaptionChangeWorksource);
                    var divFH = document.createElement("div");
                    divFH.className = "mt-2";
                    var selectWS = GenerateModalFields(JsonResult.Site, "dropdown", cChangeWorkSource);
                    var selectBV = GenerateModalFields(JsonResult.Table, "dropdown", cChangeWorkSource);
                    if (JsonResult.Site.length == 2)
                        $(selectWS).val($(selectWS).find("option:eq(1)").val());

                    $(selectBV).val(cP1BatchCollectVal);
                    $(selectBV).prop("disabled", true);
                    $(divFH).append('<div class="form-group"><label class="col-form-label text-sm-right col-sm-3">' + clblCaptionWorksource + '</label><div class="col-sm-8" id="dropdown_' + cChangeWorkSource + '_WS"></div></div>');
                    $(divFH).find("#dropdown_" + cChangeWorkSource + "_WS").append(selectWS);
                    $(divFH).append('<div class="form-group"><label class="col-from-label text-sm-right col-sm-3">' + clblCaptionBatchValue + '</label><div class="col-sm-8" id="dropdown_' + cChangeWorkSource + '_BV"></div></div>');
                    $(divFH).find("#dropdown_" + cChangeWorkSource + "_BV").append(selectBV);
                    $("#myModal .modal-body").append(divFH);
                    $("#myModal #modal_btnAccept").text(cBtnCaptionChangeWorksource);
                    $("#myModal #modal_btnAccept").attr('data-modalmode', cChangeWorkSource);
                    $("#myModal #modal_btnCancel").text(cBtnCapionClose);
                    ShowAndHideModal(true);
                }
            }
            else {
                alert(MsgBatchValuesNotFound);
                return false;
            }
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateProcessedForChangeWorksource(strNewWS, strNewBatchVal) {
    var BatchGrid = $("#gridBatchMain").data("kendoGrid");
    var rows = BatchGrid.select();
    if (rows != null && rows != undefined && rows.length > 0) {
        var selectedItem = BatchGrid.dataItem(rows[0]);
        if (selectedItem != null && selectedItem != undefined) {
            var strPcCreated = selectedItem["PCCreated"];
            var strProcessedInPass2 = selectedItem["ProcessedInPass2"];
            var strECSProcessed = selectedItem["ECSprocessed"];

            var FilterData = {
                SiteId: selectedItem["SiteId"],
                strWorkSource: selectedItem["WorkSrc"],
                BatchKey: selectedItem["BatchKey"],
                ProcessDate: $("#txtProcDate").val(),
                BatchNo: strBatchNo

            }
            ShowLoading(true);
            $.ajax({
                url: GetAllowPass2BatchDeleteToValidateURL,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(FilterData),
                contentType: "application/json; charset=utf-8",
                success: function (result) {
                    var bolProceed = true;
                    if (result != null && result != undefined) {
                        var JsonResult = JSON.parse(result);
                        if (JsonResult != null && JsonResult != undefined) {
                            if (JsonResult.Error == false) {
                                if (JsonResult.TaskResult == false)
                                    bolProceed = false;

                                if (strProcessedInPass2 == 'Y') {
                                    alert(strBatchNo + " " + MsgCWPass2Completed);
                                    bolProceed = false;
                                }

                                if (strPcCreated == 'H' || strPcCreated == 'V') {
                                    alert(MsgCWCannotBeChanged);
                                    bolProceed = false;
                                }
                            }
                            else if (JsonResult.Error == true && JsonResult.ErrorMessage != "") {
                                alert(JsonResult.ErrorMessage);
                                bolProceed = false;
                            }
                            else if (JsonResult.Error == true && JsonResult.ErrorMessage == "") {
                                bolProceed = false;
                            }
                        }
                        ShowAndHideModal(false)
                        if (bolProceed)
                            ValidateChangeWSAndDeleteBatchInAllProducts(strNewWS, strNewBatchVal);
                    }
                },
                error: function (error) {
                    alert(MsgExceptionChangeWS);
                    return false;
                },
                complete: function () {
                    ShowLoading(false);
                }
            });
        }
    }
    return true;
}

var ChangeWSDeails = [];
function ValidateChangeWSAndDeleteBatchInAllProducts(strNewWS, strNewBatchVal) {
    if (strBatchNo == "")
        return;

    var ReqData = {
        "BatchNo": strBatchNo,
        "strNewWorkSource": strNewWS,
        "strNewBatchValue": strNewBatchVal,
        "InputData": GetFilterReqData()
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateChangeWorksourceAndDeleteBatchInAllProductsURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    if (JsonResult.Error == false) {
                        ChangeWSDeails = JsonResult.objChangeBatch;
                        ValidateTMSBatchStatusForCW();
                        return true;
                    }
                    else {
                        if (JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            RevertBatchesToOriginalStatusForCW();
                            return false;
                        }
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateTMSBatchStatusForCW() {
    if (strBatchNo == "")
        return;

    if (ChangeWSDeails == null)
        ValidateChangeWSAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateTMSBatchStatusForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    if (JsonResult.Error == false) {
                        ChangeWSDeails = JsonResult.objChangeBatch;
                        ValidateILBBatchStatusForCW();
                    }
                    else {
                        if (JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            RevertBatchesToOriginalStatusForCW();
                            return false;
                        }
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateILBBatchStatusForCW() {
    if (strBatchNo == "")
        return;

    if (ChangeWSDeails == null)
        ValidateChangeWSAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateILBBatchStatusForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    if (JsonResult.Error == false) {
                        ValidateNewBatchCreatedinTMSForCW();
                    }
                    else if (JsonResult.Error == true && JsonResult.DsPopupDetails != null && JsonResult.DsPopupDetails["ChildBatchList"].length > 0) {
                        ShowChildBatchListModal(JsonResult.DsPopupDetails["ChildBatchList"], cCWDeleteChildBatchList);
                    }
                    else if (JsonResult.Error == true && JsonResult.ErrorMessage != null && JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatusForCW();
                    }
                }
            }
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateNewBatchCreatedinTMSForCW() {
    if (strBatchNo == "")
        return;

    if (ChangeWSDeails == null)
        ValidateChangeWSAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateNewBatchCreatedinTMSForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    if (JsonResult.Error == false) {
                        if (ChangeWSDeails.DeleteBatchResult.ECSStatus == 2 || ChangeWSDeails.DeleteBatchResult.ECSStatus == 3) {
                            if (!(ChangeWSDeails.UserAuthLevel < ChangeWSDeails.AuthlevelToDeleteICLJobCreatedBatch)) {
                                if (!confirm(MsgConfirECSDelete)) {
                                    RevertBatchesToOriginalStatusForCW();
                                    //FillBatchData();
                                    ChangeWSDeails.DeleteBatchResult.UserCancelledDelete = true;
                                    return false;
                                }
                            }
                        }
                        if (JsonResult.Error == true && JsonResult.ErrorMessage != null && JsonResult.ErrorMessage != "") {
                            alert(JsonResult.ErrorMessage);
                            RevertBatchesToOriginalStatusForCW();
                            return false;
                        }
                        ValidateDeleteInOtherProductsForCW();
                    }
                    else if (JsonResult.Error == true && JsonResult.DsPopupDetails != null && JsonResult.DsPopupDetails["ChildBatchList"].length > 0) {
                        ShowChildBatchListModal(JsonResult.DsPopupDetails["ChildBatchList"], cCWDeleteBatchCreatedinTMS);
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionDelete);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ValidateDeleteInOtherProductsForCW() {
    if (strBatchNo == "")
        return;

    if (ChangeWSDeails == null)
        ValidateChangeWSAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: ValidateDeleteInOtherProductsForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    if (!(ChangeWSDeails.DeleteBatchVars.UserAuthLevel < ChangeWSDeails.DeleteBatchVars.AuthlevelToDeleteICLJobCreatedBatch) && ChangeWSDeails.ECSStatus == 2 || ChangeWSDeails.ECSStatus == 3) {
                        if (!confirm(MsgConfirmECStoDelete))
                            AddAuditAndMarkedProductForDeleteForCW("false");
                        else
                            AddAuditAndMarkedProductForDeleteForCW("true");
                    }
                    else {
                        ShowConfirmDeleteModalForCW();
                        return true;
                    }
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatusForCW();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function AddAuditAndMarkedProductForDeleteForCW(bolValue) {
    var ReqData = {
        "bolAddProduct": bolValue

    }
    ShowLoading(true);
    $.ajax({
        url: AddAuditAndMarkedProductForDeleteForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    ShowConfirmDeleteModal();
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "")
                        alert(JsonResult.ErrorMessage);
                    RevertBatchesToOriginalStatusForCW();
                    return false;
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ShowConfirmDeleteModalForCW() {
    if (ChangeWSDeails != null) {
        ShowLoading(true);
        if (ChangeWSDeails.ValidateResultsForAllProducts != null && ChangeWSDeails.ValidateResultsForAllProducts.length > 0) {
            var datasource = [];
            for (var i = 0; i <= ChangeWSDeails.ValidateResultsForAllProducts.length - 1; i++) {
                datasource.push({
                    Product: GetProductName(ChangeWSDeails.ValidateResultsForAllProducts[i]["ProductName"]),
                    Status: ChangeWSDeails.ValidateResultsForAllProducts[i]["CurrentStatus"],
                    Comments: ChangeWSDeails.ValidateResultsForAllProducts[i]["Comments"]
                });
            }

            var headerCap = '';
            var btnAcceptCaption = "";
            var btnCancelCaption = "";

            var btnAction = cConfirmDelete;
            if (ChangeWSDeails.DeleteBatchResult.ValidationFailed) {
                headerCap = MsgConfirmChangeWSCannotDelete;
                btnAcceptCaption = cBtnCapionOk;
                btnAction = cConfirmCWOk;
                btnCancelCaption = cBtnCapionClose;
            }
            else {
                headerCap = MsgConfirmChangeWorksource;
                btnAcceptCaption = cBtnCapionConfirm;
                btnAction = cConfirmCW;
                btnCancelCaption = cBtnCapionCancel;
            }
            headerCap = headerCap.replace("%1", strBatchNo);
            $("#myModal .modal-body").html("");            
            $("#myModal .modal-title").text(cbtnOKChangeWorkSource);
            $("#myModal #modal_btnAccept").text(btnAcceptCaption);
            $("#myModal #modal_btnAccept").attr('data-modalmode', btnAction);
            $("#myModal #modal_btnCancel").text(btnCancelCaption);
            $("#myModal #modal_btnCancel").attr('data-modalmode', btnAction);
            $("#myModal #modal_btnClose").attr('data-modalmode', btnAction);
            $("#myModal .modal-body").append("<p>" + headerCap + "</p>");
            $("#myModal .modal-body").append(GenerateModalFields(datasource, "grid", btnAction));
            ShowAndHideModal(true);
            ShowLoading(false);
        }
        else {
            alert(MsgNoDataAvailable);
            RevertBatchesToOriginalStatusForCW();
        }
    }
}

function DeleteBatchFromAllProductsForCW() {
    if (strBatchNo == "")
        return;

    if (ChangeWSDeails == null)
        ValidateChangeWSAndDeleteBatchInAllProducts();

    var ReqData = {
        "ProcDate": $("#txtProcDate").val(),
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: DeleteBatchFromAllProductsForCWURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    GetAnnotateBatchHeaderForCW();
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatusForCW();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}
function GetAnnotateBatchHeaderForCW() {
    var ReqData = {
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: GetAnnotateBatchHeaderURL,
        type: "POST",
        dataType: "json",
        data: JSON.stringify(ReqData),
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    if (JsonResult.ErrorMessage != "") {
                        ShowNotesModelToAnnotateBatch();
                    }
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        RevertBatchesToOriginalStatusForCW();
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            RevertBatchesToOriginalStatusForCW();
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function ShowNotesModelToAnnotateBatch() {
    ShowLoading(true);
    $("#myModal .modal-body").html("");    
    $("#myModal .modal-title").text(cbtnOKChangeWorkSource);
    $("#myModal #modal_btnAccept").text(cBtnCapionOk);
    $("#myModal #modal_btnAccept").attr('data-modalmode', cChangeWSNotes);
    $("#myModal #modal_btnCancel").hide();
    $("#myModal #modal_btnClose").hide();
    $("#myModal .modal-body").append('<h5>'+ cAnnotateNoteHeader + '</h5><textarea id="modal_textarea" style="width:100%;max-width:567px;" data-modalmode="' + cChangeWSNotes + '" name="mdl_textara" rows="8" cols="50"></textarea>');
    $("#myModal .modal-body").find("#modal_textarea").val("Worksource changed from " + ChangeWSDeails.DeleteBatchVars.WorkSrc + " to " + ChangeWSDeails.DeleteBatchVars.NewWorkSrc);
    ShowAndHideModal(true);
    ShowLoading(false);
}

function AnnotateAndDeleteImageFilesCW(notes) {
    var ReqData = {
        "Notes": notes,
        "BatchNo": strBatchNo
    }
    ShowLoading(true);
    $.ajax({
        url: AnnotateBatchHeaderAndDeleteImageFilesURL,
        type: "POST",
        data: JSON.stringify(ReqData),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = JsonResult.objChangeBatch;
                    ShowDeleteBatchResultModal(cBtnCaptionChangeWorksource, ChangeWSDeails.MsgToUser.m_StringValue);
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        return false;
                    }
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function RevertBatchesToOriginalStatusForCW() {
    ShowLoading(true);
    $.ajax({
        url: RevertBatchesToOriginalStatusForCWURL,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult.Error == false) {
                    ChangeWSDeails = null;
                    FillBatchData();
                    return true;
                }
                else {
                    if (JsonResult.ErrorMessage != "") {
                        alert(JsonResult.ErrorMessage);
                        ChangeWSDeails = null;
                        FillBatchData();
                        return false;
                    }
                }
            }
            FillBatchData();
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}
//Change Worksource End here

function AddVirtualPocketTrigger() {
    var ReqData = {
        BatchNo: strBatchNo,
        ProcessDate: $("#txtProcDate").val()
    }
    ShowLoading(true);
    $.ajax({
        url: AddVirtualPocketTriggerURL,
        type: "POST",
        data: JSON.stringify(ReqData),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            if (result != null && result != undefined) {
                var JsonResult = JSON.parse(result);
                if (JsonResult != null && JsonResult != undefined) {
                    if (JsonResult.Error == false && JsonResult.ErrorMessage != "")
                        alert(JsonResult.ErrorMessage);
                    else if (JsonResult.Error == true && JsonResult.ErrorMessage != "")
                        alert(JsonResult.ErrorMessage);
                }
            }
            return true;
        },
        error: function (eror) {
            alert(MsgExceptionChangeWS);
            return false;
        },
        complete: function () {
            ShowLoading(false);
        }
    });
}

function SetOKButtonTextForAction() {
    var Action = $("#cmbAction").val();
    var btnText = "";
    switch (parseInt(Action)) {
        case cAddJob:
            btnText = cbtnOKAddJob;
            break;
        case cDeleteJob:
            btnText = cbtnOKDeleteBatch;
            break;
        case cChangeStatus:
            btnText = cbtnOKChangeStatus;
            break;
        case cCarryOver:
            btnText = cbtnOKCarryOver;
            break;
        case cPriority:
            btnText = cbtnOKSetPriority;
            break;
        case cInUseBatches:
            btnText = cbtnOKRetrieveInUse;
            break;
        case cResetBatches:
            btnText = cbtnOKResetBatches;
            break;
        case cChangeWorkSource:
            btnText = cbtnOKChangeWorkSource;
            break;
        case cHoldBatchs:
            btnText = cbtnOKHoldBatches;
            break;
        case cReleaseBatches:
            btnText = cbtnOKReleaseBatch;
            break;
        case cAddVirtualBatchPocketCut:
            btnText = cbtnOKAddPocketCut;
            break;
        case cSkipPass2:
            btnText = cbtnOKSkipSortPass;
            break;
        case cGenerateVirtualBatch:
            btnText = cbtnOKCreateTriggerForVB;
            break;
        case cResetVRRItems:
            btnText = cbtnOKResetVRRItems;
            break;
        default:
            btnText = cbtnOKDefault;
            break;
    }
    $("#btnOK").val(btnText);
    if (parseInt(Action) == cViewBatch)
        $("#btnOK").prop("disabled", true);
    else
        $("#btnOK").prop("disabled", false);
}

function SetEnableDisableForAction() {
    var Action = $("#cmbAction").val();
    var SkipPass2MenuExists = $("#hdnSkipPass2MenuExists").val();
    Action = parseInt(Action);
    if (Action == cGenerateVirtualBatch) {
        $("#cmbWorkSrc").prop("disabled", false);
        $("#txtBatFrom").prop("disabled", false);
        $("#txtBatTo").prop("disabled", false);
        $("#cmbBatMode").prop("disabled", false);
        $("#cmbPrevBatVal").prop("disabled", false);
        $("#cmbCurBatValue").prop("disabled", false);
        $("#btnDispBatch").prop("disabled", false)
    }

    if (Action == cAddVirtualBatchPocketCut) {
        $("#cmbCurBatValue").val(-1);
        $("#cmbPrevBatVal").val(-1);
        $("#cmbBatMode").val(-1);

        $("#txtBatFrom").Text = "";
        $("#txtBatTo").Text = "";

        $("#txtBatFrom").prop("disabled", true);
        $("#txtBatTo").prop("disabled", true);
        $("#cmbBatMode").prop("disabled", true);
        $("#cmbPrevBatVal").prop("disabled", true);
        $("#cmbCurBatValue").prop("disabled", true);
    }
    else {
        $("#txtBatFrom").prop("disabled", false);
        $("#txtBatTo").prop("disabled", false);
        $("#cmbBatMode").prop("disabled", false);
        $("#cmbPrevBatVal").prop("disabled", false);
        $("#cmbCurBatValue").prop("disabled", false);
        $("#btnDispBatch").prop("disabled", false);
    }


    if (Action == cAddVirtualBatchPocketCut) {
        $("#cmbPrevBatVal").prop("disabled", false);
        $("#cmbCurBatValue").prop("disabled", false);
    }
    if (Action == cSkipPass2) {
        LoadSkipPass2EnabledWSForUser();
        $("#cmbCurBatValue").val(-1);
        $("#cmbPrevBatVal").val(-1);
        $("#cmbPrevBatVal").prop("disabled", true);
        $("#cmbCurBatValue").prop("disabled", true);
    }
    else if ((SkipPass2MenuExists == "true") && (Action == cSkipPass2)) {
        if (Action != cAddVirtualBatchPocketCut) {
            $("#cmbPrevBatVal").prop("disabled", false);
            $("#cmbCurBatValue").prop("disabled", false);
        }
    }

    if (Action == cGenerateVirtualBatch) {
        $("#cmbCurBatValue").val(-1);
        $("#cmbPrevBatVal").val(-1);
        $("#cmbBatMode").val(-1);

        $("#txtBatFrom").Text = "";
        $("#txtBatTo").Text = "";

        $("#cmbWorkSrc").prop("disabled", false);
        $("#txtBatFrom").prop("disabled", true);
        $("#txtBatTo").prop("disabled", true);
        $("#cmbBatMode").prop("disabled", true);
        $("#cmbPrevBatVal").prop("disabled", true);
        $("#cmbCurBatValue").prop("disabled", true);
        $("#btnDispBatch").prop("disabled", true)
    }
    if (Action != cSkipPass2)
        LoadWorksourceForSite();
}

function DisableAllControls() {
    $("#cmbWorkSrc").prop("disabled", true);
    $("#txtBatFrom").prop("disabled", true);
    $("#txtBatTo").prop("disabled", true);
    $("#cmbBatMode").prop("disabled", true);
    $("#cmbPrevBatVal").prop("disabled", true);
    $("#cmbCurBatValue").prop("disabled", true);
    $("#btnDispBatch").prop("disabled", true)
    $("#cmbSiteID").prop("disabled", true)
    $("#txtProcDate").prop("disabled", true)
    $("#btnReset").prop("disabled", true)
    $("#btnOK").prop("disabled", true)
}

function ShowAndHideModal(bolShow) {
    if (bolShow) {
        setTimeout(function () { $('#myModal').modal('show') }, 500);
    }
    else if (!bolShow) {        
        $(".modal-footer button").attr('data-modalmode', "");
        $('#myModal').modal('hide');
        $('.modal-backdrop').remove();
        $("#myModal #modal_btnCancel").show();
        $("#myModal #modal_btnClose").show();
    }
}
function EscapeHTML(strParam) {
    if (strParam != undefined && strParam != null) {
        return strParam.replace(/\&/g, '&amp;')
            .replace(/\</g, '&lt;')
            .replace(/\>/g, '&gt;')
            .replace(/\"/g, '&quot;')
            .replace(/\'/g, '&#x27;')
            .replace(/\//g, '&#x2F;');
    }
}
async function CheckIsValidBatch(BatchNo) {
    if (!BatchNo)
        BatchNo = strBatchNo;

    var data = { BatchNo };

    ShowLoading(true);

    return new Promise((resolve, reject) => {
        $.ajax({
            url: CheckValidBatchURL,
            type: "POST",
            dataType: "json",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                if (result != null && result != undefined) {
                    var JsonResult = JSON.parse(result);
                    if (JsonResult.Error === true) {
                        ShowAndHideModal(false);
                        alert(JsonResult.ErrorMessage);
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }
            },
            error: function (eror) {
                if (eror.responseText.toLowerCase().indexOf("session expired") != -1) {
                    document.location.href = "../ADSSessionExpiry.htm?Language=en-us";
                }
                resolve(false);
            },
            complete: function () {
                ShowLoading(false);
            }
        });
    });
}