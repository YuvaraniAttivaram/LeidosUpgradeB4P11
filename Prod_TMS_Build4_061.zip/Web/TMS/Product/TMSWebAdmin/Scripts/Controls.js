﻿document.addEventListener("DOMContentLoaded", function () {

    // ---------- OnSubmit ----------
    window.OnSubmit = function (type) {
        $("#hdnAction").val(type);
        const rowCount = parseInt($("#hdnRowCount").val(), 10);
        const currentIndex = parseInt($("#hdnCurrentCount").val(), 10);

        switch (type) {
            case "Cancel":
                window.location.href = "../DBEditor/DBEditorMenu";
                break;

            case "Insert":
                let fieldName = "";
                $("input[mandatory='true']").each(function () {
                    if ($(this).val().trim() === "") {
                        fieldName = $(this).attr("name");
                        return false; // breaks out of .each
                    }
                });

                if (fieldName !== "") {
                    alert(DBEMandatFields + fieldName);
                    $("#" + fieldName).focus();
                } else {
                    document.forms[0].submit();
                }
                break;

            case "Next":
                if (currentIndex === rowCount - 1) {
                    alert(DBELastREcord);
                } else {
                    document.forms[0].submit();
                }
                break;

            case "Previous":
                if (currentIndex === 0) {
                    alert(DBEFirstREcord);
                } else {
                    document.forms[0].submit();
                }
                break;

            case "Delete":
                if (confirm(doreallywant)) {
                    document.forms[0].submit();
                }
                break;

            default:
                document.forms[0].submit();
        }
    };

    // ---------- Enable Update Button ----------
    window.EnableUpdateBtn = function () {
        $("#btnUpdate").prop("disabled", false);
    };

    // ---------- Open Goto Window ----------
    const openGotoWinBtn = document.getElementById("openGotoWinBtn");
    if (openGotoWinBtn) {
        openGotoWinBtn.addEventListener("click", function () {
            fetch(GoToUrl)
                .then(res => res.json())
                .then(data => {
                    //console.log("Fetched Goto fields:", Array.isArray(data), data);
                    renderGotoFields(data);
                    $("#GotoWin").modal("show");
                });
        });
    }

    let goToFieldsData = []; // This will be filled by renderGotoFields()

    //document.addEventListener("DOMContentLoaded", function () {
    const selectGotoBtn = document.getElementById("selectGotoBtn");
    if (selectGotoBtn) {
        selectGotoBtn.addEventListener("click", function () {
            let isEmpty = false;

            for (let i = 0; i < goToFieldsData.length; i++) {
                const colName = htmlEncode(goToFieldsData[i].ColumnName);
                const input = document.getElementById("Goto_" + colName);

                if (input && input.value.trim() === "") {
                    isEmpty = true;
                    break;
                }
            }

            if (isEmpty) {
                alert(DBEPlsEntAtl);
            } else {
                document.getElementById("hdnAction").value = "Goto";
                $("#GotoWin").modal("hide");
                document.forms[0].submit();
            }
        });
    }
    //});

    // ---------- Render Goto Fields ----------
    function renderGotoFields(fields) {
        goToFieldsData = fields;
        const container = document.getElementById("gotoFieldsContainer");
        container.innerHTML = "";
        const sanitize = (str) => {
            return String(str)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#39;");
        };
        fields.forEach(field => {
            const rawName = field.ColumnName || "";
            const safeColName = sanitize(rawName);
            const div = document.createElement("div");
            div.className = "form-group row mb-2";

            const label = document.createElement("label");
            label.className = "col-sm-3 col-form-label";
            label.textContent = safeColName; // Safely inserts text content

            const innerDiv = document.createElement("div");
            innerDiv.className = "col-sm-6";

            const input = document.createElement("input");
            input.type = "text";
            input.id = `Goto_${safeColName}`;
            input.name = `Goto_${safeColName}`;
            input.className = "form-control form-control_Cust GotoParamFields";
            input.setAttribute("data-goto-field", "true");

            innerDiv.appendChild(input);
            div.appendChild(label);
            div.appendChild(innerDiv);

            container.appendChild(div);
        });
    }

    // ---------- HTML Encode/Decode Helpers ----------
    window.htmlEncode = function (value) {
        return FormatTextContent($('<div/>').text(value).html());
    };

    window.htmlDecode = function (value) {
        return $('<div/>').html(value).text();
    };

    window.FormatTextContent = function (strResult) {
        if (typeof strResult === 'undefined') return strResult;
        return strResult
            .split('&lt;').join('<')
            .split('&gt;').join('>')
            .split('&quot;').join('"')
            .split('&amp;').join('&')
            .split('&amp;nbsp;').join(' ')
            .split('&#39;').join("'")
            .replace('\"', '"');
    };

});
