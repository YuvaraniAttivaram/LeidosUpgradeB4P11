﻿document.addEventListener('DOMContentLoaded', function () {
    const app = {
        tableId: null,
        batches: [],
        selectFields: [],

        openDetailsList: function (tableId) {
            fetch(`${GetBatchesUrl}?TableID=${tableId}&BatchNo=`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Network response was not ok");
                    }
                    return response.text(); // get raw text first
                })
                .then(text => {
                    if (!text) {
                        return []; // no data, treat as empty array
                    }
                    return JSON.parse(text); // manually parse
                })
                .then(data => {
                    app.batches = data;
                    app.tableId = tableId;
                    app.renderBatchList();
                    $(".batchNumberSelection").modal("show");
                    // AFTER modal is shown, trigger input event manually
                    //const batchInput = document.getElementById("batchSearchInput");
                    //if (batchInput) {
                    //    const event = new Event('input', { bubbles: true });
                    //    batchInput.dispatchEvent(event);
                    //}

                })
                .catch(error => {
                    console.error("Error loading batch list:", error);
                });
            document.getElementById("batchSearchInput").addEventListener("input", () => {
                app.searchBatchNo();
            });
        },

        selectBatchNo: function () {
            const selected = document.querySelector('input[name="BatchNumberRadio"]:checked');
            if (selected) {
                document.getElementById("hdnBatchNo").value = selected.value;
                document.getElementById("hdnAction").value = "DetailList";
                document.forms[0].submit();
            } else {
                alert("Please select a batch number.");
            }
        },

        searchBatchNo: function () {
            const batchInput = document.getElementById("batchSearchInput");
            const batchNo = batchInput ? batchInput.value : "";

            fetch(`${GetBatchesUrl}?TableID=${app.tableId}&BatchNo=${encodeURIComponent(batchNo)}`)
                .then(response => response.json())
                .then(data => {
                    app.batches = data;
                    app.renderBatchList();
                    $(".batchNumberSelection").modal("show");
                });
        },

        selectParameter: function () {
            if (!app.validateSelectParam()) return;

            document.getElementById("hdnAction").value = "SelectParameter";
            document.forms[0].submit();
        },

        openControlPage: function (displayName, tableId) {
            if (displayName === "Configuration") {
                location.href = "../Configuration/DBEConfiguration";
            } else {
                fetch(`${GetSelectParameterUrl}?TableID=${tableId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data && data.length > 0) {
                            app.selectFields = data;
                            if (tableId == "2")
                                app.renderWSSelectFields();
                            else
                                app.renderSelectFields();
                            $("#SelectParameter").modal("show");
                        }
                        else if (Array.isArray([data.Message]) && (tableId == "8" || tableId == "9")) {
                            alert(DBENoDataFound);
                        }
                        else {
                            location.href = `RedirectAction?name=${displayName}&TableId=${tableId}`;
                        }
                    });
            }
        },

        validateSelectParam: function () {
            const inputs = document.querySelectorAll("#SelectParameter input[data-filtertext='1']");
            if (inputs.length === 1 && inputs[0].value.trim() === "") {
                const label = $(inputs[0]).closest("div").prev("span").text().toLowerCase();
                alert(MsgPleaseEnter + " " + label);
                inputs[0].focus();
                return false;
            }

            if (inputs.length > 1) {
                let hasValue = false;
                inputs.forEach(input => {
                    if (input.value.trim() !== "") {
                        hasValue = true;
                    }
                });

                if (!hasValue) {
                    alert(DBEPlsEntAtl);
                    inputs[0].focus();
                    return false;
                }
            }
            return true;
        },

        renderBatchList: function () {
            const container = document.getElementById("batchList");
            if (!container) return;
            container.innerHTML = "";
            const sanitize = (str) => {
                return String(str)
                    .replace(/&/g, "&amp;")
                    .replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;")
                    .replace(/"/g, "&quot;")
                    .replace(/'/g, "&#39;");
            };
            if (app.batches != "" && !Array.isArray(app.batches.Message)) {
                var i = 0;
                app.batches.forEach(batch => {
                    const li = document.createElement("li");
                    li.className = "list-group-item border-0 col-sm-3";
                    //li.innerHTML = `
                    //<span class="form-check form-check-inline">
                    //    <input type="radio" id="batchListRadio`+ i + `" class="radBatchNo" value="${batch.BatchNo}" name="BatchNumberRadio" />
                    //    <label for="batchListRadio`+ i + `" >${batch.BatchNo}</label>
                    //</span>`;
                    const span = document.createElement("span");
                    span.className = "form-check form-check-inline";

                    const input = document.createElement("input");
                    input.type = "radio";
                    input.id = `batchListRadio${i}`;
                    input.className = "radBatchNo";
                    //input.value = batch.BatchNo;
                    input.name = "BatchNumberRadio";

                    // Sanitize dynamic values
                    const safeBatchNo = sanitize(batch.BatchNo);
                    input.value = safeBatchNo;

                    const label = document.createElement("label");
                    label.setAttribute("for", `batchListRadio${i}`);
                    label.textContent = safeBatchNo;

                    span.appendChild(input);
                    span.appendChild(label);
                    li.appendChild(span);

                    container.appendChild(li);
                    i++;
                });
            }
        },

        renderSelectFields: function () {
            const container = document.getElementById("selectParameterInputs");
            if (!container) return;
            //container.innerHTML = "";
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
            if (app.batches != "" && !Array.isArray(app.batches.Message)) {
                app.selectFields.forEach(field => {
                    const safeColumnName = String(field.ColumnName).replace(/[^a-zA-Z0-9 _()-]/g, '');
                    const row = document.createElement("div");
                    row.className = "form-group row";
                //    row.innerHTML = `
                //    <span class="col-form-label col-sm-2">${field.ColumnName}</span>
                //    <div class="col-sm-3">
                //        <input type="text" class="form-control GotoParamFields" data-filtertext="1" name="Select_${field.ColumnName}" id="Select_${field.ColumnName}" />
                //    </div>
                //`;
                    const labelSpan = document.createElement("span");
                    labelSpan.className = "col-form-label col-sm-2";
                    labelSpan.textContent = safeColumnName;

                    const inputDiv = document.createElement("div");
                    inputDiv.className = "col-sm-3";

                    const input = document.createElement("input");
                    input.type = "text";
                    input.className = "form-control GotoParamFields";
                    input.setAttribute("data-filtertext", "1");
                    input.name = `Select_${safeColumnName}`;
                    input.id = `Select_${safeColumnName}`;

                    inputDiv.appendChild(input);
                    row.appendChild(labelSpan);
                    row.appendChild(inputDiv);

                    container.appendChild(row);
                });
            }
            else {
                //document.getElementById("selectParameterInputs").innerHTML = `<div>${DBENoDataFound}</div>`;
                //document.getElementById("selectParamBtn").disabled = "disabled";
                const noDataDiv = document.createElement("div");
                noDataDiv.textContent = String(DBENoDataFound).replace(/[^a-zA-Z0-9 _()-]/g, '');
                container.appendChild(noDataDiv);

                const selectParamBtn = document.getElementById("selectParamBtn");
                if (selectParamBtn) selectParamBtn.disabled = true;
            }
        },

        renderWSSelectFields: function () {
            const container = document.getElementById("selectParameterInputs");
            if (!container) return;
            container.innerHTML = "";

            app.selectFields.forEach(field => {
                // Sanitize or encode the field name to remove dangerous characters
                const safeColumnName = String(field.ColumnName || "")
                    .replace(/[<>&"'`]/g, ""); // basic neutralization of HTML meta-characters

                const row = document.createElement("div");
                row.className = "form-group row";

                const labelSpan = document.createElement("span");
                labelSpan.className = "col-form-label col-sm-2";
                labelSpan.textContent = safeColumnName; // safe assignment (no HTML parsing)

                const inputDiv = document.createElement("div");
                inputDiv.className = "col-sm-3";

                const input = document.createElement("input");
                input.type = "text";
                input.className = "form-control GotoParamFields";
                input.setAttribute("data-filtertext", "1");
                input.name = `Select_${safeColumnName}`;
                input.id = `Select_${safeColumnName}`;

                inputDiv.appendChild(input);
                row.appendChild(labelSpan);
                row.appendChild(inputDiv);

                // Safe append after sanitization
                container.appendChild(row);
            });
        }
    };

    // Bind links for opening details
    document.querySelectorAll(".open-details").forEach(el => {
        el.addEventListener("click", function (e) {
            e.preventDefault();
            const tableId = this.dataset.tableid;
            app.openDetailsList(tableId);
        });
    });

    // Bind links for opening control page
    document.querySelectorAll(".open-control-page").forEach(el => {
        el.addEventListener("click", function (e) {
            e.preventDefault();
            const name = this.dataset.displayname;
            const id = this.dataset.tableid;
            app.openControlPage(name, id);
        });
    });

    // Search batch number input
    const batchInput = document.getElementById("batchSearchInput");
    if (batchInput) {
        batchInput.addEventListener("input", () => {
            app.searchBatchNo();
        });
    }

    // Select batch number button
    const selectBtn = document.getElementById("selectBatchBtn");
    if (selectBtn) {
        selectBtn.addEventListener("click", () => {
            app.selectBatchNo();
        });
    }

    // Select parameter OK button
    const paramBtn = document.getElementById("selectParamBtn");
    if (paramBtn) {
        paramBtn.addEventListener("click", () => {
            app.selectParameter();
        });
    }
});

